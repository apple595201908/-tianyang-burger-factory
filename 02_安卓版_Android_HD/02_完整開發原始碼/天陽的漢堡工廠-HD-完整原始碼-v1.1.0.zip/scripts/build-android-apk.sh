#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORKSPACE_ROOT="$(cd "$PROJECT_ROOT/../.." && pwd)"
TOOLCHAIN_ROOT="${TIANYANG_ANDROID_TOOLCHAIN:-$WORKSPACE_ROOT/.android-toolchain}"
export JAVA_HOME="${JAVA_HOME:-$TOOLCHAIN_ROOT/jdk}"
export ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-$TOOLCHAIN_ROOT/sdk}"
export LD_LIBRARY_PATH="$JAVA_HOME/lib:$JAVA_HOME/lib/server${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
ANDROID_TMPDIR="${TIANYANG_ANDROID_TMPDIR:-$WORKSPACE_ROOT/.android-tmp}"
mkdir -p "$ANDROID_TMPDIR"
export JAVA_TOOL_OPTIONS="${JAVA_TOOL_OPTIONS:-} -Djava.io.tmpdir=$ANDROID_TMPDIR"
BUILD_TOOLS="$ANDROID_SDK_ROOT/build-tools/35.0.0"
ANDROID_JAR="$ANDROID_SDK_ROOT/platforms/android-35/android.jar"
export LD_LIBRARY_PATH="$BUILD_TOOLS/lib64:$LD_LIBRARY_PATH"

if [[ ! -x "$JAVA_HOME/bin/javac" || ! -x "$BUILD_TOOLS/aapt2" || ! -f "$ANDROID_JAR" ]]; then
  echo "Android toolchain not found. Set TIANYANG_ANDROID_TOOLCHAIN or JAVA_HOME/ANDROID_SDK_ROOT." >&2
  exit 1
fi

bash "$PROJECT_ROOT/scripts/build-android-assets.sh"
mkdir -p "$PROJECT_ROOT/outputs"
TARGET_APK="$PROJECT_ROOT/outputs/Tianyang-Burger-Factory-HD-v1.1.0.apk"
BUILD_DIR="$(mktemp -d "$PROJECT_ROOT/outputs/android-build.XXXXXX")"
GENERATED_DIR="$BUILD_DIR/generated"
CLASSES_DIR="$BUILD_DIR/classes"
DEX_DIR="$BUILD_DIR/dex"
mkdir -p "$GENERATED_DIR" "$CLASSES_DIR" "$DEX_DIR"

"$BUILD_TOOLS/aapt2" compile \
  --dir "$PROJECT_ROOT/android/app/src/main/res" \
  -o "$BUILD_DIR/resources.zip"

"$BUILD_TOOLS/aapt2" link \
  -o "$BUILD_DIR/app-unsigned-unaligned.apk" \
  -I "$ANDROID_JAR" \
  --manifest "$PROJECT_ROOT/android/app/src/main/AndroidManifest.xml" \
  --java "$GENERATED_DIR" \
  --min-sdk-version 24 \
  --target-sdk-version 35 \
  --version-code 2 \
  --version-name "1.1.0-hd" \
  --auto-add-overlay \
  -A "$PROJECT_ROOT/android/app/src/main/assets" \
  "$BUILD_DIR/resources.zip"

"$JAVA_HOME/bin/javac" \
  -source 8 \
  -target 8 \
  -encoding UTF-8 \
  -classpath "$ANDROID_JAR" \
  -d "$CLASSES_DIR" \
  "$PROJECT_ROOT/android/app/src/main/java/com/tianyang/burgerfactory/MainActivity.java" \
  "$GENERATED_DIR/com/tianyang/burgerfactory/R.java"

"$JAVA_HOME/bin/jar" cf "$BUILD_DIR/classes.jar" -C "$CLASSES_DIR" .
"$BUILD_TOOLS/d8" \
  --lib "$ANDROID_JAR" \
  --min-api 24 \
  --output "$DEX_DIR" \
  "$BUILD_DIR/classes.jar"

(
  cd "$DEX_DIR"
  "$BUILD_TOOLS/aapt" add "$BUILD_DIR/app-unsigned-unaligned.apk" classes.dex >/dev/null
)

"$BUILD_TOOLS/zipalign" -p -f 4 \
  "$BUILD_DIR/app-unsigned-unaligned.apk" \
  "$BUILD_DIR/app-unsigned-aligned.apk"

KEYSTORE_DIR="$PROJECT_ROOT/outputs/.signing"
KEYSTORE="$KEYSTORE_DIR/tianyang-hd-preview.keystore"
mkdir -p "$KEYSTORE_DIR"
if [[ ! -f "$KEYSTORE" ]]; then
  "$JAVA_HOME/bin/keytool" -genkeypair -noprompt \
    -keystore "$KEYSTORE" \
    -storepass android \
    -alias tianyanghd \
    -keypass android \
    -dname "CN=Tianyang Burger Factory HD, O=Tianyang Games, C=TW" \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000
fi

"$BUILD_TOOLS/apksigner" sign \
  --ks "$KEYSTORE" \
  --ks-key-alias tianyanghd \
  --ks-pass pass:android \
  --key-pass pass:android \
  --out "$TARGET_APK" \
  "$BUILD_DIR/app-unsigned-aligned.apk"

"$BUILD_TOOLS/apksigner" verify --verbose "$TARGET_APK"
"$BUILD_TOOLS/aapt" dump badging "$TARGET_APK" | sed -n '1,4p'

echo "Installable APK ready: $TARGET_APK"
