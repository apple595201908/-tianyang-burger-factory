import assert from "node:assert/strict";
import { readFile, stat } from "node:fs/promises";
import test from "node:test";

const root = new URL("../", import.meta.url);
const read = (path) => readFile(new URL(path, root), "utf8");

test("Android HD renderer uses SVG and never creates a Canvas", async () => {
  const [html, source, built] = await Promise.all([
    read("android-svg/index.html"),
    read("android-svg/src/game.ts"),
    read("android/app/src/main/assets/www/game.js"),
  ]);
  assert.match(html, /<svg[\s>]/i);
  assert.match(html, /id="factory-stage"/);
  assert.doesNotMatch(`${html}\n${source}\n${built}`, /<canvas|createElement\s*\([^)]*canvas/i);
  assert.doesNotMatch(source, /Phaser/);
});

test("Android HD build preserves the V1 split-touch and line-return contract", async () => {
  const source = await read("android-svg/src/game.ts");
  assert.match(source, /localX < rect\.width \* 0\.5 \? "FINISH" : "RETURN"/);
  assert.match(source, /candidate\.x -= shift/);
  assert.match(source, /food\.reworkSkips < 2/);
  assert.match(source, /food\.x > this\.layout\.deadlineX/);
  assert.match(source, /candidate\.element\.setAttribute\("visibility", "hidden"\)/);
});

test("Android shell is offline-first and loads packaged web assets", async () => {
  const [manifest, activity] = await Promise.all([
    read("android/app/src/main/AndroidManifest.xml"),
    read("android/app/src/main/java/com/tianyang/burgerfactory/MainActivity.java"),
  ]);
  assert.doesNotMatch(manifest, /android\.permission\.INTERNET/);
  assert.match(activity, /file:\/\/\/android_asset\/www\/index\.html/);
  assert.match(activity, /setDomStorageEnabled\(true\)/);
});

test("Android package contains its HD backgrounds, audio, and compiled game", async () => {
  const requiredAssets = [
    "android/app/src/main/assets/www/game.js",
    "android/app/src/main/assets/www/styles.css",
    "android/app/src/main/assets/www/assets/factory-bg-portrait-hd.webp",
    "android/app/src/main/assets/www/assets/factory-bg-landscape-hd.webp",
    "android/app/src/main/assets/www/audio/factory-rush-bgm.mp3",
    "android/app/src/main/assets/www/audio/finish.wav",
    "android/app/src/main/assets/www/audio/return.wav",
  ];
  for (const asset of requiredAssets) {
    assert.ok((await stat(new URL(asset, root))).size > 0, `${asset} should not be empty`);
  }
});
