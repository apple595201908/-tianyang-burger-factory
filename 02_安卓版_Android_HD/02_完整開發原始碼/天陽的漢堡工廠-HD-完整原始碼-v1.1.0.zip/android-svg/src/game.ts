interface Window {
  TianyangApp?: {
    pauseFromNative(): void;
  };
}

type Mode =
  | "menu"
  | "tutorial"
  | "countdown"
  | "playing"
  | "returning"
  | "paused"
  | "gameover";
type FoodVisualState = "spawned" | "base-only" | "filled" | "capped" | "returning" | "rework";
type Action = "FINISH" | "RETURN";
type FailureReason = "WRONG_FINISH" | "WRONG_RETURN" | "MISSED_DEADLINE";

interface Layout {
  width: number;
  height: number;
  scale: number;
  motionScale: number;
  conveyorY: number;
  conveyorHeight: number;
  foodY: number;
  spawnX: number;
  baseX: number;
  fillX: number;
  playerX: number;
  inspectorX: number;
  deadlineX: number;
  gap: number;
}

interface Food {
  id: number;
  x: number;
  state: FoodVisualState;
  element: SVGGElement;
  baseProcessed: boolean;
  ingredientProcessed: boolean;
  playerProcessed: boolean;
  scored: boolean;
  tutorial: boolean;
  hidden: boolean;
  reworkSkips: number;
}

interface SaveData {
  saveVersion: 2;
  bestScore: number;
  mute: boolean;
  tutorialCompleted: boolean;
  tutorialVersion: number;
}

const SVG_NS = "http://www.w3.org/2000/svg";
const STORAGE_KEY = "factoryRush.save";
const TUTORIAL_VERSION = 2;
const START_SPEED = 128;
const MAX_SPEED = 465;
const BASE_GAP = 205;
const ACTION_LEAD = 52;
const DEFECT_RATE = 0.18;
const INPUT_LOCK_MS = 42;
const REWORK_MS = 210;
const COUNTDOWN_STEP_MS = 650;
const SPEED_MILESTONES = [10, 25, 50, 75, 100, 150, 200];

function required<T extends Element>(selector: string): T {
  const element = document.querySelector<T>(selector);
  if (!element) throw new Error(`Missing required element: ${selector}`);
  return element;
}

function clamp(value: number, minimum: number, maximum: number): number {
  return Math.max(minimum, Math.min(maximum, value));
}

function svgElement<K extends keyof SVGElementTagNameMap>(name: K): SVGElementTagNameMap[K] {
  return document.createElementNS(SVG_NS, name);
}

class SaveStore {
  private data: SaveData;

  public constructor() {
    this.data = this.load();
  }

  private load(): SaveData {
    const fallback: SaveData = {
      saveVersion: 2,
      bestScore: 0,
      mute: false,
      tutorialCompleted: false,
      tutorialVersion: TUTORIAL_VERSION,
    };
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (!raw) return fallback;
      const parsed = JSON.parse(raw) as Partial<SaveData>;
      return {
        ...fallback,
        ...parsed,
        bestScore: Math.max(0, Number(parsed.bestScore) || 0),
        mute: Boolean(parsed.mute),
        tutorialCompleted:
          Boolean(parsed.tutorialCompleted) && Number(parsed.tutorialVersion) === TUTORIAL_VERSION,
        tutorialVersion: TUTORIAL_VERSION,
      };
    } catch {
      return fallback;
    }
  }

  private persist(): void {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data));
    } catch {
      // Storage availability must never prevent gameplay.
    }
  }

  public get value(): Readonly<SaveData> {
    return this.data;
  }

  public setBestScore(score: number): void {
    if (score <= this.data.bestScore) return;
    this.data.bestScore = score;
    this.persist();
  }

  public setMuted(muted: boolean): void {
    this.data.mute = muted;
    this.persist();
  }

  public completeTutorial(): void {
    this.data.tutorialCompleted = true;
    this.data.tutorialVersion = TUTORIAL_VERSION;
    this.persist();
  }
}

class RandomSource {
  private state: number;

  public constructor() {
    const seedValue = new URLSearchParams(window.location.search).get("seed");
    const parsed = seedValue === null ? Number.NaN : Number(seedValue);
    this.state = (Number.isFinite(parsed) ? parsed : Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    if (this.state === 0) this.state = 0x6d2b79f5;
  }

  public next(): number {
    let value = (this.state += 0x6d2b79f5);
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  }
}

class GameAudio {
  private readonly bgm: HTMLAudioElement;
  private readonly sounds = new Map<string, HTMLAudioElement>();
  private muted: boolean;

  public constructor(muted: boolean) {
    this.muted = muted;
    this.bgm = this.makeAudio("./audio/factory-rush-bgm.mp3", true, 0.32);
    const effects: Array<[string, string, number]> = [
      ["finish", "./audio/finish.wav", 0.68],
      ["return", "./audio/return.wav", 0.72],
      ["approved", "./audio/approved.wav", 0.58],
      ["speedup", "./audio/speedup.wav", 0.64],
      ["fail", "./audio/fail.wav", 0.7],
      ["button", "./audio/button.wav", 0.55],
    ];
    effects.forEach(([name, path, volume]) => this.sounds.set(name, this.makeAudio(path, false, volume)));
    this.applyMutedState();
  }

  private makeAudio(path: string, loop: boolean, volume: number): HTMLAudioElement {
    const audio = new Audio(path);
    audio.preload = "auto";
    audio.loop = loop;
    audio.volume = volume;
    return audio;
  }

  private applyMutedState(): void {
    this.bgm.muted = this.muted;
    this.sounds.forEach((sound) => {
      sound.muted = this.muted;
    });
  }

  public unlock(): void {
    if (this.muted) return;
    const button = this.sounds.get("button");
    if (button) {
      button.currentTime = 0;
      void button.play().catch(() => undefined);
    }
  }

  public startMusic(): void {
    if (this.muted) return;
    void this.bgm.play().catch(() => undefined);
  }

  public pauseMusic(): void {
    this.bgm.pause();
  }

  public play(name: string): void {
    if (this.muted) return;
    const sound = this.sounds.get(name);
    if (!sound) return;
    sound.currentTime = 0;
    void sound.play().catch(() => undefined);
  }

  public toggle(): boolean {
    this.muted = !this.muted;
    this.applyMutedState();
    if (this.muted) this.pauseMusic();
    else this.startMusic();
    return this.muted;
  }

  public get isMuted(): boolean {
    return this.muted;
  }
}

class VectorBurgerFactory {
  private readonly app = required<HTMLElement>("#app");
  private readonly stage = required<SVGSVGElement>("#factory-stage");
  private readonly foodsLayer = required<SVGGElement>("#foods");
  private readonly effectsLayer = required<SVGGElement>("#effects");
  private readonly rollersLayer = required<SVGGElement>("#rollers");
  private readonly lampsLayer = required<SVGGElement>("#status-lamps");
  private readonly hud = required<HTMLElement>("#hud");
  private readonly touchZones = required<HTMLElement>("#touch-zones");
  private readonly cue = required<HTMLElement>("#cue");
  private readonly cueStep = required<HTMLElement>("#cue-step");
  private readonly cueTitle = required<HTMLElement>("#cue-title");
  private readonly cueDetail = required<HTMLElement>("#cue-detail");
  private readonly countdown = required<HTMLElement>("#countdown");
  private readonly toast = required<HTMLElement>("#toast");
  private readonly menu = required<HTMLElement>("#menu");
  private readonly pauseOverlay = required<HTMLElement>("#pause-overlay");
  private readonly gameOverOverlay = required<HTMLElement>("#gameover-overlay");
  private readonly scoreText = required<HTMLElement>("#score");
  private readonly speedText = required<HTMLElement>("#speed");
  private readonly bestScoreText = required<HTMLElement>("#best-score");
  private readonly finalScoreText = required<HTMLElement>("#final-score");
  private readonly finalBestText = required<HTMLElement>("#final-best");
  private readonly failureTitle = required<HTMLElement>("#failure-title");
  private readonly failureDetail = required<HTMLElement>("#failure-detail");
  private readonly muteButton = required<HTMLButtonElement>("#mute-button");
  private readonly store = new SaveStore();
  private readonly random = new RandomSource();
  private readonly audio = new GameAudio(this.store.value.mute);

  private layout: Layout;
  private foods: Food[] = [];
  private mode: Mode = "menu";
  private modeBeforePause: Mode = "playing";
  private score = 0;
  private nextFoodId = 1;
  private spawnDistance = 0;
  private lastFrame = performance.now();
  private lastInputAt = -Infinity;
  private transitionToken = 0;
  private tutorialStage = 0;
  private tutorialTransitionAt = 0;
  private returnFood: Food | null = null;
  private returnRemaining = 0;
  private returnPhase: "rewind" | "rework" = "rewind";
  private reworkReadyAt = 0;
  private returnOriginMode: Mode = "playing";

  public constructor() {
    this.layout = this.calculateLayout();
    this.bindControls();
    this.applyLayout();
    this.updateMuteButton();
    this.bestScoreText.textContent = String(this.store.value.bestScore);
    this.renderHud();
    requestAnimationFrame((time) => this.frame(time));
  }

  private bindControls(): void {
    const bindButton = (selector: string, callback: () => void): void => {
      const button = required<HTMLButtonElement>(selector);
      button.addEventListener("pointerdown", (event) => {
        event.stopPropagation();
      });
      button.addEventListener("click", (event) => {
        event.stopPropagation();
        this.audio.unlock();
        this.audio.play("button");
        callback();
      });
    };

    bindButton("#start-button", () => {
      this.menu.classList.add("hidden");
      this.audio.startMusic();
      if (this.store.value.tutorialCompleted) this.startCountdown();
      else this.startTutorial();
    });
    bindButton("#tutorial-button", () => {
      this.menu.classList.add("hidden");
      this.audio.startMusic();
      this.startTutorial();
    });
    bindButton("#pause-button", () => this.pauseGame());
    bindButton("#resume-button", () => this.resumeGame());
    bindButton("#quit-button", () => this.showMenu());
    bindButton("#retry-button", () => this.startCountdown());
    bindButton("#gameover-menu-button", () => this.showMenu());
    bindButton("#mute-button", () => {
      const muted = this.audio.toggle();
      this.store.setMuted(muted);
      this.updateMuteButton();
    });

    this.app.addEventListener("pointerdown", (event) => this.handlePointer(event), { passive: false });
    this.app.addEventListener("contextmenu", (event) => event.preventDefault());
    window.addEventListener("resize", () => {
      const previous = this.layout;
      this.layout = this.calculateLayout();
      this.reflowFoods(previous, this.layout);
      this.applyLayout();
    });
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) this.pauseFromNative();
    });
    window.addEventListener("blur", () => this.pauseFromNative());

    window.TianyangApp = { pauseFromNative: () => this.pauseFromNative() };
  }

  private calculateLayout(): Layout {
    const width = Math.max(320, window.innerWidth);
    const height = Math.max(320, window.innerHeight);
    const portrait = height >= width;
    const referenceAxis = portrait ? width : height;
    const scale = clamp(referenceAxis / 390, 0.78, 1.48);
    const conveyorY = portrait ? height * 0.625 : height * 0.62;
    const conveyorHeight = 104 * scale;
    return {
      width,
      height,
      scale,
      motionScale: scale,
      conveyorY,
      conveyorHeight,
      foodY: conveyorY - conveyorHeight * 0.34,
      spawnX: -82 * scale,
      baseX: width * 0.105,
      fillX: width * 0.335,
      playerX: width * 0.665,
      inspectorX: width * 0.885,
      deadlineX: width * 0.885 + 49 * scale,
      gap: BASE_GAP * scale,
    };
  }

  private applyLayout(): void {
    const layout = this.layout;
    this.stage.setAttribute("viewBox", `0 0 ${layout.width} ${layout.height}`);
    required<SVGRectElement>("#wall-tint").setAttribute("width", String(layout.width));
    required<SVGRectElement>("#wall-tint").setAttribute("height", String(layout.height));

    const pipeY = 92 * layout.scale;
    const pipePath = `M${-20 * layout.scale} ${pipeY} H${layout.width * 0.42} Q${layout.width * 0.47} ${pipeY} ${layout.width * 0.47} ${pipeY + 55 * layout.scale} V${pipeY + 82 * layout.scale} H${layout.width + 20 * layout.scale}`;
    required<SVGPathElement>("#top-pipe").setAttribute("d", pipePath);
    required<SVGPathElement>("#top-pipe-highlight").setAttribute("d", pipePath);

    const workerY = layout.conveyorY - layout.conveyorHeight * 0.5 - 70 * layout.scale;
    const workerScale = layout.scale * (layout.width < 370 ? 0.9 : 1);
    this.placeGroup("#worker-base", layout.baseX, workerY, workerScale);
    this.placeGroup("#worker-fill", layout.fillX, workerY, workerScale);
    this.placeGroup("#worker-player", layout.playerX, workerY, workerScale * 1.04);
    this.placeGroup("#worker-inspector", layout.inspectorX, workerY, workerScale);

    const guideY = layout.foodY - 22 * layout.scale;
    this.placeGuide("#guide-base", layout.baseX, guideY);
    this.placeGuide("#guide-fill", layout.fillX, guideY);
    this.placeGuide("#guide-player", layout.playerX, guideY);
    this.placeGuide("#guide-inspector", layout.inspectorX, guideY);

    this.layoutConveyor();
    this.renderStatusLamps();
    this.foods.forEach((food) => this.renderFoodPosition(food));
  }

  private placeGroup(selector: string, x: number, y: number, scale: number): void {
    required<SVGGElement>(selector).setAttribute("transform", `translate(${x} ${y}) scale(${scale})`);
  }

  private placeGuide(selector: string, x: number, y: number): void {
    required<SVGGElement>(selector).setAttribute("transform", `translate(${x} ${y}) scale(${this.layout.scale})`);
  }

  private layoutConveyor(): void {
    const { width, conveyorY, conveyorHeight, scale } = this.layout;
    const shadow = required<SVGRectElement>("#belt-shadow");
    const frame = required<SVGRectElement>("#belt-frame");
    const surface = required<SVGRectElement>("#belt-surface");
    const hazard = required<SVGRectElement>("#belt-hazard");
    const ticks = required<SVGLineElement>("#belt-ticks");
    shadow.setAttribute("x", String(-10 * scale));
    shadow.setAttribute("y", String(conveyorY + 18 * scale));
    shadow.setAttribute("width", String(width + 20 * scale));
    shadow.setAttribute("height", String(conveyorHeight));
    frame.setAttribute("x", String(-8 * scale));
    frame.setAttribute("y", String(conveyorY - conveyorHeight * 0.5));
    frame.setAttribute("width", String(width + 16 * scale));
    frame.setAttribute("height", String(conveyorHeight));
    surface.setAttribute("x", String(-4 * scale));
    surface.setAttribute("y", String(conveyorY - conveyorHeight * 0.39));
    surface.setAttribute("width", String(width + 8 * scale));
    surface.setAttribute("height", String(conveyorHeight * 0.55));
    ticks.setAttribute("x1", "0");
    ticks.setAttribute("x2", String(width));
    ticks.setAttribute("y1", String(conveyorY - conveyorHeight * 0.11));
    ticks.setAttribute("y2", String(conveyorY - conveyorHeight * 0.11));
    hazard.setAttribute("x", "0");
    hazard.setAttribute("y", String(conveyorY + conveyorHeight * 0.32));
    hazard.setAttribute("width", String(width));
    hazard.setAttribute("height", String(13 * scale));

    this.rollersLayer.replaceChildren();
    const rollerY = conveyorY + conveyorHeight * 0.18;
    const spacing = 64 * scale;
    for (let x = 30 * scale; x < width; x += spacing) {
      const roller = svgElement("circle");
      roller.setAttribute("cx", String(x));
      roller.setAttribute("cy", String(rollerY));
      roller.setAttribute("r", String(15 * scale));
      roller.setAttribute("fill", "#152630");
      roller.setAttribute("stroke", "#7595a5");
      roller.setAttribute("stroke-width", String(3 * scale));
      this.rollersLayer.append(roller);
    }
  }

  private renderStatusLamps(): void {
    this.lampsLayer.replaceChildren();
    const y = Math.max(120 * this.layout.scale, this.layout.conveyorY * 0.35);
    [this.layout.baseX, this.layout.fillX, this.layout.playerX, this.layout.inspectorX].forEach((x, index) => {
      const group = svgElement("g");
      group.setAttribute("transform", `translate(${x} ${y}) scale(${this.layout.scale})`);
      const box = svgElement("rect");
      box.setAttribute("x", "-24"); box.setAttribute("y", "-15"); box.setAttribute("width", "48"); box.setAttribute("height", "30"); box.setAttribute("rx", "8");
      box.setAttribute("fill", "url(#panel)"); box.setAttribute("stroke", "#668696");
      const lamp = svgElement("circle");
      lamp.setAttribute("r", "7"); lamp.setAttribute("fill", index === 2 ? "#ffc64b" : "#57efb2"); lamp.setAttribute("filter", "url(#glow)");
      group.append(box, lamp);
      this.lampsLayer.append(group);
    });
  }

  private reflowFoods(previous: Layout, next: Layout): void {
    const ratio = next.width / Math.max(1, previous.width);
    this.foods.forEach((food) => {
      food.x *= ratio;
    });
    this.returnRemaining *= ratio;
  }

  private createFood(state: FoodVisualState, x: number, tutorial = false): Food {
    const element = svgElement("g");
    element.classList.add("food");
    element.setAttribute("role", "img");
    element.setAttribute("aria-label", state === "base-only" ? "缺料漢堡" : "完整漢堡");
    element.innerHTML = `
      <ellipse class="food-shadow" cx="0" cy="34" rx="51" ry="12" />
      <rect class="bottom-bun" x="-47" y="15" width="94" height="26" rx="12" />
      <g class="ingredients">
        <path class="lettuce" d="M-49 8Q-37-3-24 8Q-10-4 2 8Q17-4 30 8Q41-2 49 8L44 18H-44Z" />
        <rect class="patty" x="-45" y="-2" width="90" height="20" rx="9" />
        <path class="cheese" d="M-44-8H44V4L28 12 13 4-4 12-20 4-35 10-44 3Z" />
        <rect class="tomato" x="-39" y="-16" width="78" height="11" rx="5" />
      </g>
      <path class="top-bun" d="M-47-13Q-38-58 0-60Q38-58 47-13Q30-5 0-5Q-30-5-47-13Z" />
      <g class="sesame">
        <ellipse cx="-23" cy="-34" rx="4" ry="2" transform="rotate(-24 -23 -34)" />
        <ellipse cx="0" cy="-45" rx="4" ry="2" />
        <ellipse cx="24" cy="-31" rx="4" ry="2" transform="rotate(22 24 -31)" />
        <ellipse cx="-6" cy="-23" rx="4" ry="2" transform="rotate(18 -6 -23)" />
      </g>
      <circle class="missing-ring" cy="-5" r="58" />
    `;
    this.foodsLayer.append(element);
    const food: Food = {
      id: this.nextFoodId++,
      x,
      state,
      element,
      baseProcessed: state !== "spawned",
      ingredientProcessed: state === "filled" || state === "base-only",
      playerProcessed: state === "capped",
      scored: false,
      tutorial,
      hidden: false,
      reworkSkips: 0,
    };
    this.foods.push(food);
    this.renderFood(food);
    return food;
  }

  private renderFood(food: Food): void {
    food.element.classList.remove("spawned", "base-only", "filled", "capped", "returning", "rework", "approved", "return-target");
    food.element.classList.add(food.state);
    if (food === this.returnFood) food.element.classList.add("return-target");
    food.element.setAttribute("aria-label", food.state === "base-only" ? "缺料漢堡" : "完整漢堡");
    this.renderFoodPosition(food);
  }

  private renderFoodPosition(food: Food): void {
    const scale = this.layout.scale;
    food.element.setAttribute("transform", `translate(${food.x} ${this.layout.foodY}) scale(${scale})`);
  }

  private removeFood(food: Food): void {
    food.element.remove();
    this.foods = this.foods.filter((candidate) => candidate !== food);
    if (this.returnFood === food) this.returnFood = null;
  }

  private clearFoods(): void {
    this.foodsLayer.replaceChildren();
    this.foods = [];
    this.returnFood = null;
    this.spawnDistance = 0;
  }

  private speedForScore(score: number): number {
    return Math.min(START_SPEED + score * 2 + Math.floor(score / 10) * 4, MAX_SPEED);
  }

  private currentSpeed(): number {
    if (this.mode === "tutorial" || (this.mode === "returning" && this.returnOriginMode === "tutorial")) return 150;
    return this.speedForScore(this.score);
  }

  private reworkSkipRate(): number {
    return Math.min(0.05 + Math.max(0, this.score) * 0.004, 0.62);
  }

  private startTutorial(): void {
    this.transitionToken += 1;
    this.clearFoods();
    this.score = 0;
    this.mode = "tutorial";
    this.tutorialStage = 0;
    this.tutorialTransitionAt = 0;
    this.menu.classList.add("hidden");
    this.gameOverOverlay.classList.add("hidden");
    this.pauseOverlay.classList.add("hidden");
    this.hud.classList.remove("hidden");
    this.touchZones.classList.remove("hidden");
    this.cue.classList.remove("hidden");
    this.app.classList.add("tutorial-left");
    this.app.classList.remove("tutorial-right");
    this.setCue("練習 1 / 2", "完整漢堡來了", "等它到工作站，點螢幕左半邊完成封蓋");
    this.createFood("filled", this.layout.fillX - 90 * this.layout.scale, true);
    this.renderHud();
  }

  private startSecondTutorialStep(): void {
    this.foods.slice().forEach((food) => this.removeFood(food));
    this.tutorialStage = 2;
    this.app.classList.remove("tutorial-left");
    this.app.classList.add("tutorial-right");
    this.setCue("練習 2 / 2", "這顆漢堡缺料", "看到明顯空缺時，點螢幕右半邊退回補料");
    this.createFood("base-only", this.layout.fillX - 70 * this.layout.scale, true);
  }

  private setCue(step: string, title: string, detail: string): void {
    this.cueStep.textContent = step;
    this.cueTitle.textContent = title;
    this.cueDetail.textContent = detail;
  }

  private startCountdown(): void {
    const token = ++this.transitionToken;
    this.clearFoods();
    this.score = 0;
    this.mode = "countdown";
    this.menu.classList.add("hidden");
    this.pauseOverlay.classList.add("hidden");
    this.gameOverOverlay.classList.add("hidden");
    this.cue.classList.add("hidden");
    this.touchZones.classList.add("hidden");
    this.app.classList.remove("tutorial-left", "tutorial-right", "returning");
    this.hud.classList.remove("hidden");
    this.renderHud();

    const labels = ["3", "2", "1", "GO!"];
    labels.forEach((label, index) => {
      window.setTimeout(() => {
        if (token !== this.transitionToken) return;
        this.countdown.textContent = label;
        this.countdown.classList.remove("hidden");
        this.countdown.style.animation = "none";
        void this.countdown.offsetWidth;
        this.countdown.style.animation = "";
        if (index < 3) this.audio.play("button");
        else this.audio.play("speedup");
      }, index * COUNTDOWN_STEP_MS);
    });
    window.setTimeout(() => {
      if (token !== this.transitionToken) return;
      this.countdown.classList.add("hidden");
      this.beginPlaying();
    }, labels.length * COUNTDOWN_STEP_MS);
  }

  private beginPlaying(): void {
    this.clearFoods();
    this.mode = "playing";
    this.lastFrame = performance.now();
    this.spawnDistance = this.layout.gap * 0.75;
    this.touchZones.classList.remove("hidden");
    this.createFood("spawned", this.layout.spawnX);
    this.renderHud();
  }

  private showMenu(): void {
    this.transitionToken += 1;
    this.clearFoods();
    this.mode = "menu";
    this.menu.classList.remove("hidden");
    this.pauseOverlay.classList.add("hidden");
    this.gameOverOverlay.classList.add("hidden");
    this.hud.classList.add("hidden");
    this.touchZones.classList.add("hidden");
    this.cue.classList.add("hidden");
    this.countdown.classList.add("hidden");
    this.app.classList.remove("tutorial-left", "tutorial-right", "returning");
    this.bestScoreText.textContent = String(this.store.value.bestScore);
    this.audio.pauseMusic();
  }

  private pauseGame(): void {
    if (!(["playing", "returning", "tutorial"] as Mode[]).includes(this.mode)) return;
    this.modeBeforePause = this.mode;
    this.mode = "paused";
    this.pauseOverlay.classList.remove("hidden");
    this.audio.pauseMusic();
  }

  private pauseFromNative(): void {
    if ((["playing", "returning", "tutorial"] as Mode[]).includes(this.mode)) this.pauseGame();
  }

  private resumeGame(): void {
    if (this.mode !== "paused") return;
    this.mode = this.modeBeforePause;
    this.pauseOverlay.classList.add("hidden");
    this.lastFrame = performance.now();
    this.audio.startMusic();
  }

  private handlePointer(event: PointerEvent): void {
    if ((event.target as Element | null)?.closest("button")) return;
    if (this.mode !== "playing" && this.mode !== "tutorial") return;
    event.preventDefault();
    const now = performance.now();
    if (now - this.lastInputAt < INPUT_LOCK_MS) return;
    this.lastInputAt = now;

    const rect = this.app.getBoundingClientRect();
    const localX = event.clientX - rect.left;
    const localY = event.clientY - rect.top;
    const action: Action = localX < rect.width * 0.5 ? "FINISH" : "RETURN";
    this.touchFeedback(localX, localY, action);

    const candidates = this.foods.filter(
      (food) =>
        !food.playerProcessed &&
        food.ingredientProcessed &&
        food.x >= this.layout.playerX - ACTION_LEAD * this.layout.scale &&
        food.x <= this.layout.deadlineX,
    );
    candidates.sort((first, second) => Math.abs(first.x - this.layout.playerX) - Math.abs(second.x - this.layout.playerX));
    const food = candidates[0];
    if (!food) {
      if (this.mode === "tutorial") this.showToast("等漢堡到你的工作站");
      return;
    }

    const needsReturn = food.state === "base-only";
    const correct = (needsReturn && action === "RETURN") || (!needsReturn && action === "FINISH");
    if (!correct) {
      if (this.mode === "tutorial") {
        this.audio.play("fail");
        this.showToast(needsReturn ? "缺料要按右邊 ↩" : "完整要按左邊 ✓");
        this.cue.animate(
          [{ transform: "translateX(-50%)" }, { transform: "translateX(calc(-50% - 10px))" }, { transform: "translateX(calc(-50% + 10px))" }, { transform: "translateX(-50%)" }],
          { duration: 260 },
        );
        return;
      }
      this.fail(needsReturn ? "WRONG_FINISH" : "WRONG_RETURN");
      return;
    }

    if (action === "FINISH") this.finishFood(food);
    else this.startReturn(food);
  }

  private finishFood(food: Food): void {
    food.state = "capped";
    food.playerProcessed = true;
    this.renderFood(food);
    food.element.classList.add("approved");
    this.audio.play("finish");
    this.vibrate(18);
    if (this.mode === "tutorial") {
      this.tutorialStage = 1;
      this.tutorialTransitionAt = performance.now() + 560;
      this.showToast("正確！完整漢堡按左邊");
      this.setCue("完成 1 / 2", "封蓋成功", "下一顆會示範缺料漢堡");
      this.app.classList.remove("tutorial-left");
    }
  }

  private startReturn(food: Food): void {
    const completedDownstream = this.foods.filter(
      (candidate) => candidate !== food && candidate.playerProcessed && candidate.x > this.layout.playerX,
    );
    completedDownstream.forEach((candidate) => {
      candidate.hidden = true;
      candidate.element.setAttribute("visibility", "hidden");
    });

    this.returnOriginMode = this.mode;
    this.returnFood = food;
    this.returnRemaining = Math.max(0, food.x - this.layout.fillX);
    this.returnPhase = "rewind";
    food.state = "returning";
    this.renderFood(food);
    this.mode = "returning";
    this.app.classList.add("returning");
    this.audio.play("return");
    this.vibrate(26);
    if (this.returnOriginMode === "tutorial") {
      this.setCue("練習 2 / 2", "整條產線正在退回", "所有漢堡保持等距，退回速度與輸送帶一致");
    }
  }

  private updateReturn(deltaSeconds: number, now: number): void {
    const food = this.returnFood;
    if (!food) {
      this.mode = this.returnOriginMode;
      return;
    }
    if (this.returnPhase === "rewind") {
      const speed = this.currentSpeed() * this.layout.motionScale;
      const shift = Math.min(this.returnRemaining, speed * deltaSeconds);
      this.foods.forEach((candidate) => {
        candidate.x -= shift;
        this.renderFoodPosition(candidate);
      });
      this.returnRemaining -= shift;
      this.spawnDistance = Math.max(0, this.spawnDistance - shift);
      if (this.returnRemaining <= 0.01) {
        food.state = "rework";
        this.renderFood(food);
        this.returnPhase = "rework";
        this.reworkReadyAt = now + REWORK_MS;
      }
      return;
    }
    if (now >= this.reworkReadyAt) this.completeReturn();
  }

  private completeReturn(): void {
    const food = this.returnFood;
    if (!food) return;
    const tutorial = this.returnOriginMode === "tutorial";
    const skip = !tutorial && food.reworkSkips < 2 && this.random.next() < this.reworkSkipRate();
    food.state = skip ? "base-only" : "filled";
    food.playerProcessed = false;
    food.ingredientProcessed = true;
    if (skip) food.reworkSkips += 1;
    this.returnFood = null;
    this.app.classList.remove("returning");
    this.mode = tutorial ? "tutorial" : "playing";
    this.renderFood(food);

    if (tutorial) {
      this.tutorialStage = 3;
      this.store.completeTutorial();
      this.setCue("練習完成", "補料成功！", "記住：完整按左，缺料按右");
      this.showToast("準備正式上工！");
      this.app.classList.remove("tutorial-right");
      const token = ++this.transitionToken;
      window.setTimeout(() => {
        if (token === this.transitionToken) this.startCountdown();
      }, 900);
    } else if (skip) {
      this.showToast("配料員又漏了！等等再退一次");
    } else {
      this.showToast("補料完成");
    }
  }

  private fail(reason: FailureReason): void {
    if (this.mode === "gameover") return;
    this.mode = "gameover";
    this.app.classList.remove("returning");
    this.touchZones.classList.add("hidden");
    this.audio.play("fail");
    this.vibrate([60, 45, 80]);
    this.store.setBestScore(this.score);
    this.finalScoreText.textContent = String(this.score);
    this.finalBestText.textContent = String(this.store.value.bestScore);
    if (reason === "WRONG_FINISH") {
      this.failureTitle.textContent = "缺料漢堡被送出";
      this.failureDetail.textContent = "看到明顯空缺時，要按右半邊退回。";
    } else if (reason === "WRONG_RETURN") {
      this.failureTitle.textContent = "完整漢堡被退回";
      this.failureDetail.textContent = "完整漢堡要按左半邊完成封蓋。";
    } else {
      this.failureTitle.textContent = "漢堡通過品管員";
      this.failureDetail.textContent = "在漢堡越過最右側人物前完成判斷。";
    }
    this.gameOverOverlay.classList.remove("hidden");
  }

  private frame(time: number): void {
    const deltaSeconds = Math.min(0.05, Math.max(0, (time - this.lastFrame) / 1000));
    this.lastFrame = time;
    if (this.mode === "playing" || this.mode === "tutorial") this.updateLine(deltaSeconds, time);
    else if (this.mode === "returning") this.updateReturn(deltaSeconds, time);
    requestAnimationFrame((next) => this.frame(next));
  }

  private updateLine(deltaSeconds: number, now: number): void {
    const speed = this.currentSpeed() * this.layout.motionScale;
    const shift = speed * deltaSeconds;
    this.foods.forEach((food) => {
      const tutorialStop =
        this.mode === "tutorial" &&
        food.tutorial &&
        food.ingredientProcessed &&
        !food.playerProcessed
          ? this.layout.playerX + 16 * this.layout.scale
          : Number.POSITIVE_INFINITY;
      food.x += Math.min(shift, Math.max(0, tutorialStop - food.x));
      this.processStations(food);
      this.renderFoodPosition(food);
    });

    if (this.mode === "playing") {
      this.spawnDistance += shift;
      if (this.spawnDistance >= this.layout.gap) {
        this.spawnDistance -= this.layout.gap;
        this.createFood("spawned", this.layout.spawnX);
      }
    }

    if (this.mode === "tutorial" && this.tutorialStage === 1 && now >= this.tutorialTransitionAt) {
      this.startSecondTutorialStep();
      return;
    }

    const missed = this.foods.find(
      (food) => !food.tutorial && food.ingredientProcessed && !food.playerProcessed && food.x > this.layout.deadlineX,
    );
    if (missed) {
      this.fail("MISSED_DEADLINE");
      return;
    }

    this.foods.slice().forEach((food) => {
      if (!food.scored && food.playerProcessed && food.x >= this.layout.inspectorX) {
        this.approveFood(food);
        if (food.hidden) this.removeFood(food);
      }
      if (food.x > this.layout.width + 130 * this.layout.scale) this.removeFood(food);
    });
  }

  private processStations(food: Food): void {
    if (!food.baseProcessed && food.x >= this.layout.baseX) {
      food.baseProcessed = true;
      food.state = "base-only";
      this.renderFood(food);
    }
    if (!food.ingredientProcessed && food.x >= this.layout.fillX) {
      food.ingredientProcessed = true;
      food.state = this.random.next() < DEFECT_RATE ? "base-only" : "filled";
      this.renderFood(food);
    }
  }

  private approveFood(food: Food): void {
    food.scored = true;
    food.element.classList.add("approved");
    if (food.tutorial) return;
    this.score += 1;
    this.audio.play("approved");
    this.scoreBurst(food.x, this.layout.foodY - 60 * this.layout.scale);
    if (SPEED_MILESTONES.includes(this.score)) {
      this.audio.play("speedup");
      this.showToast("產線加速！");
    }
    this.renderHud();
  }

  private renderHud(): void {
    this.scoreText.textContent = String(this.score);
    const ratio = this.speedForScore(this.score) / START_SPEED;
    this.speedText.textContent = `${ratio.toFixed(1)}×`;
  }

  private updateMuteButton(): void {
    this.muteButton.textContent = this.audio.isMuted ? "×" : "♪";
    this.muteButton.setAttribute("aria-label", this.audio.isMuted ? "開啟音效" : "關閉音效");
  }

  private showToast(message: string): void {
    this.toast.textContent = message;
    this.toast.classList.remove("hidden");
    this.toast.animate(
      [{ opacity: 0, transform: "translate(-50%, -30%) scale(.8)" }, { opacity: 1, transform: "translate(-50%, -50%) scale(1)" }, { opacity: 0, transform: "translate(-50%, -70%) scale(.96)" }],
      { duration: 760, easing: "ease-out" },
    ).finished.finally(() => this.toast.classList.add("hidden"));
  }

  private touchFeedback(x: number, y: number, action: Action): void {
    const circle = svgElement("circle");
    circle.setAttribute("cx", String(x));
    circle.setAttribute("cy", String(y));
    circle.setAttribute("r", "4");
    circle.setAttribute("fill", "none");
    circle.setAttribute("stroke", action === "FINISH" ? "#57efb2" : "#ffab52");
    circle.setAttribute("stroke-width", String(5 * this.layout.scale));
    this.effectsLayer.append(circle);
    circle.animate(
      [{ opacity: 1, transform: "scale(.25)", transformOrigin: `${x}px ${y}px` }, { opacity: 0, transform: "scale(1.4)", transformOrigin: `${x}px ${y}px` }],
      { duration: 300, easing: "ease-out" },
    ).finished.finally(() => circle.remove());
  }

  private scoreBurst(x: number, y: number): void {
    const text = svgElement("text");
    text.textContent = "+1";
    text.setAttribute("x", String(x));
    text.setAttribute("y", String(y));
    text.setAttribute("text-anchor", "middle");
    text.setAttribute("fill", "#57efb2");
    text.setAttribute("stroke", "#062118");
    text.setAttribute("stroke-width", "5");
    text.setAttribute("paint-order", "stroke fill");
    text.setAttribute("font-size", String(28 * this.layout.scale));
    text.setAttribute("font-weight", "1000");
    this.effectsLayer.append(text);
    text.animate(
      [{ opacity: 1, transform: "translateY(0) scale(.8)" }, { opacity: 0, transform: `translateY(${-55 * this.layout.scale}px) scale(1.15)` }],
      { duration: 600, easing: "ease-out" },
    ).finished.finally(() => text.remove());
  }

  private vibrate(pattern: number | number[]): void {
    if ("vibrate" in navigator) navigator.vibrate(pattern);
  }
}

window.addEventListener("DOMContentLoaded", () => {
  new VectorBurgerFactory();
});
