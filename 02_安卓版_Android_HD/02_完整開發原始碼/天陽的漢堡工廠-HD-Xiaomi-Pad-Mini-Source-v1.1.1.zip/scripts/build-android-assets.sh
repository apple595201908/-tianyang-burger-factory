#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ASSET_ROOT="$PROJECT_ROOT/android/app/src/main/assets/www"

mkdir -p "$ASSET_ROOT/audio" "$ASSET_ROOT/assets" "$ASSET_ROOT/icons"
cp "$PROJECT_ROOT/android-svg/index.html" "$ASSET_ROOT/index.html"
cp "$PROJECT_ROOT/android-svg/styles.css" "$ASSET_ROOT/styles.css"
cp "$PROJECT_ROOT/public/audio/"* "$ASSET_ROOT/audio/"
cp "$PROJECT_ROOT/public/icons/icon-192.png" "$ASSET_ROOT/icons/icon-192.png"
cp "$PROJECT_ROOT/public/assets/factory-bg-portrait-hd.webp" "$ASSET_ROOT/assets/factory-bg-portrait-hd.webp"
cp "$PROJECT_ROOT/public/assets/factory-bg-landscape-hd.webp" "$ASSET_ROOT/assets/factory-bg-landscape-hd.webp"

"$PROJECT_ROOT/node_modules/.bin/tsc" -p "$PROJECT_ROOT/tsconfig.android-svg.json"

for density in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  mkdir -p "$PROJECT_ROOT/android/app/src/main/res/mipmap-$density"
  cp "$PROJECT_ROOT/public/icons/icon-192.png" "$PROJECT_ROOT/android/app/src/main/res/mipmap-$density/ic_launcher.png"
done

if rg -n -i '<canvas|createElement.*canvas' "$PROJECT_ROOT/android-svg" "$ASSET_ROOT"; then
  echo "Canvas usage detected in the SVG/DOM Android build." >&2
  exit 1
fi

echo "Android SVG/DOM assets ready: $ASSET_ROOT"
