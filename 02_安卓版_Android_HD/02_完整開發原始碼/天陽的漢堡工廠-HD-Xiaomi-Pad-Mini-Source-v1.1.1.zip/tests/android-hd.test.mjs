import assert from "node:assert/strict";
import { readFile, stat } from "node:fs/promises";
import test from "node:test";

const root = new URL("../", import.meta.url);
const read = (path) => readFile(new URL(path, root), "utf8");

test("Android HD renderer uses SVG and never creates a Canvas", async () => {
  const [html, source, built] = await Promise.all([
    read("android-svg/index.html"),
    read("android-svg/src/game.ts"),
    read("android/app/src/main/assets/www/game.js"),
  ]);
  assert.match(html, /<svg[\s>]/i);
  assert.match(html, /id="factory-stage"/);
  assert.doesNotMatch(`${html}\n${source}\n${built}`, /<canvas|createElement\s*\([^)]*canvas/i);
  assert.doesNotMatch(source, /Phaser/);
});

test("Android HD build preserves the V1 split-touch and line-return contract", async () => {
  const source = await read("android-svg/src/game.ts");
  assert.match(source, /localX < rect\.width \* 0\.5 \? "FINISH" : "RETURN"/);
  assert.match(source, /candidate\.x -= shift/);
  assert.match(source, /food\.reworkSkips < 2/);
  assert.match(source, /food\.x > this\.layout\.deadlineX/);
  assert.match(source, /candidate\.element\.setAttribute\("visibility", "hidden"\)/);
});

test("Xiaomi Pad Mini receives a 3008x1880 tablet profile with safe spacing", async () => {
  const [source, styles, manifest, built] = await Promise.all([
    read("android-svg/src/game.ts"),
    read("android-svg/styles.css"),
    read("android/app/src/main/AndroidManifest.xml"),
    read("android/app/src/main/assets/www/game.js"),
  ]);
  assert.match(source, /PAD_MINI_LONG_PIXELS = 3008/);
  assert.match(source, /PAD_MINI_SHORT_PIXELS = 1880/);
  assert.match(source, /Xiaomi Pad Mini\|25079RPDCG/);
  assert.match(source, /profileOverride \|\| modelMatch \|\| resolutionMatch/);
  assert.match(source, /Math\.max\(BASE_GAP \* scale, tabletGap\)/);
  assert.match(source, /xiaomi-pad-mini-3008x1880/);
  assert.match(built, /xiaomi-pad-mini-3008x1880/);
  assert.match(styles, /\.tablet \.hud/);
  assert.match(styles, /\.xiaomi-pad-mini \.render-note/);
  assert.match(manifest, /android:xlargeScreens="true"/);
  const activity = await read("android/app/src/main/java/com/tianyang/burgerfactory/MainActivity.java");
  assert.match(activity, /index\.html\?profile=xiaomi-pad-mini/);

  const width = 1203.2;
  const height = 752;
  const scale = Math.min(1.72, Math.max(1.34, height / 430));
  const playerX = width * 0.65;
  const inspectorX = width * 0.88;
  const deadlineX = inspectorX + 54 * scale;
  const actionStartX = playerX - 52 * scale;
  const gap = Math.max(205 * scale, deadlineX - actionStartX + 18 * scale);
  assert.ok(gap > deadlineX - actionStartX, "adjacent burgers must not share the action window");
});

test("Android shell is offline-first and loads packaged web assets", async () => {
  const [manifest, activity] = await Promise.all([
    read("android/app/src/main/AndroidManifest.xml"),
    read("android/app/src/main/java/com/tianyang/burgerfactory/MainActivity.java"),
  ]);
  assert.doesNotMatch(manifest, /android\.permission\.INTERNET/);
  assert.match(activity, /file:\/\/\/android_asset\/www\/index\.html/);
  assert.match(activity, /setDomStorageEnabled\(true\)/);
});

test("Android package contains its HD backgrounds, audio, and compiled game", async () => {
  const requiredAssets = [
    "android/app/src/main/assets/www/game.js",
    "android/app/src/main/assets/www/styles.css",
    "android/app/src/main/assets/www/assets/factory-bg-portrait-hd.webp",
    "android/app/src/main/assets/www/assets/factory-bg-landscape-hd.webp",
    "android/app/src/main/assets/www/audio/factory-rush-bgm.mp3",
    "android/app/src/main/assets/www/audio/finish.wav",
    "android/app/src/main/assets/www/audio/return.wav",
  ];
  for (const asset of requiredAssets) {
    assert.ok((await stat(new URL(asset, root))).size > 0, `${asset} should not be empty`);
  }
});
