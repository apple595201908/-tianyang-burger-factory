import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://factory-rush-arcade.yoyo50582.chatgpt.site"),
  title: "天陽的漢堡工廠｜左完成・右退回",
  description: "一款為手機打造的高速食品分類反應遊戲：完整點左、缺料點右，一次失誤就結束。",
  applicationName: "天陽的漢堡工廠",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "天陽的漢堡工廠",
  },
  formatDetection: { telephone: false },
  icons: {
    icon: [
      { url: "/favicon.svg", type: "image/svg+xml" },
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" }],
  },
  openGraph: {
    title: "天陽的漢堡工廠｜左完成・右退回",
    description: "完整點左、缺料點右。挑戰高速地下食品工廠的品質分流紀錄。",
    url: "/",
    siteName: "天陽的漢堡工廠",
    locale: "zh_TW",
    type: "website",
    images: [
      {
        url: "/og.png",
        width: 1734,
        height: 907,
        alt: "天陽的漢堡工廠高速分類反應遊戲",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "天陽的漢堡工廠｜左完成・右退回",
    description: "完整點左、缺料點右。一次失誤，立即重試。",
    images: ["/og.png"],
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
  themeColor: "#071116",
  colorScheme: "dark",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-Hant">
      <body>{children}</body>
    </html>
  );
}
