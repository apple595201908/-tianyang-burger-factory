"use client";

import { useEffect, useRef, useState } from "react";
import type Phaser from "phaser";

export default function GameClient() {
  const hostRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Phaser.Game | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const preventGesture = (event: Event) => event.preventDefault();
    const preventTouchMove = (event: TouchEvent) => {
      if (event.cancelable) event.preventDefault();
    };
    document.addEventListener("gesturestart", preventGesture, { passive: false });
    document.addEventListener("gesturechange", preventGesture, { passive: false });
    document.addEventListener("touchmove", preventTouchMove, { passive: false });

    void import("@/src/main").then(({ createFactoryRushGame, registerFactoryRushServiceWorker }) => {
      if (cancelled || !hostRef.current || gameRef.current) return;
      gameRef.current = createFactoryRushGame(hostRef.current);
      registerFactoryRushServiceWorker();
      setReady(true);
    });

    return () => {
      cancelled = true;
      document.removeEventListener("gesturestart", preventGesture);
      document.removeEventListener("gesturechange", preventGesture);
      document.removeEventListener("touchmove", preventTouchMove);
      gameRef.current?.destroy(true);
      gameRef.current = null;
    };
  }, []);

  return (
    <main id="game-shell" aria-busy={!ready}>
      <div id="safe-area-probe" aria-hidden="true" />
      <div ref={hostRef} id="game-root" />
      {!ready && <div className="game-loading">產線啟動中…</div>}
      <p className="screen-reader-only">
        遊戲控制：材料完整時點擊整個畫面左半邊完成，缺少材料時點擊整個畫面右半邊退回。
      </p>
    </main>
  );
}

