import assert from "node:assert/strict";
import test from "node:test";

test("renders the 天陽的漢堡工廠 game shell and mobile metadata", async () => {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  const response = await worker.fetch(
    new Request("http://localhost/", {
      headers: { accept: "text/html" },
    }),
    {
      ASSETS: {
        fetch: async () => new Response("Not found", { status: 404 }),
      },
    },
    {
      waitUntil() {},
      passThroughOnException() {},
    },
  );

  assert.equal(response.status, 200);
  assert.match(
    response.headers.get("content-type") ?? "",
    /^text\/html\b/i,
  );
  const html = await response.text();
  assert.match(html, /<title>天陽的漢堡工廠[^<]*<\/title>/i);
  assert.match(html, /manifest\.webmanifest/i);
  assert.match(html, /property=["']og:image["']/i);
  assert.match(html, /factory-rush-arcade\.yoyo50582\.chatgpt\.site\/og\.png/i);
  assert.match(html, /id=["']game-shell["']/i);
  assert.doesNotMatch(html, /codex-preview/i);
});
