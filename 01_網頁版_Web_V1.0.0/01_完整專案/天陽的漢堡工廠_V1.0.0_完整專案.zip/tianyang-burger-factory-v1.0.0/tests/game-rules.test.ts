import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  evaluateGameplayAction,
  hasMissedDeadline,
  InputGate,
  orientationForSize,
  pickClosestActiveItem,
  returnOutfeedDisposition,
  splitActionForX,
  tutorialActionForCue,
} from "../src/game/rules/GameRules";
import { InputManager } from "../src/game/systems/InputManager";
import { DifficultyManager } from "../src/game/systems/DifficultyManager";
import { LineReturnController } from "../src/game/systems/LineReturnController";
import { SpawnManager } from "../src/game/systems/SpawnManager";
import { computeRenderScale } from "../src/game/rules/DisplayRules";
import { FoodState } from "../src/game/types/GameTypes";

describe("天陽的漢堡工廠 gameplay rules", () => {
  it("accepts FILLED + FINISH", () => {
    assert.equal(evaluateGameplayAction(FoodState.FILLED, "FINISH"), "SUCCESS");
  });

  it("accepts BASE_ONLY + RETURN", () => {
    assert.equal(evaluateGameplayAction(FoodState.BASE_ONLY, "RETURN"), "SUCCESS");
  });

  it("fails BASE_ONLY + FINISH", () => {
    assert.equal(evaluateGameplayAction(FoodState.BASE_ONLY, "FINISH"), "FAIL");
  });

  it("fails FILLED + RETURN", () => {
    assert.equal(evaluateGameplayAction(FoodState.FILLED, "RETURN"), "FAIL");
  });

  it("fails FILLED and BASE_ONLY after the deadline", () => {
    assert.equal(hasMissedDeadline(FoodState.FILLED, true, 301, 300), true);
    assert.equal(hasMissedDeadline(FoodState.BASE_ONLY, true, 301, 300), true);
  });

  it("does not fail an item before ingredient processing", () => {
    assert.equal(hasMissedDeadline(FoodState.BASE_ONLY, false, 500, 300), false);
  });

  it("maps every point in the left or right half consistently", () => {
    assert.equal(splitActionForX(1, 0, 390), "FINISH");
    assert.equal(splitActionForX(194.9, 0, 390), "FINISH");
    assert.equal(splitActionForX(195, 0, 390), "RETURN");
    assert.equal(splitActionForX(389, 0, 390), "RETURN");
    assert.equal(splitActionForX(421, 20, 802), "RETURN");
  });

  it("keeps the split and orientation correct for the required mobile viewports", () => {
    const portraitSizes = [
      [390, 844],
      [393, 852],
      [430, 932],
      [360, 800],
      [412, 915],
    ] as const;

    for (const [width, height] of portraitSizes) {
      assert.equal(orientationForSize(width, height), "portrait");
      for (const y of [1, height * 0.5, height - 1]) {
        assert.ok(y >= 0 && y <= height, "top, middle and bottom samples stay in the viewport");
        assert.equal(splitActionForX(width * 0.25, 0, width), "FINISH");
        assert.equal(splitActionForX(width * 0.75, 0, width), "RETURN");
      }

      assert.equal(orientationForSize(height, width), "landscape");
      assert.equal(splitActionForX(height * 0.25, 0, height), "FINISH");
      assert.equal(splitActionForX(height * 0.75, 0, height), "RETURN");
    }
  });

  it("uses full 3x rendering on modern phones while respecting the pixel budget", () => {
    assert.equal(computeRenderScale(3, 390, 844), 3);
    assert.equal(computeRenderScale(3, 430, 932), 3);
    assert.equal(computeRenderScale(2, 1024, 1366), 2);
    assert.ok(computeRenderScale(3, 2000, 1400) < 2);
  });

  it("ignores both actions when there is no active item", () => {
    assert.equal(pickClosestActiveItem([], 260, 205, 375), null);
    assert.equal(evaluateGameplayAction(FoodState.APPROVED, "FINISH"), "IGNORE");
    assert.equal(evaluateGameplayAction(FoodState.APPROVED, "RETURN"), "IGNORE");
  });

  it("only enables the requested half during hands-on tutorial actions", () => {
    assert.equal(tutorialActionForCue("FINISH_APPROACH"), null);
    assert.equal(tutorialActionForCue("FINISH_ACTION"), "FINISH");
    assert.equal(tutorialActionForCue("FINISH_SUCCESS"), null);
    assert.equal(tutorialActionForCue("RETURN_APPROACH"), null);
    assert.equal(tutorialActionForCue("RETURN_ACTION"), "RETURN");
    assert.equal(tutorialActionForCue("RETURN_REWORK"), null);
    assert.equal(tutorialActionForCue("DONE"), null);
  });

  it("removes or hides completed outfeed before a line return", () => {
    assert.equal(
      returnOutfeedDisposition(FoodState.CAPPED, false, 320, 260),
      "HIDE",
    );
    assert.equal(
      returnOutfeedDisposition(FoodState.APPROVED, true, 340, 260),
      "REMOVE",
    );
    assert.equal(
      returnOutfeedDisposition(FoodState.CAPPED, false, 240, 260),
      "KEEP",
    );
    assert.equal(
      returnOutfeedDisposition(FoodState.FILLED, false, 320, 260),
      "KEEP",
    );
  });

  it("chooses the actionable item closest to the player station", () => {
    const near = {
      x: 252,
      active: true,
      state: FoodState.FILLED,
      ingredientProcessed: true,
      id: "near",
    };
    const far = {
      x: 235,
      active: true,
      state: FoodState.BASE_ONLY,
      ingredientProcessed: true,
      id: "far",
    };
    assert.equal(pickClosestActiveItem([far, near], 260, 205, 375)?.id, "near");
  });

  it("keeps food actionable across the wider station-to-inspector zone", () => {
    const nearInspector = {
      x: 368,
      active: true,
      state: FoodState.BASE_ONLY,
      ingredientProcessed: true,
      id: "near-inspector",
    };
    assert.equal(
      pickClosestActiveItem([nearInspector], 260, 205, 375)?.id,
      "near-inspector",
    );
    assert.equal(hasMissedDeadline(FoodState.BASE_ONLY, true, 375, 375), false);
    assert.equal(hasMissedDeadline(FoodState.BASE_ONLY, true, 376, 375), true);
    assert.equal(pickClosestActiveItem([{ ...nearInspector, x: 376 }], 260, 205, 375), null);
  });

  it("accepts only the first simultaneous pointer", () => {
    const gate = new InputGate();
    assert.equal(gate.tryAccept(1, 1000, 42), true);
    assert.equal(gate.tryAccept(2, 1000, 42), false);
    gate.release(1);
    assert.equal(gate.tryAccept(2, 1020, 42), false);
    assert.equal(gate.tryAccept(2, 1042, 42), true);
  });

  it("marks a UI pointer as consumed before gameplay", () => {
    const pointer = { id: 7, downTime: 1234 } as Phaser.Input.Pointer;
    let stopped = false;
    InputManager.consumeUIEvent(pointer, {
      stopPropagation: () => {
        stopped = true;
      },
    } as Phaser.Types.Input.EventData);
    assert.equal(stopped, true);
    assert.equal(InputManager.isConsumed(pointer), true);
    InputManager.reset();
  });

  it("rewinds every active burger by the same distance", () => {
    const items = [
      { active: true, x: 10 },
      { active: true, x: 200 },
      { active: true, x: 390 },
      { active: true, x: 580 },
      { active: false, x: 900 },
    ];
    const originalGaps = [
      items[1].x - items[0].x,
      items[2].x - items[1].x,
      items[3].x - items[2].x,
    ];
    const controller = new LineReturnController<(typeof items)[number]>();

    assert.equal(controller.start(items[3], 200, 210), true);
    const first = controller.update(0.5, 380, items);
    assert.equal(first.shiftedDistance, 190);
    assert.equal(items[3].x, 390);
    assert.deepEqual(
      [items[1].x - items[0].x, items[2].x - items[1].x, items[3].x - items[2].x],
      originalGaps,
    );
    assert.equal(items[4].x, 900, "inactive pooled items do not move");

    const second = controller.update(0.5, 380, items);
    assert.equal(second.enteredRework, true);
    assert.equal(items[3].x, 200);
    assert.deepEqual(
      [items[1].x - items[0].x, items[2].x - items[1].x, items[3].x - items[2].x],
      originalGaps,
    );
    assert.equal(controller.phase, "REWORKING");
    assert.equal(controller.update(0.21, 380, items).completed, true);
    assert.equal(controller.active, false);
  });

  it("rewinds spawn progress so the next burger keeps the same gap", () => {
    const spawner = new SpawnManager();
    spawner.reset(false);
    assert.equal(spawner.update(1, 100, 190), null);
    spawner.rewind(80);
    assert.equal(spawner.update(0.9, 100, 190), null);
    assert.equal(spawner.update(0.8, 100, 190), 0);
  });

  it("preserves spawn overflow instead of accumulating frame-rate gap drift", () => {
    const spawner = new SpawnManager();
    spawner.reset(false);
    assert.equal(spawner.update(1, 100, 190), null);
    assert.equal(spawner.update(1, 100, 190), 10);
    assert.equal(spawner.update(1.8, 100, 190), 0);
  });

  it("makes skipped rework rare early and more frequent at high scores", () => {
    const difficulty = new DifficultyManager();
    assert.equal(difficulty.reworkSkipRateForScore(0), 0.05);
    assert.equal(difficulty.reworkSkipRateForScore(25).toFixed(2), "0.15");
    assert.equal(difficulty.reworkSkipRateForScore(100).toFixed(2), "0.45");
    assert.equal(difficulty.reworkSkipRateForScore(999), 0.62);

    assert.equal(difficulty.shouldSkipRework(0, 0, 0.04), true);
    assert.equal(difficulty.shouldSkipRework(0, 0, 0.06), false);
    assert.equal(difficulty.shouldSkipRework(100, 0, 0.4), true);
  });

  it("guarantees ingredients after two consecutive skipped reworks", () => {
    const difficulty = new DifficultyManager();
    assert.equal(difficulty.shouldSkipRework(999, 0, 0), true);
    assert.equal(difficulty.shouldSkipRework(999, 1, 0), true);
    assert.equal(difficulty.shouldSkipRework(999, 2, 0), false);
  });
});
