import * as Phaser from "phaser";

export const gameEvents = new Phaser.Events.EventEmitter();

export const GameEvents = Object.freeze({
  STATE_CHANGED: "state:changed",
  SCORE_CHANGED: "score:changed",
  TOUCH_FEEDBACK: "touch:feedback",
  TUTORIAL_STEP: "tutorial:step",
  TUTORIAL_NUDGE: "tutorial:nudge",
  COUNTDOWN: "countdown",
  SPEED_UP: "speed:up",
  GAME_OVER: "game:over",
  PAUSE_REQUEST: "pause:request",
  RESUME_REQUEST: "resume:request",
  RETRY_REQUEST: "retry:request",
  MENU_REQUEST: "menu:request",
  DEBUG_UPDATE: "debug:update",
});
