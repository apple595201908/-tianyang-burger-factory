import * as Phaser from "phaser";
import { ArtTheme } from "../art/ArtTheme";
import { GAME_NAME } from "../Branding";
import {
  AUDIO_ASSET_PATHS,
  AudioManager,
  type AudioAssetName,
} from "../systems/AudioManager";
import { DisplayManager } from "../systems/DisplayManager";

export class PreloadScene extends Phaser.Scene {
  private progressBar?: Phaser.GameObjects.Graphics;
  private progressGlow?: Phaser.GameObjects.Graphics;

  public constructor() {
    super("PreloadScene");
  }

  public preload(): void {
    const { width, height } = this.scale;
    this.cameras.main.setBackgroundColor(ArtTheme.colors.ink);
    const backdrop = this.add.graphics();
    backdrop.fillStyle(ArtTheme.colors.inkSoft, 1);
    backdrop.fillRect(0, 0, width, height);
    backdrop.fillStyle(ArtTheme.colors.panelLight, 0.5);
    backdrop.fillCircle(width * 0.5, height * 0.42, Math.min(width, height) * 0.34);

    const title = this.add
      .text(width * 0.5, height * 0.43, GAME_NAME, {
        fontFamily: ArtTheme.fonts.display,
        fontSize: "28px",
        fontStyle: "bold",
        color: "#ffe49a",
        stroke: "#071116",
        strokeThickness: 7,
      })
      .setOrigin(0.5);
    title.setScale(DisplayManager.renderScale);

    this.progressGlow = this.add.graphics();
    this.progressBar = this.add.graphics();
    this.drawProgress(width, height, 0);
    this.load.on(Phaser.Loader.Events.PROGRESS, (progress: number) => {
      this.drawProgress(width, height, progress);
    });

    this.load.image("factory-bg-portrait", "/assets/factory-bg-portrait-hd.webp");
    this.load.image("factory-bg-landscape", "/assets/factory-bg-landscape-hd.webp");
    for (const [name, path] of Object.entries(AUDIO_ASSET_PATHS)) {
      this.load.binary(`audio-${name}`, path);
    }
  }

  public create(): void {
    for (const name of Object.keys(AUDIO_ASSET_PATHS) as AudioAssetName[]) {
      const encoded = this.cache.binary.get(`audio-${name}`) as ArrayBuffer | undefined;
      if (encoded) AudioManager.shared.registerEncodedAsset(name, encoded);
    }
    DisplayManager.sharpenActiveText(this.game);
    this.time.delayedCall(90, () => this.scene.start("MenuScene"));
  }

  private drawProgress(width: number, height: number, progress: number): void {
    const barWidth = Math.min(width * 0.54, 290 * DisplayManager.renderScale);
    const barHeight = 8 * DisplayManager.renderScale;
    const x = width * 0.5 - barWidth * 0.5;
    const y = height * 0.51;
    this.progressGlow?.clear();
    this.progressGlow?.fillStyle(ArtTheme.colors.amber, 0.14);
    this.progressGlow?.fillRoundedRect(
      x - 5 * DisplayManager.renderScale,
      y - 5 * DisplayManager.renderScale,
      barWidth + 10 * DisplayManager.renderScale,
      barHeight + 10 * DisplayManager.renderScale,
      9 * DisplayManager.renderScale,
    );
    this.progressBar?.clear();
    this.progressBar?.fillStyle(0x09171d, 0.92);
    this.progressBar?.fillRoundedRect(x, y, barWidth, barHeight, barHeight * 0.5);
    this.progressBar?.fillStyle(ArtTheme.colors.amberLight, 1);
    this.progressBar?.fillRoundedRect(
      x,
      y,
      Math.max(barHeight, barWidth * Phaser.Math.Clamp(progress, 0, 1)),
      barHeight,
      barHeight * 0.5,
    );
  }
}
