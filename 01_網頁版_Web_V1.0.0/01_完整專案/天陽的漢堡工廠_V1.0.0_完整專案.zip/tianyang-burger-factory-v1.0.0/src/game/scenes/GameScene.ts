import * as Phaser from "phaser";
import { ArtTheme } from "../art/ArtTheme";
import { GameEvents, gameEvents } from "../core/EventBus";
import { Conveyor } from "../entities/Conveyor";
import { FactoryBackdrop } from "../entities/FactoryBackdrop";
import { FoodItem } from "../entities/FoodItem";
import { Inspector } from "../entities/Inspector";
import { Worker } from "../entities/Worker";
import { GameTuning } from "../GameTuning";
import {
  evaluateGameplayAction,
  hasMissedDeadline,
  pickClosestActiveItem,
  returnOutfeedDisposition,
  tutorialActionForCue,
} from "../rules/GameRules";
import { AudioManager } from "../systems/AudioManager";
import { DifficultyManager } from "../systems/DifficultyManager";
import { DisplayManager } from "../systems/DisplayManager";
import { InputManager } from "../systems/InputManager";
import { LayoutManager } from "../systems/LayoutManager";
import { LineReturnController } from "../systems/LineReturnController";
import { LifecycleManager } from "../systems/LifecycleManager";
import { ScoreManager } from "../systems/ScoreManager";
import { SeededRng } from "../systems/SeededRng";
import { SpawnManager } from "../systems/SpawnManager";
import { SplitTouchController } from "../systems/SplitTouchController";
import { StorageManager } from "../systems/StorageManager";
import {
  FoodState,
  GameState,
  type DebugSnapshot,
  type FailureReason,
  type GameLayout,
  type GameplayAction,
  type TutorialCue,
} from "../types/GameTypes";

interface GameSceneData {
  forceSkipTutorial?: boolean;
}

export class GameScene extends Phaser.Scene {
  private state = GameState.COUNTDOWN;
  private stateBeforePause = GameState.PLAYING;
  private layout!: GameLayout;
  private previousWidth = 0;
  private forceSkipTutorial = false;

  private backdrop!: FactoryBackdrop;
  private background!: Phaser.GameObjects.Graphics;
  private stationGraphics!: Phaser.GameObjects.Graphics;
  private conveyor!: Conveyor;
  private baseWorker!: Worker;
  private ingredientWorker!: Worker;
  private playerWorker!: Worker;
  private inspector!: Inspector;
  private items: FoodItem[] = [];

  private readonly difficulty = new DifficultyManager();
  private readonly score = new ScoreManager();
  private readonly spawner = new SpawnManager();
  private readonly lineReturn = new LineReturnController<FoodItem>();
  private rng!: SeededRng;
  private splitController!: SplitTouchController;
  private lifecycle!: LifecycleManager;

  private tutorialCue: TutorialCue | null = null;
  private tutorialItem: FoodItem | null = null;
  private countdownIndex = 0;
  private countdownElapsed = 0;
  private debugElapsed = 0;
  private returnCompletesTutorial = false;

  public constructor() {
    super("GameScene");
  }

  public init(data: GameSceneData): void {
    this.forceSkipTutorial = Boolean(data.forceSkipTutorial);
  }

  public create(): void {
    InputManager.reset();
    this.layout = LayoutManager.refresh(this.scale.width, this.scale.height);
    this.previousWidth = this.layout.width;
    this.rng = new SeededRng(this.readSeed());
    this.backdrop = new FactoryBackdrop(this);
    this.background = this.add.graphics().setDepth(1);
    this.stationGraphics = this.add.graphics().setDepth(11);
    this.conveyor = new Conveyor(this);
    this.baseWorker = new Worker(this, "BASE", 0x5bb8a6);
    this.ingredientWorker = new Worker(this, "INGREDIENT", 0xe66e6e);
    this.playerWorker = new Worker(this, "PLAYER", 0xf0a14a);
    this.inspector = new Inspector(this);
    this.items = Array.from(
      { length: GameTuning.FOOD_POOL_SIZE },
      () => new FoodItem(this),
    );
    this.applyLayout(this.layout);

    this.splitController = new SplitTouchController(this, {
      getState: () => this.state,
      hasActiveItem: () => this.getActiveItem() !== null,
      dispatch: (action, pointer) => this.dispatchAction(action, pointer),
    });
    this.splitController.enable();
    this.lifecycle = new LifecycleManager(this, {
      suspend: () => this.requestPause("lifecycle"),
      resize: (width, height) => this.handleResize(width, height),
    });

    gameEvents.on(GameEvents.PAUSE_REQUEST, this.requestPause, this);
    gameEvents.on(GameEvents.RESUME_REQUEST, this.resumeGame, this);
    gameEvents.on(GameEvents.RETRY_REQUEST, this.retryGame, this);
    gameEvents.on(GameEvents.MENU_REQUEST, this.returnToMenu, this);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, this.shutdown, this);

    this.scene.launch("UIScene");
    this.scene.bringToTop("UIScene");
    DisplayManager.sharpenActiveText(this.game);
    this.time.delayedCall(0, () => {
      gameEvents.emit(GameEvents.SCORE_CHANGED, 0, this.score.best);
      const needsTutorial = !StorageManager.get().tutorialCompleted && !this.forceSkipTutorial;
      if (needsTutorial) this.beginTutorial();
      else this.beginCountdown();
    });
  }

  public update(_time: number, delta: number): void {
    const clampedDelta = Math.min(delta, 50);
    this.backdrop.updateAtmosphere(this.time.now);
    if (this.state === GameState.COUNTDOWN) {
      this.updateCountdown(clampedDelta);
    } else if (this.state === GameState.TUTORIAL) {
      if (this.lineReturn.active) this.updateLineReturn(clampedDelta / 1000);
      else this.updateTutorial(clampedDelta);
    } else if (this.state === GameState.PLAYING) {
      this.updateGameplay(clampedDelta);
    }

    this.updateDebug(clampedDelta);
  }

  private updateGameplay(deltaMs: number): void {
    const deltaSeconds = deltaMs / 1000;
    if (this.lineReturn.active) {
      this.updateLineReturn(deltaSeconds);
      return;
    }

    const speed = this.currentConveyorSpeed();
    this.conveyor.updateBelt(deltaSeconds, speed);

    for (const item of this.items) {
      if (!item.active) continue;
      item.updateMotion(deltaSeconds, speed, this.layout);

      if (item.state === FoodState.SPAWNED && item.x >= this.layout.baseWorkerX) {
        item.setFoodState(FoodState.BASE_ONLY);
        this.baseWorker.playWork();
      }

      if (
        item.state === FoodState.BASE_ONLY &&
        !item.ingredientProcessed &&
        item.x >= this.layout.ingredientWorkerX
      ) {
        const defective = this.rng.chance(GameTuning.DEFECT_RATE);
        item.markIngredientProcessed(defective);
        if (defective) this.ingredientWorker.playBored();
        else this.ingredientWorker.playWork();
      }

      if (
        hasMissedDeadline(
          item.state,
          item.ingredientProcessed,
          item.x,
          this.layout.deadlineX,
        )
      ) {
        this.gameOver("MISSED_DEADLINE", item);
        return;
      }

      if (
        item.state === FoodState.CAPPED &&
        !item.inspected &&
        item.x >= this.layout.inspectorX
      ) {
        const hiddenOutfeed = item.isOutfeedHidden;
        item.inspected = true;
        item.setFoodState(FoodState.INSPECTION);
        this.inspector.approve(item.x, item.y, this.layout.uiScale);
        item.setFoodState(FoodState.APPROVED);
        AudioManager.shared.play("approved");
        const newScore = this.score.increment();
        gameEvents.emit(GameEvents.SCORE_CHANGED, newScore, this.score.best);
        if (this.difficulty.isSpeedMilestone(newScore)) {
          AudioManager.shared.play("speedup");
          gameEvents.emit(GameEvents.SPEED_UP);
        }
        if (hiddenOutfeed) {
          item.deactivate();
        } else {
          this.time.delayedCall(GameTuning.APPROVED_EXIT_MS, () => {
            if (item.active && item.state === FoodState.APPROVED) item.deactivate();
          });
        }
      }

      if (item.x > this.layout.width + 100 * this.layout.uiScale) {
        item.deactivate();
      }
    }

    const spawnOverflow = this.spawner.update(
      deltaSeconds,
      speed * this.layout.motionScale,
      this.layout.spawnGap,
    );
    if (spawnOverflow !== null) this.spawnFood(spawnOverflow);
  }

  private spawnFood(spawnOverflow = 0): void {
    const item = this.items.find((candidate) => !candidate.active);
    if (!item) return;
    item.activateAt(
      this.layout.spawnX + spawnOverflow,
      this.layout.conveyorY,
      this.layout.uiScale,
    );
  }

  private getActiveItem(): FoodItem | null {
    if (this.lineReturn.active) return null;
    if (this.state === GameState.TUTORIAL && !tutorialActionForCue(this.tutorialCue)) {
      return null;
    }
    return pickClosestActiveItem(
      this.items,
      this.layout.playerStationX,
      this.layout.actionStartX,
      this.layout.actionEndX,
    );
  }

  private dispatchAction(
    action: GameplayAction,
    pointer: Phaser.Input.Pointer,
  ): void {
    const item = this.getActiveItem();
    if (!item) return;

    if (this.state === GameState.TUTORIAL) {
      const expectedAction = tutorialActionForCue(this.tutorialCue);
      if (!expectedAction) return;
      if (action !== expectedAction) {
        gameEvents.emit(GameEvents.TUTORIAL_NUDGE, expectedAction);
        AudioManager.shared.play("button");
        navigator.vibrate?.(7);
        return;
      }
      this.emitTouchFeedback(action, pointer);
      if (action === "FINISH") {
        item.finish();
        this.playerWorker.playWork();
        AudioManager.shared.play("finish");
        this.setTutorialCue("FINISH_SUCCESS");
        this.time.delayedCall(GameTuning.TUTORIAL_SUCCESS_MS, () => {
          if (this.state === GameState.TUTORIAL) this.beginTutorialScenario("RETURN");
        });
      } else {
        if (this.beginLineReturn(item, true)) {
          this.setTutorialCue("RETURN_REWORK");
          this.playerWorker.playWork();
          AudioManager.shared.play("return");
        }
      }
      return;
    }

    if (this.state !== GameState.PLAYING) return;
    const result = evaluateGameplayAction(item.state, action);
    if (result === "IGNORE") return;
    this.emitTouchFeedback(action, pointer);
    if (result === "FAIL") {
      this.gameOver(action === "FINISH" ? "WRONG_FINISH" : "WRONG_RETURN", item);
      return;
    }

    this.playerWorker.playWork();
    if (action === "FINISH") {
      item.finish();
      AudioManager.shared.play("finish");
    } else {
      if (this.beginLineReturn(item, false)) AudioManager.shared.play("return");
    }
    navigator.vibrate?.(12);
  }

  private emitTouchFeedback(
    action: GameplayAction,
    pointer: Phaser.Input.Pointer,
  ): void {
    gameEvents.emit(GameEvents.TOUCH_FEEDBACK, {
      action,
      x: pointer.x,
      y: pointer.y,
    });
  }

  private beginLineReturn(item: FoodItem, completesTutorial: boolean): boolean {
    if (
      !this.lineReturn.start(
        item,
        this.layout.ingredientWorkerX,
        GameTuning.REWORK_MS,
      )
    ) {
      return false;
    }

    this.returnCompletesTutorial = completesTutorial;
    this.prepareOutfeedForReturn(item);
    item.startReturn();
    return true;
  }

  private prepareOutfeedForReturn(returningItem: FoodItem): void {
    for (const item of this.items) {
      if (!item.active || item === returningItem) continue;
      const disposition = returnOutfeedDisposition(
        item.state,
        item.inspected,
        item.x,
        this.layout.playerStationX,
      );
      if (disposition === "REMOVE") item.deactivate();
      else if (disposition === "HIDE") item.hideCompletedOutfeed();
    }
  }

  private updateLineReturn(deltaSeconds: number): void {
    const conveyorSpeed = this.currentConveyorSpeed();
    const result = this.lineReturn.update(
      deltaSeconds,
      conveyorSpeed * this.layout.motionScale,
      this.items,
    );

    if (result.shiftedDistance > 0) {
      this.conveyor.moveBeltBy(-result.shiftedDistance);
      this.spawner.rewind(result.shiftedDistance);
      for (const item of this.items) {
        if (item.active) {
          item.y = this.layout.conveyorY - 9 * this.layout.uiScale;
        }
      }
    }

    if (result.enteredRework && result.target) {
      result.target.beginRework();
      this.ingredientWorker.playWork();
    }

    if (result.completed && result.target) {
      const completesTutorial = this.returnCompletesTutorial;
      this.returnCompletesTutorial = false;
      const skipsRework =
        !completesTutorial &&
        this.difficulty.shouldSkipRework(
          this.score.score,
          result.target.reworkSkipCount,
          this.rng.next(),
        );

      if (skipsRework) {
        result.target.skipRework();
        this.ingredientWorker.playBored();
      } else {
        result.target.completeRework();
        this.ingredientWorker.playWork();
        if (completesTutorial) this.completeTutorial(result.target);
      }
    }
  }

  private currentConveyorSpeed(): number {
    return this.difficulty.speedForScore(this.score.score);
  }

  private updateTutorial(deltaMs: number): void {
    const item = this.tutorialItem;
    const cue = this.tutorialCue;
    if (!item?.active || !cue) return;
    const moving =
      cue === "FINISH_APPROACH" ||
      cue === "FINISH_ACTION" ||
      cue === "RETURN_APPROACH" ||
      cue === "RETURN_ACTION";
    if (!moving) return;

    const deltaSeconds = deltaMs / 1000;
    const speed = GameTuning.TUTORIAL_SPEED;
    if (item.x < this.layout.playerStationX) {
      item.x = Math.min(
        this.layout.playerStationX,
        item.x + speed * this.layout.motionScale * deltaSeconds,
      );
      item.y = this.layout.conveyorY - 9 * this.layout.uiScale;
      this.conveyor.updateBelt(deltaSeconds, speed);
    }

    if (cue === "FINISH_APPROACH" && item.x >= this.layout.actionStartX) {
      this.setTutorialCue("FINISH_ACTION");
    } else if (cue === "RETURN_APPROACH" && item.x >= this.layout.actionStartX) {
      this.setTutorialCue("RETURN_ACTION");
    }
  }

  private beginTutorial(): void {
    this.resetRun();
    this.setState(GameState.TUTORIAL);
    this.beginTutorialScenario("FINISH");
  }

  private beginTutorialScenario(action: GameplayAction): void {
    if (this.state !== GameState.TUTORIAL) return;
    this.tutorialItem?.deactivate();
    const item = this.items[0];
    item.activateAt(
      this.layout.ingredientWorkerX,
      this.layout.conveyorY,
      this.layout.uiScale,
    );
    const defective = action === "RETURN";
    item.markIngredientProcessed(defective);
    this.tutorialItem = item;
    if (defective) this.ingredientWorker.playBored();
    else this.ingredientWorker.playWork();
    this.setTutorialCue(defective ? "RETURN_APPROACH" : "FINISH_APPROACH");
  }

  private completeTutorial(item: FoodItem): void {
    if (this.state !== GameState.TUTORIAL) return;
    this.setTutorialCue("RETURN_SUCCESS");
    this.time.delayedCall(GameTuning.TUTORIAL_SUCCESS_MS, () => {
      if (this.state !== GameState.TUTORIAL || this.tutorialCue !== "RETURN_SUCCESS") {
        return;
      }
      item.deactivate();
      StorageManager.completeTutorial();
      this.setTutorialCue("DONE");
      this.beginCountdown();
    });
  }

  private setTutorialCue(cue: TutorialCue): void {
    this.tutorialCue = cue;
    gameEvents.emit(GameEvents.TUTORIAL_STEP, cue);
  }

  private beginCountdown(): void {
    this.resetRun();
    this.setState(GameState.COUNTDOWN);
    this.countdownIndex = 0;
    this.countdownElapsed = 0;
    gameEvents.emit(GameEvents.COUNTDOWN, "3");
  }

  private updateCountdown(deltaMs: number): void {
    this.countdownElapsed += deltaMs;
    if (this.countdownElapsed < GameTuning.COUNTDOWN_STEP_MS) return;
    this.countdownElapsed -= GameTuning.COUNTDOWN_STEP_MS;
    this.countdownIndex += 1;
    const values = ["3", "2", "1", "GO!"];
    if (this.countdownIndex < values.length) {
      gameEvents.emit(GameEvents.COUNTDOWN, values[this.countdownIndex]);
      return;
    }
    gameEvents.emit(GameEvents.COUNTDOWN, "");
    this.startPlaying();
  }

  private startPlaying(): void {
    this.setState(GameState.PLAYING);
    this.spawner.reset(true);
    AudioManager.shared.startBgm();
  }

  private resetRun(): void {
    this.score.reset();
    this.spawner.reset(true);
    this.lineReturn.reset();
    this.returnCompletesTutorial = false;
    this.tutorialCue = null;
    this.tutorialItem = null;
    this.splitController?.reset();
    this.items.forEach((item) => item.deactivate());
    this.tweens.killAll();
    gameEvents.emit(GameEvents.SCORE_CHANGED, 0, this.score.best);
  }

  private gameOver(reason: FailureReason, item: FoodItem): void {
    if (this.state !== GameState.PLAYING) return;
    item.fail();
    this.playerWorker.playFail();
    this.setState(GameState.GAME_OVER);
    AudioManager.shared.stopBgm();
    AudioManager.shared.play("fail");
    navigator.vibrate?.([24, 32, 24]);
    gameEvents.emit(GameEvents.GAME_OVER, {
      score: this.score.score,
      best: this.score.best,
      isNewBest: this.score.isNewBest,
      reason,
    });
  }

  private requestPause(source: "manual" | "lifecycle" = "manual"): void {
    if (
      this.state !== GameState.PLAYING &&
      this.state !== GameState.COUNTDOWN &&
      this.state !== GameState.TUTORIAL
    ) {
      return;
    }
    void source;
    this.stateBeforePause = this.state;
    this.state = GameState.PAUSED;
    this.splitController.reset();
    this.time.paused = true;
    this.tweens.pauseAll();
    AudioManager.shared.stopBgm();
    gameEvents.emit(GameEvents.STATE_CHANGED, GameState.PAUSED);
  }

  private async resumeGame(): Promise<void> {
    if (this.state !== GameState.PAUSED) return;
    await AudioManager.shared.unlock();
    if (this.state !== GameState.PAUSED) return;
    const resumeState = this.stateBeforePause;
    this.time.paused = false;
    this.tweens.resumeAll();
    this.splitController.reset();
    this.setState(resumeState);
    if (resumeState === GameState.PLAYING) AudioManager.shared.startBgm();
  }

  private retryGame(): void {
    if (this.state !== GameState.GAME_OVER) return;
    this.scene.stop("UIScene");
    this.scene.restart({ forceSkipTutorial: true });
  }

  private returnToMenu(): void {
    AudioManager.shared.stopBgm();
    this.scene.stop("UIScene");
    this.scene.start("MenuScene");
  }

  private setState(state: GameState): void {
    this.state = state;
    gameEvents.emit(GameEvents.STATE_CHANGED, state);
  }

  private handleResize(width: number, height: number): void {
    if (width <= 0 || height <= 0) return;
    const previousSpawnGap = this.layout.spawnGap;
    const next = LayoutManager.refresh(width, height);
    const oldWidth = this.previousWidth;
    this.previousWidth = next.width;
    this.applyLayout(next);
    this.items.forEach((item) => item.rescale(next, oldWidth));
    this.lineReturn.setDestination(next.ingredientWorkerX);
    this.spawner.rescaleProgress(next.spawnGap / previousSpawnGap);
    this.layout = next;
  }

  private applyLayout(layout: GameLayout): void {
    this.layout = layout;
    this.backdrop.applyLayout(layout);
    this.drawFactory(layout);
    this.conveyor.applyLayout(layout);
    this.baseWorker.place(
      layout.baseWorkerX,
      layout.workerTopY,
      layout.uiScale * 0.78,
      true,
    );
    this.ingredientWorker.place(
      layout.ingredientWorkerX,
      layout.workerTopY,
      layout.uiScale * 0.78,
      true,
    );
    this.playerWorker.place(
      layout.playerStationX,
      layout.workerBottomY,
      layout.uiScale * 0.82,
      true,
    );
    this.inspector.place(
      layout.inspectorX,
      layout.workerTopY,
      layout.uiScale * 0.72,
      true,
    );
  }

  private drawFactory(layout: GameLayout): void {
    const { width, height, uiScale, conveyorY } = layout;
    this.background.clear();
    this.background.fillStyle(ArtTheme.colors.ink, 0.24);
    this.background.fillRect(0, conveyorY + 84 * uiScale, width, height);
    this.background.fillStyle(ArtTheme.colors.cyan, 0.024);
    this.background.fillEllipse(width * 0.5, conveyorY, width * 0.88, 260 * uiScale);
    this.background.lineStyle(2 * uiScale, ArtTheme.colors.steelLight, 0.14);
    this.background.lineBetween(0, conveyorY + 91 * uiScale, width, conveyorY + 91 * uiScale);

    this.stationGraphics.clear();
    this.drawStationMarker(layout.baseWorkerX, conveyorY, 0x5bb8a6, uiScale);
    this.drawStationMarker(layout.ingredientWorkerX, conveyorY, 0xe66e6e, uiScale);
    this.drawStationMarker(layout.playerStationX, conveyorY, 0xffc857, uiScale);
    this.drawStationMarker(layout.inspectorX, conveyorY, 0x9d77d8, uiScale);
  }

  private drawStationMarker(
    x: number,
    y: number,
    color: number,
    scale: number,
  ): void {
    this.stationGraphics.fillStyle(ArtTheme.colors.ink, 0.48);
    this.stationGraphics.fillEllipse(x, y + 42 * scale, 66 * scale, 18 * scale);
    this.stationGraphics.fillStyle(color, 0.2);
    this.stationGraphics.fillEllipse(x, y + 40 * scale, 56 * scale, 13 * scale);
    this.stationGraphics.lineStyle(2.5 * scale, color, 0.82);
    this.stationGraphics.strokeEllipse(x, y + 40 * scale, 46 * scale, 10 * scale);
    this.stationGraphics.fillStyle(color, 0.92);
    this.stationGraphics.fillRoundedRect(
      x - 12 * scale,
      y + 37 * scale,
      24 * scale,
      6 * scale,
      3 * scale,
    );
  }

  private updateDebug(deltaMs: number): void {
    const debug = new URLSearchParams(window.location.search).get("debug") === "1";
    if (!debug) return;
    this.debugElapsed += deltaMs;
    if (this.debugElapsed < GameTuning.DEBUG_REFRESH_MS) return;
    this.debugElapsed = 0;
    const speed = this.difficulty.speedForScore(this.score.score);
    const active = this.getActiveItem();
    const snapshot: DebugSnapshot = {
      fps: this.game.loop.actualFps,
      width: this.layout.width,
      height: this.layout.height,
      dpr: DisplayManager.renderScale,
      orientation: this.layout.orientation,
      speed,
      score: this.score.score,
      spawnInterval:
        (this.layout.spawnGap / (speed * this.layout.motionScale)) * 1000,
      defectRate: GameTuning.DEFECT_RATE,
      reworkSkipRate: this.difficulty.reworkSkipRateForScore(this.score.score),
      activeItem: active ? `${active.itemId}:${active.state}` : "NONE",
      entityCount: this.items.filter((item) => item.active).length,
      touchState: this.splitController.describe(),
      playerStationX: this.layout.playerStationX,
      deadlineX: this.layout.deadlineX,
      actionStartX: this.layout.actionStartX,
      actionEndX: this.layout.actionEndX,
      safeArea: this.layout.safeArea,
    };
    gameEvents.emit(GameEvents.DEBUG_UPDATE, snapshot);
  }

  private readSeed(): number | undefined {
    const value = new URLSearchParams(window.location.search).get("seed");
    if (!value) return undefined;
    const seed = Number.parseInt(value, 10);
    return Number.isFinite(seed) ? seed : undefined;
  }

  private shutdown(): void {
    this.time.paused = false;
    this.time.removeAllEvents();
    this.tweens.killAll();
    this.splitController?.destroy();
    this.lifecycle?.destroy();
    AudioManager.shared.stopBgm();
    gameEvents.off(GameEvents.PAUSE_REQUEST, this.requestPause, this);
    gameEvents.off(GameEvents.RESUME_REQUEST, this.resumeGame, this);
    gameEvents.off(GameEvents.RETRY_REQUEST, this.retryGame, this);
    gameEvents.off(GameEvents.MENU_REQUEST, this.returnToMenu, this);
  }
}
