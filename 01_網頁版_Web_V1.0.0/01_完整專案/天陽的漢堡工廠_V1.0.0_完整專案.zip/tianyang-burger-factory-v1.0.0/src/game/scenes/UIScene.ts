import * as Phaser from "phaser";
import { ArtTheme } from "../art/ArtTheme";
import { GameEvents, gameEvents } from "../core/EventBus";
import { AudioManager } from "../systems/AudioManager";
import { DisplayManager } from "../systems/DisplayManager";
import { LayoutManager } from "../systems/LayoutManager";
import type {
  DebugSnapshot,
  FailureReason,
  GameLayout,
  GameplayAction,
  TutorialCue,
} from "../types/GameTypes";
import { GameState } from "../types/GameTypes";
import { GameOverPanel } from "../ui/GameOverPanel";
import { PauseOverlay } from "../ui/PauseOverlay";
import { ScoreHUD } from "../ui/ScoreHUD";
import { TouchFeedback } from "../ui/TouchFeedback";

interface TouchPayload {
  action: GameplayAction;
  x: number;
  y: number;
}

interface GameOverPayload {
  score: number;
  best: number;
  isNewBest: boolean;
  reason: FailureReason;
}

export class UIScene extends Phaser.Scene {
  private hud!: ScoreHUD;
  private touchFeedback!: TouchFeedback;
  private pauseOverlay!: PauseOverlay;
  private gameOverPanel!: GameOverPanel;
  private tutorialShade!: Phaser.GameObjects.Rectangle;
  private tutorialGuide!: Phaser.GameObjects.Graphics;
  private tutorialPanel!: Phaser.GameObjects.Graphics;
  private tutorialProgress!: Phaser.GameObjects.Text;
  private tutorialTitle!: Phaser.GameObjects.Text;
  private tutorialBody!: Phaser.GameObjects.Text;
  private tutorialSideLabel!: Phaser.GameObjects.Text;
  private countdownBadge!: Phaser.GameObjects.Graphics;
  private countdown!: Phaser.GameObjects.Text;
  private speedUpPlate!: Phaser.GameObjects.Graphics;
  private speedUp!: Phaser.GameObjects.Text;
  private debugGraphics!: Phaser.GameObjects.Graphics;
  private debugText!: Phaser.GameObjects.Text;
  private currentLayout!: GameLayout;
  private currentTutorialCue: TutorialCue | null = null;
  private readonly debugEnabled =
    typeof window !== "undefined" && new URLSearchParams(window.location.search).get("debug") === "1";

  public constructor() {
    super("UIScene");
  }

  public create(): void {
    this.currentLayout = LayoutManager.current;
    this.hud = new ScoreHUD(
      this,
      () => gameEvents.emit(GameEvents.PAUSE_REQUEST, "manual"),
      () => {
        const muted = AudioManager.shared.toggleMute();
        this.hud.updateMute(muted);
      },
    );
    this.hud.updateMute(AudioManager.shared.isMuted);
    this.touchFeedback = new TouchFeedback(this);
    this.pauseOverlay = new PauseOverlay(
      this,
      () => gameEvents.emit(GameEvents.RESUME_REQUEST),
      () => gameEvents.emit(GameEvents.MENU_REQUEST),
    );
    this.gameOverPanel = new GameOverPanel(
      this,
      () => gameEvents.emit(GameEvents.RETRY_REQUEST),
      () => gameEvents.emit(GameEvents.MENU_REQUEST),
    );
    this.tutorialShade = this.add
      .rectangle(0, 0, 10, 10, 0xffd166, 0)
      .setOrigin(0)
      .setDepth(120);
    this.tutorialGuide = this.add.graphics().setDepth(121).setVisible(false);
    this.tutorialPanel = this.add.graphics().setDepth(122).setVisible(false);
    this.tutorialProgress = this.add
      .text(0, 0, "", {
        fontFamily: ArtTheme.fonts.rounded,
        fontSize: "13px",
        fontStyle: "bold",
        color: "#9fb7be",
        letterSpacing: 1,
      })
      .setOrigin(0.5)
      .setDepth(123)
      .setVisible(false);
    this.tutorialTitle = this.add
      .text(0, 0, "", {
        fontFamily: ArtTheme.fonts.display,
        fontSize: "23px",
        fontStyle: "bold",
        color: "#ffe49a",
        align: "center",
        stroke: "#071116",
        strokeThickness: 4,
      })
      .setOrigin(0.5)
      .setDepth(123)
      .setVisible(false);
    this.tutorialBody = this.add
      .text(0, 0, "", {
        fontFamily: ArtTheme.fonts.rounded,
        fontSize: "16px",
        fontStyle: "bold",
        color: "#e7f0f3",
        align: "center",
        lineSpacing: 5,
      })
      .setOrigin(0.5)
      .setDepth(123)
      .setVisible(false);
    this.tutorialSideLabel = this.add
      .text(0, 0, "", {
        fontFamily: ArtTheme.fonts.display,
        fontSize: "20px",
        fontStyle: "bold",
        color: "#fff4d2",
        align: "center",
        lineSpacing: 3,
        stroke: "#071116",
        strokeThickness: 5,
      })
      .setOrigin(0.5)
      .setDepth(124)
      .setVisible(false);
    this.countdownBadge = this.add.graphics().setDepth(159).setVisible(false);
    this.countdownBadge.fillStyle(ArtTheme.colors.ink, 0.72);
    this.countdownBadge.fillCircle(0, 0, 59);
    this.countdownBadge.lineStyle(4, ArtTheme.colors.amber, 0.92);
    this.countdownBadge.fillStyle(ArtTheme.colors.panel, 0.92);
    this.countdownBadge.fillCircle(0, 0, 51);
    this.countdownBadge.strokeCircle(0, 0, 51);
    this.countdownBadge.lineStyle(2, ArtTheme.colors.steelLight, 0.38);
    this.countdownBadge.strokeCircle(0, 0, 42);
    for (let angle = 0; angle < 360; angle += 45) {
      const radians = Phaser.Math.DegToRad(angle);
      this.countdownBadge.fillStyle(ArtTheme.colors.amberLight, 0.78);
      this.countdownBadge.fillCircle(Math.cos(radians) * 45, Math.sin(radians) * 45, 2);
    }
    this.countdown = this.add
      .text(0, 0, "", {
        fontFamily: ArtTheme.fonts.display,
        fontSize: "74px",
        fontStyle: "bold",
        color: "#ffdc72",
        stroke: "#071015",
        strokeThickness: 10,
      })
      .setOrigin(0.5)
      .setDepth(160)
      .setVisible(false);
    this.speedUpPlate = this.add.graphics().setDepth(154).setVisible(false);
    this.speedUpPlate.fillStyle(ArtTheme.colors.ink, 0.52);
    this.speedUpPlate.fillRoundedRect(-107, -24, 214, 54, 16);
    this.speedUpPlate.lineStyle(2.5, ArtTheme.colors.cyan, 0.75);
    this.speedUpPlate.fillStyle(ArtTheme.colors.panel, 0.92);
    this.speedUpPlate.fillRoundedRect(-107, -28, 214, 54, 16);
    this.speedUpPlate.strokeRoundedRect(-107, -28, 214, 54, 16);
    this.speedUpPlate.fillStyle(ArtTheme.colors.cyan, 0.18);
    this.speedUpPlate.fillRoundedRect(-97, -18, 194, 8, 4);
    this.speedUp = this.add
      .text(0, 0, "SPEED UP!", {
        fontFamily: ArtTheme.fonts.display,
        fontSize: "28px",
        fontStyle: "bold",
        color: "#7fe7ee",
        stroke: "#071015",
        strokeThickness: 7,
      })
      .setOrigin(0.5)
      .setDepth(155)
      .setVisible(false);
    this.debugGraphics = this.add.graphics().setDepth(250).setVisible(this.debugEnabled);
    this.debugText = this.add
      .text(0, 0, "", {
        fontFamily: "ui-monospace, Menlo, monospace",
        fontSize: "11px",
        color: "#dffcff",
        backgroundColor: "rgba(3,10,14,0.78)",
        padding: { x: 7, y: 6 },
        lineSpacing: 2,
      })
      .setDepth(251)
      .setVisible(this.debugEnabled);

    this.bindEvents();
    this.applyLayout(this.currentLayout);
    DisplayManager.sharpenActiveText(this.game);
    this.scale.on(Phaser.Scale.Events.RESIZE, this.onResize, this);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, this.shutdown, this);
  }

  private bindEvents(): void {
    gameEvents.on(GameEvents.SCORE_CHANGED, this.onScoreChanged);
    gameEvents.on(GameEvents.TOUCH_FEEDBACK, this.onTouchFeedback);
    gameEvents.on(GameEvents.TUTORIAL_STEP, this.onTutorialStep);
    gameEvents.on(GameEvents.TUTORIAL_NUDGE, this.onTutorialNudge);
    gameEvents.on(GameEvents.COUNTDOWN, this.onCountdown);
    gameEvents.on(GameEvents.SPEED_UP, this.onSpeedUp);
    gameEvents.on(GameEvents.GAME_OVER, this.onGameOver);
    gameEvents.on(GameEvents.STATE_CHANGED, this.onStateChanged);
    gameEvents.on(GameEvents.DEBUG_UPDATE, this.onDebugUpdate);
  }

  private readonly onScoreChanged = (score: number, best: number): void => {
    this.hud.updateScore(score, best);
  };

  private readonly onTouchFeedback = (payload: TouchPayload): void => {
    this.touchFeedback.flash(payload.action, payload.x, payload.y);
  };

  private readonly onTutorialStep = (cue: TutorialCue): void => {
    this.currentTutorialCue = cue;
    this.tweens.killTweensOf(this.tutorialSideLabel);
    if (cue === "DONE") {
      this.tutorialShade.setAlpha(0);
      this.tutorialGuide.setVisible(false);
      this.tutorialPanel.setVisible(false);
      this.tutorialProgress.setVisible(false);
      this.tutorialTitle.setVisible(false);
      this.tutorialBody.setVisible(false);
      this.tutorialSideLabel.setVisible(false);
      return;
    }

    const finish = cue.startsWith("FINISH");
    const actionable = cue === "FINISH_ACTION" || cue === "RETURN_ACTION";
    const approaching = cue === "FINISH_APPROACH" || cue === "RETURN_APPROACH";
    const accent = finish ? ArtTheme.colors.amber : ArtTheme.colors.cyan;
    this.tutorialShade
      .setFillStyle(finish ? 0xffd166 : 0x62ddeb, actionable ? 0.13 : approaching ? 0.045 : 0)
      .setPosition(finish ? 0 : this.currentLayout.width * 0.5, 0)
      .setAlpha(actionable || approaching ? 1 : 0);
    this.tutorialGuide.setVisible(true);
    this.tutorialPanel.setVisible(true);
    this.tutorialPanel.setData("accent", accent);
    this.tutorialProgress
      .setText(finish ? "實際練習  1 / 2" : "實際練習  2 / 2")
      .setVisible(true);
    this.tutorialTitle.setVisible(true);
    this.tutorialBody.setVisible(true);
    this.tutorialSideLabel.setVisible(actionable);

    switch (cue) {
      case "FINISH_APPROACH":
        this.tutorialTitle.setText("先看漢堡");
        this.tutorialBody.setText("材料完整，等它來到你的工作站");
        break;
      case "FINISH_ACTION":
        this.tutorialTitle.setText("材料完整");
        this.tutorialBody.setText("不要點漢堡｜點畫面左半邊任何位置");
        this.tutorialSideLabel.setText("✓  左半邊\nFINISH");
        break;
      case "FINISH_SUCCESS":
        this.tutorialTitle.setText("答對了！");
        this.tutorialBody.setText("完整漢堡  →  左邊完成");
        break;
      case "RETURN_APPROACH":
        this.tutorialTitle.setText("再看一個");
        this.tutorialBody.setText("這次缺少材料，等它來到工作站");
        break;
      case "RETURN_ACTION":
        this.tutorialTitle.setText("缺少材料");
        this.tutorialBody.setText("不要點漢堡｜點畫面右半邊任何位置");
        this.tutorialSideLabel.setText("↩  右半邊\nRETURN");
        break;
      case "RETURN_REWORK":
        this.tutorialTitle.setText("正確，退回補料！");
        this.tutorialBody.setText("整條產線會保持間距一起往左移");
        break;
      case "RETURN_SUCCESS":
        this.tutorialTitle.setText("教學完成");
        this.tutorialBody.setText("完整點左・缺料點右");
        break;
      default:
        break;
    }
    this.layoutTutorial(this.currentLayout);
    if (actionable) {
      const baseScale = this.currentLayout.uiScale;
      this.tweens.add({
        targets: this.tutorialSideLabel,
        scaleX: baseScale * 1.045,
        scaleY: baseScale * 1.045,
        alpha: { from: 0.82, to: 1 },
        duration: 430,
        yoyo: true,
        repeat: -1,
        ease: "Sine.InOut",
      });
    }
  };

  private readonly onTutorialNudge = (expected: GameplayAction): void => {
    const cue = this.currentTutorialCue;
    if (cue !== "FINISH_ACTION" && cue !== "RETURN_ACTION") return;
    this.tutorialBody.setText(
      expected === "FINISH"
        ? "看輪廓：材料完整要點左半邊"
        : "看輪廓：缺少材料要點右半邊",
    );
    this.tweens.killTweensOf([
      this.tutorialPanel,
      this.tutorialProgress,
      this.tutorialTitle,
      this.tutorialBody,
    ]);
    this.tweens.add({
      targets: [
        this.tutorialPanel,
        this.tutorialProgress,
        this.tutorialTitle,
        this.tutorialBody,
      ],
      x: { from: -7 * this.currentLayout.uiScale, to: 7 * this.currentLayout.uiScale },
      duration: 48,
      yoyo: true,
      repeat: 2,
      onComplete: () => {
        for (const target of [
          this.tutorialPanel,
          this.tutorialProgress,
          this.tutorialTitle,
          this.tutorialBody,
        ]) {
          target.setX(0);
        }
        if (this.currentTutorialCue === cue) this.onTutorialStep(cue);
      },
    });
  };

  private readonly onCountdown = (value: string): void => {
    if (!value) {
      this.countdown.setVisible(false);
      this.countdownBadge.setVisible(false);
      return;
    }
    const targetScale = value === "GO!" ? this.currentLayout.uiScale * 0.78 : this.currentLayout.uiScale;
    this.countdown
      .setText(value)
      .setFontSize(value === "GO!" ? 48 : 74)
      .setVisible(true)
      .setAlpha(1)
      .setScale(targetScale * 0.68);
    this.countdownBadge
      .setVisible(true)
      .setAlpha(1)
      .setScale(this.currentLayout.uiScale * 0.72)
      .setAngle(-8);
    this.tweens.killTweensOf([this.countdown, this.countdownBadge]);
    this.tweens.add({
      targets: [this.countdown, this.countdownBadge],
      scaleX: targetScale,
      scaleY: targetScale,
      alpha: { from: 1, to: 0.56 },
      angle: 0,
      duration: 430,
      ease: "Back.Out",
    });
  };

  private readonly onSpeedUp = (): void => {
    const startY = this.currentLayout.height * 0.26;
    this.speedUp
      .setPosition(this.currentLayout.width * 0.5, startY)
      .setVisible(true)
      .setAlpha(1)
      .setScale(this.currentLayout.uiScale * 0.85);
    this.speedUpPlate
      .setPosition(this.currentLayout.width * 0.5, startY)
      .setVisible(true)
      .setAlpha(1)
      .setScale(this.currentLayout.uiScale * 0.85);
    this.tweens.killTweensOf([this.speedUp, this.speedUpPlate]);
    this.tweens.add({
      targets: [this.speedUp, this.speedUpPlate],
      y: this.currentLayout.height * 0.26 - 24 * this.currentLayout.uiScale,
      alpha: 0,
      scaleX: this.currentLayout.uiScale * 1.08,
      scaleY: this.currentLayout.uiScale * 1.08,
      duration: 520,
      ease: "Quad.Out",
      onComplete: () => {
        this.speedUp.setVisible(false);
        this.speedUpPlate.setVisible(false);
      },
    });
  };

  private readonly onGameOver = (payload: GameOverPayload): void => {
    this.gameOverPanel.show(payload.score, payload.best, payload.isNewBest, payload.reason);
  };

  private readonly onStateChanged = (state: GameState): void => {
    if (state === GameState.PAUSED) this.pauseOverlay.show();
    else this.pauseOverlay.hide();
    if (state !== GameState.GAME_OVER) this.gameOverPanel.hide();
  };

  private readonly onDebugUpdate = (snapshot: DebugSnapshot): void => {
    if (!this.debugEnabled) return;
    this.debugText.setText([
      `FPS ${snapshot.fps.toFixed(0)}  ${snapshot.width}×${snapshot.height} @${snapshot.dpr.toFixed(2)}`,
      `${snapshot.orientation.toUpperCase()}  SPEED ${snapshot.speed.toFixed(1)}`,
      `SCORE ${snapshot.score}  SPAWN ${snapshot.spawnInterval.toFixed(0)}ms`,
      `DEFECT ${(snapshot.defectRate * 100).toFixed(0)}%  RE-SKIP ${(snapshot.reworkSkipRate * 100).toFixed(0)}%`,
      `ENTITIES ${snapshot.entityCount}`,
      `ACTIVE ${snapshot.activeItem}`,
      `TOUCH ${snapshot.touchState}`,
    ]);
    this.debugText.setPosition(
      snapshot.safeArea.left + 6 * this.currentLayout.uiScale,
      snapshot.height -
        snapshot.safeArea.bottom -
        this.debugText.displayHeight -
        8 * this.currentLayout.uiScale,
    );
    this.debugGraphics.clear();
    this.debugGraphics.fillStyle(0xffd166, 0.025);
    this.debugGraphics.fillRect(0, 0, snapshot.width * 0.5, snapshot.height);
    this.debugGraphics.fillStyle(0x62ddeb, 0.025);
    this.debugGraphics.fillRect(snapshot.width * 0.5, 0, snapshot.width * 0.5, snapshot.height);
    this.debugGraphics.lineStyle(1, 0xffffff, 0.48);
    for (let y = 0; y < snapshot.height; y += 16) {
      this.debugGraphics.lineBetween(snapshot.width * 0.5, y, snapshot.width * 0.5, y + 8);
    }
    this.debugGraphics.lineStyle(2, 0xffd166, 0.7);
    this.debugGraphics.strokeRect(
      snapshot.actionStartX,
      this.currentLayout.conveyorY - 72 * this.currentLayout.uiScale,
      snapshot.actionEndX - snapshot.actionStartX,
      108 * this.currentLayout.uiScale,
    );
    this.debugGraphics.lineStyle(1, 0x69dc8e, 0.7);
    this.debugGraphics.strokeRect(
      snapshot.safeArea.left,
      snapshot.safeArea.top,
      snapshot.width - snapshot.safeArea.left - snapshot.safeArea.right,
      snapshot.height - snapshot.safeArea.top - snapshot.safeArea.bottom,
    );
  };

  private applyLayout(layout: GameLayout): void {
    this.currentLayout = layout;
    this.hud.applyLayout(layout);
    this.touchFeedback.applyLayout(layout);
    this.pauseOverlay.applyLayout(layout);
    this.gameOverPanel.applyLayout(layout);
    this.tutorialShade.setSize(layout.width * 0.5, layout.height);
    this.countdown.setPosition(layout.width * 0.5, layout.height * 0.36);
    this.countdownBadge.setPosition(layout.width * 0.5, layout.height * 0.36);
    this.speedUp.setPosition(layout.width * 0.5, layout.height * 0.26);
    this.speedUpPlate.setPosition(layout.width * 0.5, layout.height * 0.26);
    this.debugText.setScale(layout.uiScale);
    this.layoutTutorial(layout);
  }

  private layoutTutorial(layout: GameLayout): void {
    const cue = this.currentTutorialCue;
    const panelWidth = Math.min(layout.width - 32 * layout.uiScale, 370 * layout.uiScale);
    const panelHeight = 148 * layout.uiScale;
    const centerX = layout.width * 0.5;
    const centerY = Math.max(
      layout.safeArea.top + 160 * layout.uiScale,
      layout.conveyorY - 220 * layout.uiScale,
    );
    this.tutorialPanel.clear();
    const accent = (this.tutorialPanel.getData("accent") as number | undefined) ?? ArtTheme.colors.amber;
    const left = centerX - panelWidth * 0.5;
    const top = centerY - panelHeight * 0.5;
    this.tutorialPanel.fillStyle(ArtTheme.colors.ink, 0.5);
    this.tutorialPanel.fillRoundedRect(
      left + 5 * layout.uiScale,
      top + 7 * layout.uiScale,
      panelWidth,
      panelHeight,
      22 * layout.uiScale,
    );
    this.tutorialPanel.lineStyle(2.5 * layout.uiScale, accent, 0.78);
    this.tutorialPanel.fillStyle(ArtTheme.colors.panel, 0.97);
    this.tutorialPanel.fillRoundedRect(
      left,
      top,
      panelWidth,
      panelHeight,
      20 * layout.uiScale,
    );
    this.tutorialPanel.strokeRoundedRect(
      left,
      top,
      panelWidth,
      panelHeight,
      20 * layout.uiScale,
    );
    this.tutorialPanel.fillStyle(accent, 0.18);
    this.tutorialPanel.fillRoundedRect(
      left + 8 * layout.uiScale,
      top + 8 * layout.uiScale,
      panelWidth - 16 * layout.uiScale,
      31 * layout.uiScale,
      12 * layout.uiScale,
    );
    const pointerX = Phaser.Math.Clamp(
      layout.playerStationX,
      left + 34 * layout.uiScale,
      left + panelWidth - 34 * layout.uiScale,
    );
    this.tutorialPanel.fillStyle(accent, 0.92);
    this.tutorialPanel.fillTriangle(
      pointerX - 12 * layout.uiScale,
      top + panelHeight,
      pointerX + 12 * layout.uiScale,
      top + panelHeight,
      pointerX,
      top + panelHeight + 12 * layout.uiScale,
    );

    this.tutorialGuide.clear();
    const finish = cue?.startsWith("FINISH") ?? true;
    const actionable = cue === "FINISH_ACTION" || cue === "RETURN_ACTION";
    const approaching = cue === "FINISH_APPROACH" || cue === "RETURN_APPROACH";
    const reworking = cue === "RETURN_REWORK";
    if (cue) this.tutorialShade.setPosition(finish ? 0 : layout.width * 0.5, 0);

    if (approaching || reworking) {
      const startX = reworking ? layout.playerStationX : layout.ingredientWorkerX;
      const endX = reworking ? layout.ingredientWorkerX : layout.playerStationX;
      const routeY = layout.conveyorY - 78 * layout.uiScale;
      this.tutorialGuide.lineStyle(3 * layout.uiScale, accent, 0.82);
      this.tutorialGuide.lineBetween(startX, routeY, endX, routeY);
      const direction = endX >= startX ? 1 : -1;
      this.tutorialGuide.fillStyle(accent, 0.95);
      this.tutorialGuide.fillTriangle(
        endX,
        routeY,
        endX - direction * 13 * layout.uiScale,
        routeY - 8 * layout.uiScale,
        endX - direction * 13 * layout.uiScale,
        routeY + 8 * layout.uiScale,
      );
      for (let progress = 0.3; progress < 0.9; progress += 0.24) {
        const x = Phaser.Math.Linear(startX, endX, progress);
        this.tutorialGuide.fillStyle(accent, 0.65);
        this.tutorialGuide.fillCircle(x, routeY, 2.8 * layout.uiScale);
      }
    }

    if (actionable) {
      this.tutorialGuide.lineStyle(1.5 * layout.uiScale, 0xffffff, 0.33);
      for (
        let y = layout.safeArea.top + 82 * layout.uiScale;
        y < layout.height - layout.safeArea.bottom - 26 * layout.uiScale;
        y += 22 * layout.uiScale
      ) {
        this.tutorialGuide.lineBetween(
          layout.halfWidth,
          y,
          layout.halfWidth,
          y + 11 * layout.uiScale,
        );
      }

      this.tutorialGuide.fillStyle(accent, 0.08);
      this.tutorialGuide.fillEllipse(
        layout.playerStationX,
        layout.conveyorY - 15 * layout.uiScale,
        150 * layout.uiScale,
        112 * layout.uiScale,
      );
      this.tutorialGuide.lineStyle(3 * layout.uiScale, accent, 0.9);
      this.tutorialGuide.strokeEllipse(
        layout.playerStationX,
        layout.conveyorY - 15 * layout.uiScale,
        132 * layout.uiScale,
        98 * layout.uiScale,
      );

      const sideX = finish ? layout.width * 0.25 : layout.width * 0.75;
      const badgeY = Math.min(
        layout.height - layout.safeArea.bottom - 54 * layout.uiScale,
        Math.max(layout.conveyorY + 145 * layout.uiScale, layout.height * 0.78),
      );
      const badgeWidth = Math.min(
        layout.width * 0.5 - 26 * layout.uiScale,
        180 * layout.uiScale,
      );
      const badgeHeight = 68 * layout.uiScale;
      this.tutorialGuide.fillStyle(ArtTheme.colors.ink, 0.64);
      this.tutorialGuide.fillRoundedRect(
        sideX - badgeWidth * 0.5 + 4 * layout.uiScale,
        badgeY - badgeHeight * 0.5 + 6 * layout.uiScale,
        badgeWidth,
        badgeHeight,
        19 * layout.uiScale,
      );
      this.tutorialGuide.lineStyle(3 * layout.uiScale, accent, 0.92);
      this.tutorialGuide.fillStyle(ArtTheme.colors.panel, 0.96);
      this.tutorialGuide.fillRoundedRect(
        sideX - badgeWidth * 0.5,
        badgeY - badgeHeight * 0.5,
        badgeWidth,
        badgeHeight,
        19 * layout.uiScale,
      );
      this.tutorialGuide.strokeRoundedRect(
        sideX - badgeWidth * 0.5,
        badgeY - badgeHeight * 0.5,
        badgeWidth,
        badgeHeight,
        19 * layout.uiScale,
      );
      this.tutorialSideLabel.setPosition(sideX, badgeY).setScale(layout.uiScale);
    }

    this.tutorialProgress
      .setPosition(centerX, centerY - 52 * layout.uiScale)
      .setScale(layout.uiScale);
    this.tutorialTitle
      .setPosition(centerX, centerY - 17 * layout.uiScale)
      .setScale(layout.uiScale);
    this.tutorialBody
      .setPosition(centerX, centerY + 34 * layout.uiScale)
      .setScale(layout.uiScale);
  }

  private onResize(gameSize: Phaser.Structs.Size): void {
    this.applyLayout(LayoutManager.refresh(gameSize.width, gameSize.height));
  }

  private shutdown(): void {
    this.scale.off(Phaser.Scale.Events.RESIZE, this.onResize, this);
    gameEvents.off(GameEvents.SCORE_CHANGED, this.onScoreChanged);
    gameEvents.off(GameEvents.TOUCH_FEEDBACK, this.onTouchFeedback);
    gameEvents.off(GameEvents.TUTORIAL_STEP, this.onTutorialStep);
    gameEvents.off(GameEvents.TUTORIAL_NUDGE, this.onTutorialNudge);
    gameEvents.off(GameEvents.COUNTDOWN, this.onCountdown);
    gameEvents.off(GameEvents.SPEED_UP, this.onSpeedUp);
    gameEvents.off(GameEvents.GAME_OVER, this.onGameOver);
    gameEvents.off(GameEvents.STATE_CHANGED, this.onStateChanged);
    gameEvents.off(GameEvents.DEBUG_UPDATE, this.onDebugUpdate);
  }
}
