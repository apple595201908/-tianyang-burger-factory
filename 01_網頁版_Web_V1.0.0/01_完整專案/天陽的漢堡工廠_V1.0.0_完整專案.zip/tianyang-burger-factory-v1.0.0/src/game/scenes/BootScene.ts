import * as Phaser from "phaser";
import { LayoutManager } from "../systems/LayoutManager";

export class BootScene extends Phaser.Scene {
  public constructor() {
    super("BootScene");
  }

  public create(): void {
    LayoutManager.refresh(this.scale.width, this.scale.height);
    this.cameras.main.setBackgroundColor(0x0b151d);
    this.scene.start("PreloadScene");
  }
}
