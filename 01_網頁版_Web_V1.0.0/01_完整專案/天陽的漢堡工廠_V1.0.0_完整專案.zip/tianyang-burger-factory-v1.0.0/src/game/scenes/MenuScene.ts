import * as Phaser from "phaser";
import { ArtTheme } from "../art/ArtTheme";
import { GAME_NAME, GAME_NAME_STACKED, GAME_TAGLINE } from "../Branding";
import { Conveyor } from "../entities/Conveyor";
import { FactoryBackdrop } from "../entities/FactoryBackdrop";
import { FoodItem } from "../entities/FoodItem";
import { Worker } from "../entities/Worker";
import { AudioManager } from "../systems/AudioManager";
import { DisplayManager } from "../systems/DisplayManager";
import { InputManager } from "../systems/InputManager";
import { LayoutManager } from "../systems/LayoutManager";
import { StorageManager } from "../systems/StorageManager";
import type { GameLayout } from "../types/GameTypes";
import { createUiButton } from "../ui/UiButton";

export class MenuScene extends Phaser.Scene {
  private backdrop!: FactoryBackdrop;
  private background!: Phaser.GameObjects.Graphics;
  private logoPlate!: Phaser.GameObjects.Graphics;
  private title!: Phaser.GameObjects.Text;
  private subtitle!: Phaser.GameObjects.Text;
  private bestText!: Phaser.GameObjects.Text;
  private startButton!: Phaser.GameObjects.Container;
  private howButton!: Phaser.GameObjects.Container;
  private muteButton!: Phaser.GameObjects.Container;
  private muteLabel!: Phaser.GameObjects.Text;
  private conveyor!: Conveyor;
  private heroFood!: FoodItem;
  private worker!: Worker;
  private howOverlay!: Phaser.GameObjects.Container;
  private currentLayout!: GameLayout;

  public constructor() {
    super("MenuScene");
  }

  public create(): void {
    InputManager.reset();
    this.currentLayout = LayoutManager.refresh(this.scale.width, this.scale.height);
    this.backdrop = new FactoryBackdrop(this);
    this.background = this.add.graphics().setDepth(1);
    this.logoPlate = this.add.graphics().setDepth(2);
    this.conveyor = new Conveyor(this);
    this.heroFood = new FoodItem(this).activateAt(0, 0, 1);
    this.heroFood.markIngredientProcessed(false);
    this.heroFood.finish();
    this.heroFood.setDepth(18);
    this.worker = new Worker(this, "PLAYER", 0xf0a14a);
    this.title = this.add
      .text(0, 0, GAME_NAME_STACKED, {
        fontFamily: ArtTheme.fonts.display,
        fontSize: "55px",
        fontStyle: "bold",
        color: "#ffd25f",
        align: "center",
        stroke: "#071116",
        strokeThickness: 11,
        shadow: { color: "#f27c34", offsetX: 0, offsetY: 5, blur: 0, fill: true },
        lineSpacing: -10,
      })
      .setOrigin(0.5)
      .setDepth(3);
    this.subtitle = this.add
      .text(0, 0, GAME_TAGLINE, {
        fontFamily: ArtTheme.fonts.rounded,
        fontSize: "16px",
        fontStyle: "bold",
        color: "#d9edef",
        align: "center",
        stroke: "#071116",
        strokeThickness: 4,
      })
      .setOrigin(0.5)
      .setDepth(3);
    this.bestText = this.add
      .text(0, 0, `BEST  ${String(StorageManager.get().bestScore).padStart(3, "0")}`, {
        fontFamily: ArtTheme.fonts.display,
        fontSize: "20px",
        fontStyle: "bold",
        color: "#fff2cf",
        stroke: "#071116",
        strokeThickness: 6,
      })
      .setOrigin(0.5)
      .setDepth(4);
    this.startButton = createUiButton(this, {
      width: 246,
      height: 66,
      label: "開始值班",
      color: 0xffc857,
      fontSize: 24,
      onPress: () => void this.startGame(),
    }).setDepth(30);
    this.howButton = createUiButton(this, {
      width: 172,
      height: 48,
      label: "玩法說明",
      color: 0x344955,
      textColor: "#f3f6f7",
      fontSize: 17,
      onPress: () => this.howOverlay.setVisible(true),
    }).setDepth(30);
    this.muteButton = createUiButton(this, {
      width: 48,
      height: 46,
      label: AudioManager.shared.isMuted ? "×" : "♪",
      color: 0x243744,
      textColor: "#f7f2df",
      fontSize: 23,
      onPress: () => {
        const muted = AudioManager.shared.toggleMute();
        this.muteLabel.setText(muted ? "×" : "♪");
      },
    }).setDepth(30);
    this.muteLabel = this.muteButton.list[2] as Phaser.GameObjects.Text;
    this.howOverlay = this.createHowOverlay();
    this.applyLayout(this.currentLayout);
    DisplayManager.sharpenActiveText(this.game);
    this.scale.on(Phaser.Scale.Events.RESIZE, this.onResize, this);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, this.shutdown, this);
  }

  public update(_time: number, delta: number): void {
    this.backdrop.updateAtmosphere(this.time.now);
    this.conveyor.updateBelt(delta / 1000, 72);
    this.heroFood.rotation = Math.sin(this.time.now * 0.003) * 0.025;
  }

  private async startGame(): Promise<void> {
    await AudioManager.shared.unlock();
    AudioManager.shared.startBgm();
    this.scene.start("GameScene");
  }

  private applyLayout(layout: GameLayout): void {
    this.currentLayout = layout;
    this.backdrop.applyLayout(layout);
    this.drawBackground(layout);
    this.conveyor.applyLayout({ ...layout, conveyorY: layout.height * 0.49 });
    const compactLandscape =
      layout.orientation === "landscape" && layout.height / layout.renderScale < 500;
    const titleY = compactLandscape ? layout.height * 0.24 : layout.height * 0.19;
    this.title.setText(compactLandscape ? GAME_NAME : GAME_NAME_STACKED);
    this.title.setPosition(layout.width * 0.5, titleY).setScale(layout.uiScale);
    this.subtitle
      .setPosition(layout.width * 0.5, titleY + 88 * layout.uiScale)
      .setScale(layout.uiScale);
    this.heroFood
      .setPosition(layout.width * 0.5, layout.height * 0.49 - 14 * layout.uiScale)
      .setScale(layout.uiScale * 1.12);
    this.worker.place(
      layout.width * 0.22,
      layout.height * 0.38,
      layout.uiScale * 0.88,
      true,
    );
    const controlsY = compactLandscape ? layout.height * 0.77 : layout.height * 0.77;
    this.bestText
      .setPosition(layout.width * 0.5, controlsY - 118 * layout.uiScale)
      .setScale(layout.uiScale);
    this.startButton
      .setPosition(layout.width * 0.5, controlsY - 52 * layout.uiScale)
      .setScale(layout.uiScale);
    this.howButton
      .setPosition(layout.width * 0.5, controlsY + 28 * layout.uiScale)
      .setScale(layout.uiScale);
    this.muteButton
      .setPosition(
        layout.width - layout.safeArea.right - 28 * layout.uiScale,
        layout.safeArea.top + 31 * layout.uiScale,
      )
      .setScale(layout.uiScale);
    this.layoutHowOverlay(layout);
  }

  private drawBackground(layout: GameLayout): void {
    const { width, height, uiScale } = layout;
    this.background.clear();
    this.background.fillStyle(ArtTheme.colors.ink, 0.28);
    this.background.fillRect(0, height * 0.61, width, height * 0.39);
    this.background.fillStyle(ArtTheme.colors.amber, 0.045);
    this.background.fillEllipse(width * 0.5, height * 0.24, 360 * uiScale, 190 * uiScale);

    const compact = layout.orientation === "landscape";
    const plateWidth = Math.min(width - 34 * uiScale, (compact ? 480 : 326) * uiScale);
    const plateHeight = (compact ? 102 : 158) * uiScale;
    const plateX = width * 0.5;
    const plateY = height * (compact ? 0.24 : 0.19);
    this.logoPlate.clear();
    this.logoPlate.fillStyle(ArtTheme.colors.ink, 0.58);
    this.logoPlate.fillRoundedRect(
      plateX - plateWidth * 0.5 + 7 * uiScale,
      plateY - plateHeight * 0.5 + 9 * uiScale,
      plateWidth,
      plateHeight,
      25 * uiScale,
    );
    this.logoPlate.lineStyle(4 * uiScale, ArtTheme.colors.steelLight, 0.34);
    this.logoPlate.fillStyle(ArtTheme.colors.panel, 0.92);
    this.logoPlate.fillRoundedRect(
      plateX - plateWidth * 0.5,
      plateY - plateHeight * 0.5,
      plateWidth,
      plateHeight,
      25 * uiScale,
    );
    this.logoPlate.strokeRoundedRect(
      plateX - plateWidth * 0.5,
      plateY - plateHeight * 0.5,
      plateWidth,
      plateHeight,
      25 * uiScale,
    );
    this.logoPlate.lineStyle(3 * uiScale, ArtTheme.colors.amber, 0.78);
    this.logoPlate.strokeRoundedRect(
      plateX - plateWidth * 0.5 + 8 * uiScale,
      plateY - plateHeight * 0.5 + 8 * uiScale,
      plateWidth - 16 * uiScale,
      plateHeight - 16 * uiScale,
      19 * uiScale,
    );
    for (const x of [plateX - plateWidth * 0.44, plateX + plateWidth * 0.44]) {
      for (const y of [plateY - plateHeight * 0.36, plateY + plateHeight * 0.36]) {
        this.logoPlate.fillStyle(ArtTheme.colors.steelLight, 0.8);
        this.logoPlate.fillCircle(x, y, 3.2 * uiScale);
        this.logoPlate.fillStyle(ArtTheme.colors.ink, 0.7);
        this.logoPlate.fillCircle(x, y, 1.25 * uiScale);
      }
    }
  }

  private createHowOverlay(): Phaser.GameObjects.Container {
    const blocker = this.add.rectangle(0, 0, 10, 10, 0x05090d, 0.88).setOrigin(0);
    blocker.setInteractive();
    blocker.on(
      Phaser.Input.Events.POINTER_DOWN,
      (pointer: Phaser.Input.Pointer, _x: number, _y: number, event: Phaser.Types.Input.EventData) => {
        InputManager.consumeUIEvent(pointer, event);
        this.howOverlay.setVisible(false);
      },
    );
    const panel = this.add.graphics();
    panel.setData("panel", true);
    const heading = this.add
      .text(0, 0, "只要記住兩件事", {
        fontFamily: ArtTheme.fonts.display,
        fontSize: "29px",
        fontStyle: "bold",
        color: "#ffdc72",
      })
      .setOrigin(0.5);
    const rules = this.add
      .text(0, 0, "✓  完整漢堡   →   點左半邊   FINISH\n\n↩  缺料底座   →   點右半邊   RETURN\n\n一次判斷錯誤或超時，值班結束。\n速度會持續提高，專心看食品輪廓！", {
        fontFamily: ArtTheme.fonts.rounded,
        fontSize: "18px",
        fontStyle: "bold",
        color: "#e7f0f3",
        align: "center",
        lineSpacing: 5,
        wordWrap: { width: 330 },
        stroke: "#071116",
        strokeThickness: 2,
      })
      .setOrigin(0.5);
    const close = this.add
      .text(0, 0, "點任何位置關閉", {
        fontFamily: ArtTheme.fonts.body,
        fontSize: "15px",
        color: "#8fa7b2",
      })
      .setOrigin(0.5);
    const container = this.add
      .container(0, 0, [blocker, panel, heading, rules, close])
      .setDepth(100)
      .setVisible(false);
    return container;
  }

  private layoutHowOverlay(layout: GameLayout): void {
    const [blocker, panel, heading, rules, close] = this.howOverlay.list as [
      Phaser.GameObjects.Rectangle,
      Phaser.GameObjects.Graphics,
      Phaser.GameObjects.Text,
      Phaser.GameObjects.Text,
      Phaser.GameObjects.Text,
    ];
    blocker.setSize(layout.width, layout.height);
    const centerX = layout.width * 0.5;
    const usableTop = layout.safeArea.top + 10 * layout.uiScale;
    const usableBottom = layout.height - layout.safeArea.bottom - 10 * layout.uiScale;
    const centerY = (usableTop + usableBottom) * 0.5;
    const compact =
      layout.orientation === "landscape" && layout.height / layout.renderScale < 520;
    const width = Math.min(
      layout.width - 34 * layout.uiScale,
      (compact ? 620 : 410) * layout.uiScale,
    );
    const height = Math.min(
      usableBottom - usableTop,
      (compact ? 370 : 430) * layout.uiScale,
    );
    panel.clear();
    const left = centerX - width * 0.5;
    const top = centerY - height * 0.5;
    panel.fillStyle(ArtTheme.colors.ink, 0.6);
    panel.fillRoundedRect(
      left + 7 * layout.uiScale,
      top + 9 * layout.uiScale,
      width,
      height,
      30 * layout.uiScale,
    );
    panel.lineStyle(3 * layout.uiScale, ArtTheme.colors.steelLight, 0.4);
    panel.fillStyle(ArtTheme.colors.panel, 1);
    panel.fillRoundedRect(left, top, width, height, 28 * layout.uiScale);
    panel.strokeRoundedRect(left, top, width, height, 28 * layout.uiScale);
    panel.lineStyle(2 * layout.uiScale, ArtTheme.colors.amber, 0.8);
    panel.strokeRoundedRect(
      left + 8 * layout.uiScale,
      top + 8 * layout.uiScale,
      width - 16 * layout.uiScale,
      height - 16 * layout.uiScale,
      21 * layout.uiScale,
    );
    panel.fillStyle(ArtTheme.colors.amber, 0.13);
    panel.fillRoundedRect(
      left + 13 * layout.uiScale,
      top + 13 * layout.uiScale,
      width - 26 * layout.uiScale,
      59 * layout.uiScale,
      15 * layout.uiScale,
    );
    const ruleBandY = centerY - 31 * layout.uiScale;
    panel.fillStyle(ArtTheme.colors.amber, 0.08);
    panel.fillRoundedRect(
      left + 22 * layout.uiScale,
      ruleBandY - 51 * layout.uiScale,
      width - 44 * layout.uiScale,
      49 * layout.uiScale,
      12 * layout.uiScale,
    );
    panel.fillStyle(ArtTheme.colors.cyan, 0.08);
    panel.fillRoundedRect(
      left + 22 * layout.uiScale,
      ruleBandY + 7 * layout.uiScale,
      width - 44 * layout.uiScale,
      49 * layout.uiScale,
      12 * layout.uiScale,
    );
    panel.lineStyle(1.5 * layout.uiScale, ArtTheme.colors.steelLight, 0.22);
    panel.lineBetween(
      left + 33 * layout.uiScale,
      centerY + 86 * layout.uiScale,
      left + width - 33 * layout.uiScale,
      centerY + 86 * layout.uiScale,
    );
    for (const x of [left + 18 * layout.uiScale, left + width - 18 * layout.uiScale]) {
      for (const y of [top + 18 * layout.uiScale, top + height - 18 * layout.uiScale]) {
        panel.fillStyle(ArtTheme.colors.steelLight, 0.66);
        panel.fillCircle(x, y, 2.5 * layout.uiScale);
      }
    }
    heading
      .setPosition(centerX, centerY - (compact ? 132 : 142) * layout.uiScale)
      .setScale(layout.uiScale);
    rules.setPosition(centerX, centerY - 5 * layout.uiScale).setScale(layout.uiScale);
    close
      .setPosition(centerX, centerY + (compact ? 143 : 166) * layout.uiScale)
      .setScale(layout.uiScale);
  }

  private onResize(gameSize: Phaser.Structs.Size): void {
    this.applyLayout(LayoutManager.refresh(gameSize.width, gameSize.height));
  }

  private shutdown(): void {
    this.scale.off(Phaser.Scale.Events.RESIZE, this.onResize, this);
  }
}
