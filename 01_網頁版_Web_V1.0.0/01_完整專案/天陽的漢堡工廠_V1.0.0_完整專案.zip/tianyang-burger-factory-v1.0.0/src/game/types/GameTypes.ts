export enum GameState {
  MENU = "MENU",
  TUTORIAL = "TUTORIAL",
  COUNTDOWN = "COUNTDOWN",
  PLAYING = "PLAYING",
  PAUSED = "PAUSED",
  GAME_OVER = "GAME_OVER",
}

export enum FoodState {
  SPAWNED = "SPAWNED",
  BASE_ONLY = "BASE_ONLY",
  FILLED = "FILLED",
  PLAYER_STATION = "PLAYER_STATION",
  CAPPED = "CAPPED",
  INSPECTION = "INSPECTION",
  APPROVED = "APPROVED",
  DEFECTIVE = "DEFECTIVE",
  RETURNING = "RETURNING",
  REWORK = "REWORK",
  FAILED = "FAILED",
}

export type GameplayAction = "FINISH" | "RETURN";

export type TutorialCue =
  | "FINISH_APPROACH"
  | "FINISH_ACTION"
  | "FINISH_SUCCESS"
  | "RETURN_APPROACH"
  | "RETURN_ACTION"
  | "RETURN_REWORK"
  | "RETURN_SUCCESS"
  | "DONE";

export type FailureReason =
  | "WRONG_FINISH"
  | "WRONG_RETURN"
  | "MISSED_DEADLINE";

export interface SafeAreaInsets {
  top: number;
  right: number;
  bottom: number;
  left: number;
}

export interface GameLayout {
  width: number;
  height: number;
  renderScale: number;
  orientation: "portrait" | "landscape";
  safeArea: SafeAreaInsets;
  gameplayRect: Phaser.Geom.Rectangle;
  halfWidth: number;
  conveyorY: number;
  conveyorHeight: number;
  spawnX: number;
  baseWorkerX: number;
  ingredientWorkerX: number;
  playerStationX: number;
  inspectorX: number;
  deadlineX: number;
  actionStartX: number;
  actionEndX: number;
  spawnGap: number;
  workerTopY: number;
  workerBottomY: number;
  uiScale: number;
  motionScale: number;
}

export interface SaveData {
  saveVersion: 2;
  bestScore: number;
  mute: boolean;
  tutorialCompleted: boolean;
  tutorialVersion: number;
}

export interface DebugSnapshot {
  fps: number;
  width: number;
  height: number;
  dpr: number;
  orientation: "portrait" | "landscape";
  speed: number;
  score: number;
  spawnInterval: number;
  defectRate: number;
  reworkSkipRate: number;
  activeItem: string;
  entityCount: number;
  touchState: string;
  playerStationX: number;
  deadlineX: number;
  actionStartX: number;
  actionEndX: number;
  safeArea: SafeAreaInsets;
}
