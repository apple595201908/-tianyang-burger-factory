export const GAME_NAME = "天陽的漢堡工廠";
export const GAME_NAME_STACKED = "天陽的\n漢堡工廠";
export const GAME_TAGLINE = "地下食品工廠・高速品質分流";

