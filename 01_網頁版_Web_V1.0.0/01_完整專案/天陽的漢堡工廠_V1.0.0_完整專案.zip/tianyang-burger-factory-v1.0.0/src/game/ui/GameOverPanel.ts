import * as Phaser from "phaser";
import { ArtTheme } from "../art/ArtTheme";
import type { FailureReason, GameLayout } from "../types/GameTypes";
import { InputManager } from "../systems/InputManager";
import { createUiButton } from "./UiButton";

const REASON_COPY: Record<FailureReason, string> = {
  WRONG_FINISH: "缺料品被完成了",
  WRONG_RETURN: "完整品被退回了",
  MISSED_DEADLINE: "食品越過檢查員",
};

export class GameOverPanel extends Phaser.GameObjects.Container {
  private readonly blocker: Phaser.GameObjects.Rectangle;
  private readonly panel: Phaser.GameObjects.Graphics;
  private readonly title: Phaser.GameObjects.Text;
  private readonly reason: Phaser.GameObjects.Text;
  private readonly score: Phaser.GameObjects.Text;
  private readonly best: Phaser.GameObjects.Text;
  private readonly newBest: Phaser.GameObjects.Text;
  private readonly retryButton: Phaser.GameObjects.Container;
  private readonly menuButton: Phaser.GameObjects.Container;

  public constructor(
    scene: Phaser.Scene,
    onRetry: () => void,
    onMenu: () => void,
  ) {
    super(scene, 0, 0);
    this.blocker = scene.add.rectangle(0, 0, 10, 10, 0x05090d, 0.82).setOrigin(0);
    this.blocker.setInteractive();
    this.blocker.on(
      Phaser.Input.Events.POINTER_DOWN,
      (pointer: Phaser.Input.Pointer, _x: number, _y: number, event: Phaser.Types.Input.EventData) => {
        InputManager.consumeUIEvent(pointer, event);
      },
    );
    this.panel = scene.add.graphics();
    this.title = this.makeText("SHIFT OVER!", 34, "#ffe49a", true);
    this.reason = this.makeText("", 16, "#d7e9e8");
    this.score = this.makeText("SCORE\n000", 26, "#fff2cf", true);
    this.best = this.makeText("BEST\n000", 18, "#cce5e5", true);
    this.newBest = this.makeText("★  NEW BEST!  ★", 18, "#77e2a0", true).setVisible(false);
    this.retryButton = createUiButton(scene, {
      width: 220,
      height: 62,
      label: "立即重試",
      color: 0xffc857,
      fontSize: 22,
      onPress: onRetry,
    });
    this.menuButton = createUiButton(scene, {
      width: 160,
      height: 46,
      label: "回主選單",
      color: 0x344955,
      textColor: "#f3f6f7",
      fontSize: 16,
      onPress: onMenu,
    });
    this.add([
      this.blocker,
      this.panel,
      this.title,
      this.reason,
      this.score,
      this.best,
      this.newBest,
      this.retryButton,
      this.menuButton,
    ]);
    this.setDepth(400).setVisible(false);
    scene.add.existing(this);
  }

  public applyLayout(layout: GameLayout): void {
    this.blocker.setSize(layout.width, layout.height);
    const centerX = layout.width * 0.5;
    const usableTop = layout.safeArea.top + 10 * layout.uiScale;
    const usableBottom = layout.height - layout.safeArea.bottom - 10 * layout.uiScale;
    const centerY = (usableTop + usableBottom) * 0.5;
    const compact =
      layout.orientation === "landscape" && layout.height / layout.renderScale < 520;
    const panelWidth = Math.min(
      layout.width - 32 * layout.uiScale,
      (compact ? 620 : 400) * layout.uiScale,
    );
    const panelHeight = compact
      ? usableBottom - usableTop
      : Math.min(usableBottom - usableTop, 490 * layout.uiScale);
    this.panel.clear();
    const left = centerX - panelWidth * 0.5;
    const top = centerY - panelHeight * 0.5;
    this.panel.fillStyle(ArtTheme.colors.ink, 0.58);
    this.panel.fillRoundedRect(
      left + 7 * layout.uiScale,
      top + 9 * layout.uiScale,
      panelWidth,
      panelHeight,
      30 * layout.uiScale,
    );
    this.panel.lineStyle(3 * layout.uiScale, ArtTheme.colors.steelLight, 0.4);
    this.panel.fillStyle(ArtTheme.colors.panel, 0.995);
    this.panel.fillRoundedRect(
      left,
      top,
      panelWidth,
      panelHeight,
      28 * layout.uiScale,
    );
    this.panel.strokeRoundedRect(
      left,
      top,
      panelWidth,
      panelHeight,
      28 * layout.uiScale,
    );
    this.panel.lineStyle(2 * layout.uiScale, ArtTheme.colors.amber, 0.8);
    this.panel.strokeRoundedRect(
      left + 8 * layout.uiScale,
      top + 8 * layout.uiScale,
      panelWidth - 16 * layout.uiScale,
      panelHeight - 16 * layout.uiScale,
      21 * layout.uiScale,
    );
    this.panel.fillStyle(ArtTheme.colors.coral, 0.12);
    this.panel.fillRoundedRect(
      left + 12 * layout.uiScale,
      top + 12 * layout.uiScale,
      panelWidth - 24 * layout.uiScale,
      (compact ? 64 : 70) * layout.uiScale,
      15 * layout.uiScale,
    );
    this.panel.fillStyle(ArtTheme.colors.coral, 0.85);
    for (let x = left + 26 * layout.uiScale; x < left + panelWidth - 20 * layout.uiScale; x += 25 * layout.uiScale) {
      this.panel.fillRoundedRect(
        x,
        top + 17 * layout.uiScale,
        12 * layout.uiScale,
        3 * layout.uiScale,
        1.5 * layout.uiScale,
      );
    }

    // Score readout plate.
    const scorePlateWidth = Math.min(panelWidth - 48 * layout.uiScale, 250 * layout.uiScale);
    const scorePlateHeight = (compact ? 70 : 115) * layout.uiScale;
    const scorePlateY = centerY + (compact ? -28 : -47) * layout.uiScale;
    this.panel.lineStyle(2 * layout.uiScale, 0x84a6aa, 0.36);
    this.panel.fillStyle(ArtTheme.colors.inkSoft, 0.8);
    this.panel.fillRoundedRect(
      centerX - scorePlateWidth * 0.5,
      scorePlateY - scorePlateHeight * 0.5,
      scorePlateWidth,
      scorePlateHeight,
      14 * layout.uiScale,
    );
    this.panel.strokeRoundedRect(
      centerX - scorePlateWidth * 0.5,
      scorePlateY - scorePlateHeight * 0.5,
      scorePlateWidth,
      scorePlateHeight,
      14 * layout.uiScale,
    );
    for (const x of [left + 17 * layout.uiScale, left + panelWidth - 17 * layout.uiScale]) {
      for (const y of [top + 17 * layout.uiScale, top + panelHeight - 17 * layout.uiScale]) {
        this.panel.fillStyle(ArtTheme.colors.steelLight, 0.62);
        this.panel.fillCircle(x, y, 2.5 * layout.uiScale);
      }
    }
    if (compact) {
      this.title.setPosition(centerX, centerY - 126 * layout.uiScale).setScale(layout.uiScale);
      this.reason.setPosition(centerX, centerY - 85 * layout.uiScale).setScale(layout.uiScale);
      this.score
        .setPosition(centerX - 100 * layout.uiScale, centerY - 26 * layout.uiScale)
        .setScale(layout.uiScale);
      this.best
        .setPosition(centerX + 100 * layout.uiScale, centerY - 26 * layout.uiScale)
        .setScale(layout.uiScale);
      this.newBest.setPosition(centerX, centerY + 40 * layout.uiScale).setScale(layout.uiScale);
      this.retryButton
        .setPosition(centerX - 124 * layout.uiScale, centerY + 112 * layout.uiScale)
        .setScale(layout.uiScale * 0.9);
      this.menuButton
        .setPosition(centerX + 124 * layout.uiScale, centerY + 112 * layout.uiScale)
        .setScale(layout.uiScale * 0.9);
      return;
    }
    this.title.setPosition(centerX, centerY - 172 * layout.uiScale).setScale(layout.uiScale);
    this.reason.setPosition(centerX, centerY - 127 * layout.uiScale).setScale(layout.uiScale);
    this.score.setPosition(centerX, centerY - 65 * layout.uiScale).setScale(layout.uiScale);
    this.best.setPosition(centerX, centerY + 5 * layout.uiScale).setScale(layout.uiScale);
    this.newBest.setPosition(centerX, centerY + 53 * layout.uiScale).setScale(layout.uiScale);
    this.retryButton.setPosition(centerX, centerY + 118 * layout.uiScale).setScale(layout.uiScale);
    this.menuButton.setPosition(centerX, centerY + 181 * layout.uiScale).setScale(layout.uiScale);
  }

  public show(score: number, best: number, isNewBest: boolean, reason: FailureReason): void {
    this.reason.setText(REASON_COPY[reason]);
    this.score.setText(`SCORE\n${String(score).padStart(3, "0")}`);
    this.best.setText(`BEST\n${String(best).padStart(3, "0")}`);
    this.newBest.setVisible(isNewBest);
    this.setVisible(true).setAlpha(0);
    this.scene.tweens.add({ targets: this, alpha: 1, duration: 160 });
  }

  public hide(): void {
    this.setVisible(false);
  }

  private makeText(
    content: string,
    size: number,
    color: string,
    bold = false,
  ): Phaser.GameObjects.Text {
    return this.scene.add
      .text(0, 0, content, {
        fontFamily: bold ? ArtTheme.fonts.display : ArtTheme.fonts.rounded,
        fontSize: `${size}px`,
        fontStyle: bold ? "bold" : "normal",
        color,
        align: "center",
        lineSpacing: 3,
        stroke: "#071116",
        strokeThickness: bold ? 4 : 2,
      })
      .setOrigin(0.5);
  }
}
