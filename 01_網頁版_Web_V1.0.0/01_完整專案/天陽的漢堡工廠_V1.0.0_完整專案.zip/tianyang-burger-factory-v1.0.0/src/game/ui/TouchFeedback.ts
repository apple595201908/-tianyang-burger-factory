import * as Phaser from "phaser";
import { ArtTheme } from "../art/ArtTheme";
import { GameTuning } from "../GameTuning";
import type { GameLayout, GameplayAction } from "../types/GameTypes";

export class TouchFeedback extends Phaser.GameObjects.Container {
  private readonly leftOverlay: Phaser.GameObjects.Rectangle;
  private readonly rightOverlay: Phaser.GameObjects.Rectangle;
  private readonly pulse: Phaser.GameObjects.Graphics;
  private readonly symbol: Phaser.GameObjects.Text;
  private layout: GameLayout | null = null;

  public constructor(scene: Phaser.Scene) {
    super(scene, 0, 0);
    this.leftOverlay = scene.add.rectangle(0, 0, 10, 10, 0xffd166, 0).setOrigin(0);
    this.rightOverlay = scene.add.rectangle(0, 0, 10, 10, 0x62ddeb, 0).setOrigin(0);
    this.pulse = scene.add.graphics().setAlpha(0);
    this.symbol = scene.add
      .text(0, 0, "", {
        fontFamily: ArtTheme.fonts.display,
        fontSize: "30px",
        fontStyle: "bold",
        color: "#fff7df",
        stroke: "#071116",
        strokeThickness: 5,
      })
      .setOrigin(0.5)
      .setAlpha(0);
    this.add([this.leftOverlay, this.rightOverlay, this.pulse, this.symbol]);
    this.setDepth(90);
    scene.add.existing(this);
  }

  public applyLayout(layout: GameLayout): void {
    this.layout = layout;
    this.leftOverlay.setSize(layout.width * 0.5, layout.height).setPosition(0, 0);
    this.rightOverlay
      .setSize(layout.width * 0.5, layout.height)
      .setPosition(layout.width * 0.5, 0);
  }

  public flash(action: GameplayAction, x: number, y: number): void {
    if (!this.layout) return;
    const overlay = action === "FINISH" ? this.leftOverlay : this.rightOverlay;
    const accent = action === "FINISH" ? ArtTheme.colors.amberLight : ArtTheme.colors.cyan;
    const px = Phaser.Math.Clamp(
      x,
      34 * this.layout.uiScale,
      this.layout.width - 34 * this.layout.uiScale,
    );
    const py = Phaser.Math.Clamp(
      y,
      92 * this.layout.uiScale,
      this.layout.height - 74 * this.layout.uiScale,
    );
    this.scene.tweens.killTweensOf([overlay, this.pulse, this.symbol]);
    overlay.setAlpha(0.095);
    this.pulse.clear();
    this.pulse.fillStyle(accent, 0.13);
    this.pulse.fillCircle(0, 0, 27);
    this.pulse.lineStyle(3, accent, 0.78);
    this.pulse.strokeCircle(0, 0, 20);
    this.pulse.lineStyle(1.5, 0xffffff, 0.46);
    this.pulse.strokeCircle(0, 0, 15);
    this.pulse
      .setPosition(px, py)
      .setScale(this.layout.uiScale * 0.72)
      .setAlpha(0.84);
    this.symbol
      .setText(action === "FINISH" ? "✓" : "↩")
      .setPosition(px, py - 1 * this.layout.uiScale)
      .setScale(this.layout.uiScale)
      .setAlpha(0.86);
    this.scene.tweens.add({
      targets: overlay,
      alpha: 0,
      duration: GameTuning.TOUCH_FEEDBACK_MS,
      ease: "Quad.Out",
    });
    this.scene.tweens.add({
      targets: [this.pulse, this.symbol],
      alpha: 0,
      scaleX: this.layout.uiScale * 1.2,
      scaleY: this.layout.uiScale * 1.2,
      duration: GameTuning.TOUCH_FEEDBACK_MS + 18,
      ease: "Quad.Out",
    });
  }
}
