import * as Phaser from "phaser";
import { ArtTheme } from "../art/ArtTheme";
import { AudioManager } from "../systems/AudioManager";
import { InputManager } from "../systems/InputManager";

export interface UiButtonOptions {
  width: number;
  height: number;
  label: string;
  color?: number;
  textColor?: string;
  fontSize?: number;
  onPress: () => void;
}

export function createUiButton(
  scene: Phaser.Scene,
  options: UiButtonOptions,
): Phaser.GameObjects.Container {
  const shadow = scene.add.graphics();
  const radius = Math.min(18, options.height * 0.35);
  shadow.fillStyle(ArtTheme.colors.ink, 0.28);
  shadow.fillRoundedRect(
    -options.width * 0.5 - 3,
    -options.height * 0.5 + 5,
    options.width + 6,
    options.height + 4,
    radius + 2,
  );
  shadow.fillStyle(ArtTheme.colors.ink, 0.62);
  shadow.fillRoundedRect(
    -options.width * 0.5,
    -options.height * 0.5 + 6,
    options.width,
    options.height,
    radius,
  );
  const background = scene.add.graphics();
  background.lineStyle(3, ArtTheme.colors.ink, 0.9);
  background.fillStyle(options.color ?? 0xffc857, 1);
  background.fillRoundedRect(
    -options.width * 0.5,
    -options.height * 0.5,
    options.width,
    options.height,
    radius,
  );
  background.strokeRoundedRect(
    -options.width * 0.5,
    -options.height * 0.5,
    options.width,
    options.height,
    radius,
  );
  // Painted bevels and gloss remain cheap to render while reading like a tactile arcade control.
  background.fillStyle(ArtTheme.colors.ink, 0.18);
  background.fillRoundedRect(
    -options.width * 0.5 + 4,
    options.height * 0.5 - 11,
    options.width - 8,
    7,
    3,
  );
  background.fillStyle(0xffffff, 0.17);
  background.fillRoundedRect(
    -options.width * 0.5 + 7,
    -options.height * 0.5 + 6,
    options.width - 14,
    Math.max(3, options.height * 0.12),
    4,
  );
  background.lineStyle(1.5, 0xffffff, 0.16);
  background.strokeRoundedRect(
    -options.width * 0.5 + 5,
    -options.height * 0.5 + 5,
    options.width - 10,
    options.height - 12,
    Math.max(5, radius - 5),
  );
  const label = scene.add
    .text(0, 0, options.label, {
      fontFamily: ArtTheme.fonts.rounded,
      fontSize: `${options.fontSize ?? 20}px`,
      fontStyle: "bold",
      color: options.textColor ?? "#10202a",
      align: "center",
      stroke: options.textColor ? "#071116" : "#fff0b0",
      strokeThickness: options.textColor ? 2 : 1,
    })
    .setOrigin(0.5);
  const button = scene.add.container(0, 0, [shadow, background, label]);
  button.setSize(options.width, options.height);
  button.setInteractive({ useHandCursor: true });
  button.on(
    Phaser.Input.Events.POINTER_DOWN,
    (pointer: Phaser.Input.Pointer, _x: number, _y: number, event: Phaser.Types.Input.EventData) => {
      InputManager.consumeUIEvent(pointer, event);
      void AudioManager.shared.unlock().then(() => AudioManager.shared.play("button"));
      scene.tweens.add({
        targets: button,
        scaleX: 0.955,
        scaleY: 0.955,
        duration: 45,
        yoyo: true,
        ease: "Quad.Out",
      });
      options.onPress();
    },
  );
  return button;
}
