import * as Phaser from "phaser";
import { ArtTheme } from "../art/ArtTheme";
import type { GameLayout } from "../types/GameTypes";
import { createUiButton } from "./UiButton";

export class ScoreHUD extends Phaser.GameObjects.Container {
  private readonly plate: Phaser.GameObjects.Graphics;
  private readonly scoreText: Phaser.GameObjects.Text;
  private readonly bestText: Phaser.GameObjects.Text;
  private readonly muteButton: Phaser.GameObjects.Container;
  private readonly muteLabel: Phaser.GameObjects.Text;
  private readonly pauseButton: Phaser.GameObjects.Container;

  public constructor(
    scene: Phaser.Scene,
    onPause: () => void,
    onMute: () => void,
  ) {
    super(scene, 0, 0);
    this.plate = scene.add.graphics();
    const textStyle: Phaser.Types.GameObjects.Text.TextStyle = {
      fontFamily: ArtTheme.fonts.display,
      fontSize: "17px",
      fontStyle: "bold",
      color: "#fff2cf",
      stroke: "#071116",
      strokeThickness: 4,
      lineSpacing: -3,
    };
    this.scoreText = scene.add.text(0, 0, "SCORE\n000", textStyle).setOrigin(0, 0);
    this.bestText = scene.add.text(0, 0, "BEST\n000", textStyle).setOrigin(0.5, 0);
    this.muteButton = createUiButton(scene, {
      width: 44,
      height: 42,
      label: "♪",
      color: 0x243744,
      textColor: "#f7f2df",
      fontSize: 22,
      onPress: onMute,
    });
    this.muteLabel = this.muteButton.list[2] as Phaser.GameObjects.Text;
    this.pauseButton = createUiButton(scene, {
      width: 44,
      height: 42,
      label: "Ⅱ",
      color: 0x243744,
      textColor: "#f7f2df",
      fontSize: 18,
      onPress: onPause,
    });
    this.add([this.plate, this.scoreText, this.bestText, this.muteButton, this.pauseButton]);
    this.setDepth(100);
    scene.add.existing(this);
  }

  public updateScore(score: number, best: number): void {
    this.scoreText.setText(`SCORE\n${String(score).padStart(3, "0")}`);
    this.bestText.setText(`BEST\n${String(best).padStart(3, "0")}`);
  }

  public updateMute(muted: boolean): void {
    this.muteLabel.setText(muted ? "×" : "♪");
  }

  public applyLayout(layout: GameLayout): void {
    const top = layout.safeArea.top + 13 * layout.uiScale;
    const cardHeight = 51 * layout.uiScale;
    const scoreCardWidth = 92 * layout.uiScale;
    const centerCardWidth = 96 * layout.uiScale;
    const scoreLeft = layout.safeArea.left + 8 * layout.uiScale;
    const bestLeft = layout.width * 0.5 - centerCardWidth * 0.5;
    this.plate.clear();

    for (const [x, width, accent] of [
      [scoreLeft, scoreCardWidth, ArtTheme.colors.amber],
      [bestLeft, centerCardWidth, ArtTheme.colors.cyan],
    ] as const) {
      this.plate.fillStyle(ArtTheme.colors.ink, 0.46);
      this.plate.fillRoundedRect(
        x + 3 * layout.uiScale,
        top + 5 * layout.uiScale,
        width,
        cardHeight,
        12 * layout.uiScale,
      );
      this.plate.lineStyle(2 * layout.uiScale, 0x8eafb2, 0.36);
      this.plate.fillStyle(ArtTheme.colors.panel, 0.93);
      this.plate.fillRoundedRect(x, top, width, cardHeight, 12 * layout.uiScale);
      this.plate.strokeRoundedRect(x, top, width, cardHeight, 12 * layout.uiScale);
      this.plate.fillStyle(accent, 0.9);
      this.plate.fillRoundedRect(
        x + 7 * layout.uiScale,
        top + 5 * layout.uiScale,
        width - 14 * layout.uiScale,
        3 * layout.uiScale,
        1.5 * layout.uiScale,
      );
      this.plate.fillStyle(0xffffff, 0.13);
      this.plate.fillCircle(
        x + width - 10 * layout.uiScale,
        top + 11 * layout.uiScale,
        2 * layout.uiScale,
      );
    }

    this.scoreText.setPosition(layout.safeArea.left + 15 * layout.uiScale, top);
    this.scoreText.setScale(layout.uiScale);
    this.bestText.setPosition(layout.width * 0.5, top + 1 * layout.uiScale);
    this.bestText.setScale(layout.uiScale);
    this.pauseButton
      .setPosition(
        layout.width - layout.safeArea.right - 23 * layout.uiScale,
        top + 22 * layout.uiScale,
      )
      .setScale(layout.uiScale);
    this.muteButton
      .setPosition(
        layout.width - layout.safeArea.right - 73 * layout.uiScale,
        top + 22 * layout.uiScale,
      )
      .setScale(layout.uiScale);
  }
}
