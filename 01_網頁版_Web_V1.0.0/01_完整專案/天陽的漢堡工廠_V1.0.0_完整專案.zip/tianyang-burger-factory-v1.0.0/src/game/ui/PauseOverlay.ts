import * as Phaser from "phaser";
import { ArtTheme } from "../art/ArtTheme";
import type { GameLayout } from "../types/GameTypes";
import { InputManager } from "../systems/InputManager";
import { createUiButton } from "./UiButton";

export class PauseOverlay extends Phaser.GameObjects.Container {
  private readonly blocker: Phaser.GameObjects.Rectangle;
  private readonly panel: Phaser.GameObjects.Graphics;
  private readonly title: Phaser.GameObjects.Text;
  private readonly subtitle: Phaser.GameObjects.Text;
  private readonly menuButton: Phaser.GameObjects.Container;
  private layout: GameLayout | null = null;

  public constructor(
    scene: Phaser.Scene,
    onResume: () => void,
    onMenu: () => void,
  ) {
    super(scene, 0, 0);
    this.blocker = scene.add.rectangle(0, 0, 10, 10, 0x05090d, 0.78).setOrigin(0);
    this.blocker.setInteractive();
    this.blocker.on(
      Phaser.Input.Events.POINTER_DOWN,
      (pointer: Phaser.Input.Pointer, _x: number, _y: number, event: Phaser.Types.Input.EventData) => {
        InputManager.consumeUIEvent(pointer, event);
        onResume();
      },
    );
    this.panel = scene.add.graphics();
    this.title = scene.add
      .text(0, 0, "產線已暫停", {
        fontFamily: ArtTheme.fonts.display,
        fontSize: "32px",
        fontStyle: "bold",
        color: "#ffe49a",
        align: "center",
        stroke: "#071116",
        strokeThickness: 6,
      })
      .setOrigin(0.5);
    this.subtitle = scene.add
      .text(0, 0, "TAP TO RESUME\n點畫面繼續", {
        fontFamily: ArtTheme.fonts.rounded,
        fontSize: "17px",
        fontStyle: "bold",
        color: "#d7e9e8",
        align: "center",
        lineSpacing: 6,
      })
      .setOrigin(0.5);
    this.menuButton = createUiButton(scene, {
      width: 150,
      height: 48,
      label: "回主選單",
      color: 0x344955,
      textColor: "#f3f6f7",
      fontSize: 17,
      onPress: onMenu,
    });
    this.add([this.blocker, this.panel, this.title, this.subtitle, this.menuButton]);
    this.setDepth(300).setVisible(false);
    scene.add.existing(this);
  }

  public applyLayout(layout: GameLayout): void {
    this.layout = layout;
    this.blocker.setSize(layout.width, layout.height);
    const panelWidth = Math.min(layout.width - 38 * layout.uiScale, 390 * layout.uiScale);
    const panelHeight = 280 * layout.uiScale;
    const centerX = layout.width * 0.5;
    const centerY = layout.height * 0.5;
    this.panel.clear();
    const left = centerX - panelWidth * 0.5;
    const top = centerY - panelHeight * 0.5;
    this.panel.fillStyle(ArtTheme.colors.ink, 0.5);
    this.panel.fillRoundedRect(
      left + 7 * layout.uiScale,
      top + 9 * layout.uiScale,
      panelWidth,
      panelHeight,
      28 * layout.uiScale,
    );
    this.panel.lineStyle(3 * layout.uiScale, ArtTheme.colors.steelLight, 0.42);
    this.panel.fillStyle(ArtTheme.colors.panel, 0.98);
    this.panel.fillRoundedRect(
      left,
      top,
      panelWidth,
      panelHeight,
      26 * layout.uiScale,
    );
    this.panel.strokeRoundedRect(
      left,
      top,
      panelWidth,
      panelHeight,
      26 * layout.uiScale,
    );
    this.panel.lineStyle(2 * layout.uiScale, ArtTheme.colors.amber, 0.78);
    this.panel.strokeRoundedRect(
      left + 8 * layout.uiScale,
      top + 8 * layout.uiScale,
      panelWidth - 16 * layout.uiScale,
      panelHeight - 16 * layout.uiScale,
      19 * layout.uiScale,
    );
    this.panel.fillStyle(ArtTheme.colors.amber, 0.13);
    this.panel.fillRoundedRect(
      left + 12 * layout.uiScale,
      top + 12 * layout.uiScale,
      panelWidth - 24 * layout.uiScale,
      51 * layout.uiScale,
      13 * layout.uiScale,
    );
    this.panel.fillStyle(ArtTheme.colors.amber, 0.95);
    this.panel.fillRoundedRect(
      centerX - 24 * layout.uiScale,
      top + 23 * layout.uiScale,
      9 * layout.uiScale,
      23 * layout.uiScale,
      3 * layout.uiScale,
    );
    this.panel.fillRoundedRect(
      centerX - 9 * layout.uiScale,
      top + 23 * layout.uiScale,
      9 * layout.uiScale,
      23 * layout.uiScale,
      3 * layout.uiScale,
    );
    for (const x of [left + 17 * layout.uiScale, left + panelWidth - 17 * layout.uiScale]) {
      for (const y of [top + 17 * layout.uiScale, top + panelHeight - 17 * layout.uiScale]) {
        this.panel.fillStyle(ArtTheme.colors.steelLight, 0.65);
        this.panel.fillCircle(x, y, 2.5 * layout.uiScale);
      }
    }
    this.title.setPosition(centerX, centerY - 69 * layout.uiScale).setScale(layout.uiScale);
    this.subtitle.setPosition(centerX, centerY + 2 * layout.uiScale).setScale(layout.uiScale);
    this.menuButton.setPosition(centerX, centerY + 88 * layout.uiScale).setScale(layout.uiScale);
  }

  public show(): void {
    this.setVisible(true).setAlpha(0);
    this.scene.tweens.killTweensOf(this);
    this.scene.tweens.add({ targets: this, alpha: 1, duration: 120, ease: "Quad.Out" });
  }

  public hide(): void {
    this.setVisible(false);
  }
}
