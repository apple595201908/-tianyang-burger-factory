import * as Phaser from "phaser";
import { ArtTheme } from "../art/ArtTheme";
import { GameTuning } from "../GameTuning";
import { FoodState, type GameLayout } from "../types/GameTypes";

let foodSerial = 0;

export class FoodItem extends Phaser.GameObjects.Container {
  public readonly itemId = `FOOD-${++foodSerial}`;
  public state = FoodState.SPAWNED;
  public ingredientProcessed = false;
  public inspected = false;
  public reworkSkipCount = 0;
  private outfeedHidden = false;

  private readonly visual: Phaser.GameObjects.Container;
  private readonly shadow: Phaser.GameObjects.Graphics;
  private readonly food: Phaser.GameObjects.Graphics;
  private readonly cap: Phaser.GameObjects.Graphics;
  private readonly accent: Phaser.GameObjects.Graphics;
  private baseScale = 1;

  public constructor(scene: Phaser.Scene) {
    super(scene, -999, -999);
    this.shadow = scene.add.graphics();
    this.food = scene.add.graphics();
    this.cap = scene.add.graphics();
    this.accent = scene.add.graphics();
    this.visual = scene.add.container(0, 0, [this.shadow, this.food, this.cap, this.accent]);
    this.add(this.visual);
    this.setSize(GameTuning.FOOD_BASE_WIDTH, GameTuning.FOOD_BASE_HEIGHT);
    this.setDepth(22);
    this.setActive(false).setVisible(false);
    scene.add.existing(this);
  }

  public activateAt(x: number, y: number, scale: number): this {
    this.baseScale = scale;
    this.setPosition(x, y - 9 * scale);
    this.setScale(scale);
    this.setAlpha(1);
    this.setAngle(0);
    this.visual.setScale(1).setAngle(0).setPosition(0, 0);
    this.state = FoodState.SPAWNED;
    this.ingredientProcessed = false;
    this.inspected = false;
    this.reworkSkipCount = 0;
    this.outfeedHidden = false;
    this.setActive(true).setVisible(true);
    this.redraw();
    return this;
  }

  public deactivate(): void {
    this.outfeedHidden = false;
    this.setActive(false).setVisible(false).setPosition(-999, -999);
    this.scene.tweens.killTweensOf([this, this.visual, this.cap, this.accent]);
  }

  public setFoodState(state: FoodState): void {
    this.state = state;
    this.redraw();
  }

  public get isOutfeedHidden(): boolean {
    return this.outfeedHidden;
  }

  public hideCompletedOutfeed(): void {
    this.outfeedHidden = true;
    this.setVisible(false);
  }

  public markIngredientProcessed(defective: boolean): void {
    this.ingredientProcessed = true;
    this.setFoodState(defective ? FoodState.BASE_ONLY : FoodState.FILLED);
  }

  public finish(): void {
    this.state = FoodState.CAPPED;
    this.redraw();
    this.cap.y = -26;
    this.scene.tweens.add({
      targets: this.cap,
      y: 0,
      duration: GameTuning.FINISH_ANIMATION_MS,
      ease: "Back.Out",
    });
    this.visual.setScale(1, 1);
    this.scene.tweens.add({
      targets: this.visual,
      scaleY: 0.88,
      duration: 30,
      yoyo: true,
      repeat: 1,
      ease: "Quad.Out",
      onComplete: () => this.visual.setScale(1),
    });
  }

  public startReturn(): void {
    this.state = FoodState.RETURNING;
    this.redraw();
    this.scene.tweens.add({
      targets: this.visual,
      scaleX: 0.85,
      duration: GameTuning.RETURN_ANIMATION_MS * 0.4,
      yoyo: true,
      repeat: 1,
      ease: "Quad.Out",
      onComplete: () => this.visual.setScale(1),
    });
  }

  public beginRework(): void {
    this.state = FoodState.REWORK;
    this.redraw();
  }

  public completeRework(): void {
    this.state = FoodState.FILLED;
    this.ingredientProcessed = true;
    this.redraw();
  }

  public skipRework(): void {
    this.reworkSkipCount += 1;
    this.state = FoodState.BASE_ONLY;
    this.ingredientProcessed = true;
    this.redraw();
    this.scene.tweens.killTweensOf(this.visual);
    this.scene.tweens.add({
      targets: this.visual,
      angle: { from: -4, to: 4 },
      duration: 70,
      yoyo: true,
      repeat: 1,
      ease: "Sine.InOut",
      onComplete: () => this.visual.setAngle(0),
    });
  }

  public fail(): void {
    this.state = FoodState.FAILED;
    this.redraw();
    this.scene.tweens.add({
      targets: this.visual,
      x: { from: -5, to: 5 },
      duration: 38,
      yoyo: true,
      repeat: 3,
      onComplete: () => this.visual.setX(0),
    });
  }

  public updateMotion(
    deltaSeconds: number,
    speed: number,
    layout: GameLayout,
  ): void {
    if (
      !this.active ||
      this.state === FoodState.FAILED ||
      this.state === FoodState.RETURNING ||
      this.state === FoodState.REWORK
    ) {
      return;
    }

    this.x += speed * layout.motionScale * deltaSeconds;
    this.y = layout.conveyorY - 9 * this.baseScale;
  }

  public rescale(layout: GameLayout, previousWidth: number): void {
    if (!this.active) return;
    const ratio = previousWidth > 0 ? layout.width / previousWidth : 1;
    this.x *= ratio;
    this.baseScale = layout.uiScale;
    this.setScale(layout.uiScale);
    this.y = layout.conveyorY - 9 * layout.uiScale;
  }

  private redraw(): void {
    this.shadow.clear();
    this.food.clear();
    this.cap.clear();
    this.accent.clear();

    this.shadow.fillStyle(ArtTheme.colors.ink, 0.54);
    this.shadow.fillEllipse(2, 31, 104, 18);
    this.shadow.fillStyle(0x050b0e, 0.35);
    this.shadow.fillEllipse(-3, 27, 83, 11);

    const outline = 0x301711;
    const baseOnly =
      this.state === FoodState.SPAWNED ||
      this.state === FoodState.BASE_ONLY ||
      this.state === FoodState.DEFECTIVE ||
      this.state === FoodState.RETURNING ||
      this.state === FoodState.REWORK;
    const failed = this.state === FoodState.FAILED;

    // Small stainless tray visually anchors every order to the conveyor.
    this.food.lineStyle(2.5, 0x16282e, 1);
    this.food.fillStyle(0x78959a, 1);
    this.food.fillRoundedRect(-51, 22, 102, 11, 5);
    this.food.strokeRoundedRect(-51, 22, 102, 11, 5);
    this.food.fillStyle(0xc8dcda, 0.55);
    this.food.fillRoundedRect(-43, 23.5, 86, 3, 1.5);

    // Toasted bottom bun with a dark readable outline and painted highlight.
    this.food.lineStyle(4, failed ? ArtTheme.colors.coral : outline, 1);
    this.food.fillStyle(failed ? 0xa5504c : 0xc86c32, 1);
    this.food.fillRoundedRect(-45, 5, 90, 24, { tl: 7, tr: 7, bl: 13, br: 13 });
    this.food.strokeRoundedRect(-45, 5, 90, 24, { tl: 7, tr: 7, bl: 13, br: 13 });
    this.food.fillStyle(failed ? 0xc97066 : 0xf2a94d, 1);
    this.food.fillRoundedRect(-39, 5, 78, 14, 6);
    this.food.fillStyle(0xffd78d, failed ? 0.28 : 0.72);
    this.food.fillRoundedRect(-32, 8, 47, 5, 2.5);
    this.food.fillStyle(0x9f4e28, 0.5);
    this.food.fillRoundedRect(-34, 21, 68, 4, 2);

    if (!baseOnly || failed) {
      // Patty.
      this.food.lineStyle(3.5, outline, 1);
      this.food.fillStyle(failed ? 0x73443e : 0x552c25, 1);
      this.food.fillRoundedRect(-44, -8, 88, 18, 7);
      this.food.strokeRoundedRect(-44, -8, 88, 18, 7);
      this.food.fillStyle(0x8c4a35, failed ? 0.38 : 0.72);
      this.food.fillRoundedRect(-35, -5, 58, 5, 2.5);
      for (const x of [-26, -7, 14, 31]) {
        this.food.fillStyle(0xd37a46, failed ? 0.18 : 0.44);
        this.food.fillRoundedRect(x, 3, 8, 2, 1);
      }

      // Big wavy lettuce silhouette remains legible in peripheral vision.
      this.food.lineStyle(2.5, 0x173b25, 1);
      this.food.fillStyle(failed ? 0x5b7651 : 0x55c66b, 1);
      this.food.beginPath();
      this.food.moveTo(-48, -10);
      this.food.lineTo(-38, -19);
      this.food.lineTo(-25, -13);
      this.food.lineTo(-12, -22);
      this.food.lineTo(2, -13);
      this.food.lineTo(16, -22);
      this.food.lineTo(28, -13);
      this.food.lineTo(42, -20);
      this.food.lineTo(48, -10);
      this.food.closePath();
      this.food.fillPath();
      this.food.strokePath();
      this.food.lineStyle(2, 0x9bec82, failed ? 0.2 : 0.65);
      this.food.lineBetween(-36, -16, -18, -15);
      this.food.lineBetween(3, -16, 24, -16);

      // Tomato and melted cheese provide broad, distinct color bands.
      this.food.lineStyle(2.5, outline, 0.96);
      this.food.fillStyle(failed ? 0x9a5b50 : 0xec5f55, 1);
      this.food.fillRoundedRect(-41, -25, 82, 10, 5);
      this.food.strokeRoundedRect(-41, -25, 82, 10, 5);
      this.food.fillStyle(0xffa079, failed ? 0.22 : 0.55);
      this.food.fillRoundedRect(-31, -23, 33, 3, 1.5);

      this.food.lineStyle(2.5, 0x6d4518, 0.9);
      this.food.fillStyle(failed ? 0xb99a57 : 0xffcf4d, 1);
      this.food.beginPath();
      this.food.moveTo(-39, -28);
      this.food.lineTo(39, -28);
      this.food.lineTo(31, -18);
      this.food.lineTo(17, -23);
      this.food.lineTo(5, -15);
      this.food.lineTo(-9, -23);
      this.food.lineTo(-26, -17);
      this.food.closePath();
      this.food.fillPath();
      this.food.strokePath();
      this.food.fillStyle(0xffffa7, failed ? 0.15 : 0.48);
      this.food.fillRoundedRect(-30, -26, 40, 3, 1.5);
    }

    const capped =
      this.state === FoodState.CAPPED ||
      this.state === FoodState.INSPECTION ||
      this.state === FoodState.APPROVED;
    if (capped || failed) {
      this.cap.fillStyle(ArtTheme.colors.ink, 0.32);
      this.cap.fillEllipse(1, -18, 84, 10);
      this.cap.lineStyle(4, failed ? ArtTheme.colors.coral : outline, 1);
      this.cap.fillStyle(failed ? 0xa5504c : 0xdd863b, 1);
      this.cap.fillRoundedRect(-46, -49, 92, 31, { tl: 27, tr: 27, bl: 8, br: 8 });
      this.cap.strokeRoundedRect(-46, -49, 92, 31, { tl: 27, tr: 27, bl: 8, br: 8 });
      this.cap.fillStyle(failed ? 0xc97066 : 0xf4ad51, 1);
      this.cap.fillRoundedRect(-39, -46, 78, 18, { tl: 22, tr: 22, bl: 5, br: 5 });
      this.cap.fillStyle(0xffe5aa, failed ? 0.2 : 0.75);
      this.cap.fillEllipse(-15, -40, 36, 10);
      this.cap.fillStyle(0x9b5129, 0.45);
      this.cap.fillRoundedRect(-35, -23, 70, 4, 2);
      this.cap.fillStyle(failed ? 0xe2a79c : 0xfff1c4, 1);
      for (const seed of [
        [-25, -40, -0.18],
        [-7, -44, 0.15],
        [12, -39, -0.1],
        [29, -42, 0.18],
      ] as const) {
        this.cap.fillEllipse(seed[0], seed[1], 6, 2.7);
      }
    }

    if (baseOnly && !failed) {
      const accentColor = this.state === FoodState.RETURNING
        ? ArtTheme.colors.cyan
        : ArtTheme.colors.amberLight;
      // Empty upper space and the two small ticks exaggerate the low silhouette.
      this.accent.lineStyle(3, accentColor, 0.74);
      this.accent.lineBetween(-31, -2, -15, -2);
      this.accent.lineBetween(15, -2, 31, -2);
      this.accent.fillStyle(accentColor, 0.18);
      this.accent.fillCircle(0, -2, 6);

      if (this.state === FoodState.RETURNING) {
        this.accent.fillStyle(ArtTheme.colors.cyan, 0.12);
        this.accent.fillCircle(-42, -14, 17);
        this.accent.lineStyle(4, ArtTheme.colors.cyan, 1);
        this.accent.beginPath();
        this.accent.moveTo(-28, -14);
        this.accent.lineTo(-48, -14);
        this.accent.lineTo(-39, -23);
        this.accent.moveTo(-48, -14);
        this.accent.lineTo(-39, -5);
        this.accent.strokePath();
      } else if (this.state === FoodState.REWORK) {
        this.accent.lineStyle(2.5, ArtTheme.colors.amberLight, 0.75);
        for (const x of [-17, 0, 17]) {
          this.accent.beginPath();
          this.accent.moveTo(x - 4, -14);
          this.accent.lineTo(x + 2, -20);
          this.accent.lineTo(x - 1, -27);
          this.accent.strokePath();
        }
      }
    }

    if (this.state === FoodState.APPROVED) {
      this.accent.fillStyle(ArtTheme.colors.green, 0.22);
      this.accent.fillCircle(35, -41, 17);
      this.accent.lineStyle(2.5, 0xf1fff0, 0.75);
      this.accent.fillStyle(ArtTheme.colors.green, 1);
      this.accent.fillCircle(35, -41, 12.5);
      this.accent.strokeCircle(35, -41, 12.5);
      this.accent.lineStyle(3, 0x143422, 1);
      this.accent.beginPath();
      this.accent.moveTo(29, -41);
      this.accent.lineTo(34, -36);
      this.accent.lineTo(42, -47);
      this.accent.strokePath();
    }

    if (failed) {
      this.accent.fillStyle(ArtTheme.colors.coral, 0.18);
      this.accent.fillCircle(0, -11, 24);
      this.accent.lineStyle(5, 0xffd7cb, 0.95);
      this.accent.lineBetween(-8, -19, 8, -3);
      this.accent.lineBetween(8, -19, -8, -3);
    }
  }
}
