import * as Phaser from "phaser";
import { ArtTheme, WorkerPalettes } from "../art/ArtTheme";

export type WorkerRole = "BASE" | "INGREDIENT" | "PLAYER" | "INSPECTOR";

const ROLE_LABELS: Record<WorkerRole, string> = {
  BASE: "底座",
  INGREDIENT: "配料",
  PLAYER: "你",
  INSPECTOR: "檢查",
};

export class Worker extends Phaser.GameObjects.Container {
  private readonly visual: Phaser.GameObjects.Container;
  private readonly bodyGraphics: Phaser.GameObjects.Graphics;
  private readonly leftArm: Phaser.GameObjects.Graphics;
  private readonly rightArm: Phaser.GameObjects.Graphics;
  private readonly eyes: Phaser.GameObjects.Graphics;
  private readonly label: Phaser.GameObjects.Text;

  public constructor(
    scene: Phaser.Scene,
    public readonly role: WorkerRole,
    private readonly color: number,
  ) {
    super(scene, 0, 0);
    this.bodyGraphics = scene.add.graphics();
    this.leftArm = scene.add.graphics();
    this.rightArm = scene.add.graphics();
    this.eyes = scene.add.graphics();
    this.label = scene.add
      .text(0, 56, ROLE_LABELS[role], {
        fontFamily: ArtTheme.fonts.rounded,
        fontSize: "12px",
        fontStyle: "bold",
        color: "#fff2cf",
        backgroundColor: "rgba(7,17,22,0.86)",
        padding: { x: 7, y: 3 },
        stroke: "#071116",
        strokeThickness: 2,
      })
      .setOrigin(0.5);
    this.visual = scene.add.container(0, 0, [
      this.leftArm,
      this.rightArm,
      this.bodyGraphics,
      this.eyes,
      this.label,
    ]);
    this.add(this.visual);
    this.setDepth(14);
    scene.add.existing(this);
    this.draw();
  }

  public place(x: number, y: number, scale: number, faceDown: boolean): void {
    this.setPosition(x, y).setScale(scale);
    this.visual.setScale(1, faceDown ? 1 : -1);
    this.label.setScale(1, faceDown ? 1 : -1);
  }

  public playWork(): void {
    this.scene.tweens.killTweensOf([this.visual, this.leftArm, this.rightArm]);
    this.scene.tweens.add({
      targets: this.visual,
      scaleX: 1.08,
      duration: 55,
      yoyo: true,
      ease: "Quad.Out",
    });
    this.scene.tweens.add({
      targets: [this.leftArm, this.rightArm],
      angle: { from: -12, to: 20 },
      duration: 65,
      yoyo: true,
      ease: "Quad.Out",
    });
  }

  public playBored(): void {
    this.scene.tweens.killTweensOf(this.visual);
    this.scene.tweens.add({
      targets: this.visual,
      angle: { from: -5, to: 6 },
      duration: 100,
      yoyo: true,
      repeat: 1,
      ease: "Sine.InOut",
      onComplete: () => this.visual.setAngle(0),
    });
    this.eyes.x = 3;
    this.scene.time.delayedCall(180, () => this.active && this.eyes.setX(0));
  }

  public playFail(): void {
    this.scene.tweens.add({
      targets: this.visual,
      angle: { from: -9, to: 9 },
      duration: 70,
      yoyo: true,
      repeat: 2,
      onComplete: () => this.visual.setAngle(0),
    });
  }

  private draw(): void {
    this.bodyGraphics.clear();
    this.leftArm.clear();
    this.rightArm.clear();
    this.eyes.clear();

    const palette = WorkerPalettes[this.role];
    const primary = palette.primary ?? this.color;
    const outline = ArtTheme.colors.ink;
    const skin = 0xf4bd91;
    const skinShade = 0xd9906f;

    // Rounded rubber boots and floor shadow.
    this.bodyGraphics.fillStyle(outline, 0.4);
    this.bodyGraphics.fillEllipse(0, 48, 66, 14);
    this.bodyGraphics.lineStyle(3, outline, 1);
    this.bodyGraphics.fillStyle(0x24363c, 1);
    this.bodyGraphics.fillRoundedRect(-25, 35, 22, 14, 7);
    this.bodyGraphics.fillRoundedRect(3, 35, 22, 14, 7);
    this.bodyGraphics.strokeRoundedRect(-25, 35, 22, 14, 7);
    this.bodyGraphics.strokeRoundedRect(3, 35, 22, 14, 7);
    this.bodyGraphics.fillStyle(0x8aa2a5, 0.42);
    this.bodyGraphics.fillRoundedRect(-20, 38, 12, 3, 1.5);
    this.bodyGraphics.fillRoundedRect(8, 38, 12, 3, 1.5);

    // Articulated sleeves and glove-like hands. The arms remain separate for work animation.
    for (const [arm, side] of [
      [this.leftArm, -1],
      [this.rightArm, 1],
    ] as const) {
      const shoulderX = 23 * side;
      const handX = 40 * side;
      arm.lineStyle(15, outline, 1);
      arm.beginPath();
      arm.moveTo(shoulderX, 6);
      arm.lineTo(handX, 28);
      arm.strokePath();
      arm.lineStyle(9, palette.shade, 1);
      arm.beginPath();
      arm.moveTo(shoulderX, 6);
      arm.lineTo(handX, 28);
      arm.strokePath();
      arm.lineStyle(4, primary, 1);
      arm.lineBetween(shoulderX + side * 1.5, 4, handX - side * 2, 25);
      arm.fillStyle(outline, 1);
      arm.fillCircle(handX, 29, 9);
      arm.fillStyle(skin, 1);
      arm.fillCircle(handX, 29, 6.5);
      arm.fillStyle(0xffd5ae, 0.55);
      arm.fillCircle(handX - side * 1.6, 27, 2.2);
    }

    // Uniform body with shaded side, apron, seams and a bright role badge.
    this.bodyGraphics.lineStyle(3.5, outline, 1);
    this.bodyGraphics.fillStyle(primary, 1);
    this.bodyGraphics.fillRoundedRect(-29, -1, 58, 45, { tl: 17, tr: 17, bl: 12, br: 12 });
    this.bodyGraphics.strokeRoundedRect(-29, -1, 58, 45, { tl: 17, tr: 17, bl: 12, br: 12 });
    this.bodyGraphics.fillStyle(palette.shade, 0.78);
    this.bodyGraphics.fillRoundedRect(-28, 19, 56, 24, { tl: 6, tr: 6, bl: 11, br: 11 });
    this.bodyGraphics.fillStyle(palette.highlight, 0.7);
    this.bodyGraphics.fillRoundedRect(-20, 3, 11, 28, 5);
    this.bodyGraphics.lineStyle(2.2, outline, 0.82);
    this.bodyGraphics.fillStyle(0xe8f1ed, 0.96);
    this.bodyGraphics.fillRoundedRect(-18, 7, 36, 29, 9);
    this.bodyGraphics.strokeRoundedRect(-18, 7, 36, 29, 9);
    this.bodyGraphics.fillStyle(0xb8d0cc, 0.65);
    this.bodyGraphics.fillRoundedRect(-14, 25, 28, 7, 3);
    this.bodyGraphics.lineStyle(1.5, outline, 0.55);
    this.bodyGraphics.lineBetween(0, 8, 0, 34);
    this.bodyGraphics.fillStyle(palette.accent, 1);
    this.bodyGraphics.fillCircle(13, 10, 5.5);
    this.bodyGraphics.lineStyle(1.5, 0xfff5d2, 0.85);
    this.bodyGraphics.strokeCircle(13, 10, 5.5);

    // Role glyphs make the four workers identifiable even without reading labels.
    this.bodyGraphics.lineStyle(2.3, outline, 0.86);
    if (this.role === "BASE") {
      this.bodyGraphics.fillStyle(0xe49a43, 1);
      this.bodyGraphics.fillRoundedRect(-9, 14, 18, 8, 4);
      this.bodyGraphics.lineBetween(-7, 17, 7, 17);
    } else if (this.role === "INGREDIENT") {
      this.bodyGraphics.fillStyle(0x62c86e, 1);
      this.bodyGraphics.fillTriangle(-9, 21, 0, 12, 9, 21);
      this.bodyGraphics.lineBetween(0, 14, 0, 21);
    } else if (this.role === "PLAYER") {
      this.bodyGraphics.lineStyle(3, palette.accent, 1);
      this.bodyGraphics.lineBetween(-8, 18, -2, 24);
      this.bodyGraphics.lineBetween(-2, 24, 9, 12);
    } else {
      this.bodyGraphics.lineStyle(2.5, palette.accent, 1);
      this.bodyGraphics.strokeCircle(0, 18, 7);
      this.bodyGraphics.lineBetween(5, 23, 10, 28);
    }

    // Head, ears and clean food-safe cap.
    this.bodyGraphics.fillStyle(outline, 1);
    this.bodyGraphics.fillCircle(-26, -18, 8.5);
    this.bodyGraphics.fillCircle(26, -18, 8.5);
    this.bodyGraphics.fillStyle(skinShade, 1);
    this.bodyGraphics.fillCircle(-26, -18, 6);
    this.bodyGraphics.fillCircle(26, -18, 6);
    this.bodyGraphics.lineStyle(3.5, outline, 1);
    this.bodyGraphics.fillStyle(skin, 1);
    this.bodyGraphics.fillCircle(0, -19, 28);
    this.bodyGraphics.strokeCircle(0, -19, 28);
    this.bodyGraphics.fillStyle(0xffd3a7, 0.75);
    this.bodyGraphics.fillEllipse(-9, -27, 15, 10);
    this.bodyGraphics.fillStyle(0xce765c, 0.27);
    this.bodyGraphics.fillCircle(-18, -10, 5);
    this.bodyGraphics.fillCircle(18, -10, 5);

    this.bodyGraphics.lineStyle(3.5, outline, 1);
    this.bodyGraphics.fillStyle(0xe8f1ed, 1);
    this.bodyGraphics.fillRoundedRect(-29, -47, 58, 17, 8);
    this.bodyGraphics.strokeRoundedRect(-29, -47, 58, 17, 8);
    this.bodyGraphics.fillStyle(primary, 1);
    this.bodyGraphics.fillRoundedRect(-21, -42, 42, 10, 5);
    this.bodyGraphics.fillStyle(palette.highlight, 0.78);
    this.bodyGraphics.fillRoundedRect(-16, -40, 23, 4, 2);
    this.bodyGraphics.fillStyle(palette.accent, 0.95);
    this.bodyGraphics.fillCircle(21, -39, 3.4);

    // Friendly, highly readable face.
    this.eyes.fillStyle(outline, 1);
    this.eyes.fillEllipse(-9, -20, 6.5, 8);
    this.eyes.fillEllipse(9, -20, 6.5, 8);
    this.eyes.fillStyle(0xffffff, 0.9);
    this.eyes.fillCircle(-10, -22, 1.4);
    this.eyes.fillCircle(8, -22, 1.4);
    if (this.role === "INSPECTOR") {
      this.eyes.lineStyle(2.4, 0x293d48, 1);
      this.eyes.fillStyle(0xbcebf2, 0.16);
      this.eyes.fillCircle(-9, -20, 8);
      this.eyes.fillCircle(9, -20, 8);
      this.eyes.strokeCircle(-9, -20, 8);
      this.eyes.strokeCircle(9, -20, 8);
      this.eyes.lineBetween(-1, -20, 1, -20);
    }
    this.eyes.lineStyle(2.2, 0x8f4f43, 1);
    this.eyes.beginPath();
    this.eyes.moveTo(-5, -9);
    this.eyes.lineTo(0, -6);
    this.eyes.lineTo(5, -9);
    this.eyes.strokePath();
  }
}
