import * as Phaser from "phaser";
import { ArtTheme } from "../art/ArtTheme";
import type { GameLayout } from "../types/GameTypes";

export class Conveyor extends Phaser.GameObjects.Container {
  private readonly base: Phaser.GameObjects.Graphics;
  private readonly stripes: Phaser.GameObjects.Graphics;
  private offset = 0;
  private layout: GameLayout | null = null;

  public constructor(scene: Phaser.Scene) {
    super(scene, 0, 0);
    this.base = scene.add.graphics();
    this.stripes = scene.add.graphics();
    this.add([this.base, this.stripes]);
    this.setDepth(10);
    scene.add.existing(this);
  }

  public applyLayout(layout: GameLayout): void {
    this.layout = layout;
    this.drawBase();
    this.drawStripes();
  }

  public updateBelt(deltaSeconds: number, speed: number): void {
    if (!this.layout) return;
    this.moveBeltBy(speed * this.layout.motionScale * deltaSeconds);
  }

  public moveBeltBy(distance: number): void {
    if (!this.layout) return;
    const step = 42 * this.layout.uiScale;
    this.offset = Phaser.Math.Wrap(this.offset + distance, 0, step);
    this.drawStripes();
  }

  private drawBase(): void {
    if (!this.layout) return;
    const { width, conveyorY, conveyorHeight, uiScale } = this.layout;
    const top = conveyorY - conveyorHeight * 0.38;
    const beltHeight = conveyorHeight * 0.57;
    const chassisTop = top + beltHeight - 1 * uiScale;
    const chassisHeight = conveyorHeight * 0.43;
    const rollerY = top + beltHeight * 0.58;
    this.base.clear();

    // Floor contact shadow gives the belt a grounded 2.5D silhouette.
    this.base.fillStyle(ArtTheme.colors.ink, 0.52);
    this.base.fillRoundedRect(
      -10 * uiScale,
      top + conveyorHeight * 0.58,
      width + 20 * uiScale,
      conveyorHeight * 0.62,
      18 * uiScale,
    );

    // Lower powder-coated chassis.
    this.base.lineStyle(3 * uiScale, ArtTheme.colors.ink, 0.95);
    this.base.fillStyle(0x203a43, 1);
    this.base.fillRoundedRect(
      -7 * uiScale,
      chassisTop,
      width + 14 * uiScale,
      chassisHeight,
      10 * uiScale,
    );
    this.base.strokeRoundedRect(
      -7 * uiScale,
      chassisTop,
      width + 14 * uiScale,
      chassisHeight,
      10 * uiScale,
    );
    this.base.fillStyle(0x13282f, 1);
    this.base.fillRect(0, chassisTop + chassisHeight * 0.52, width, chassisHeight * 0.48);
    this.base.fillStyle(ArtTheme.colors.steelLight, 0.14);
    this.base.fillRect(0, chassisTop + 2 * uiScale, width, 3 * uiScale);

    // Belt bed: dark rubber with a bright steel rim and warm reflected light.
    this.base.lineStyle(4 * uiScale, ArtTheme.colors.ink, 0.96);
    this.base.fillStyle(0x324b53, 1);
    this.base.fillRoundedRect(
      -8 * uiScale,
      top,
      width + 16 * uiScale,
      beltHeight,
      13 * uiScale,
    );
    this.base.strokeRoundedRect(
      -8 * uiScale,
      top,
      width + 16 * uiScale,
      beltHeight,
      13 * uiScale,
    );
    this.base.fillStyle(0x172c33, 1);
    this.base.fillRoundedRect(
      0,
      top + 7 * uiScale,
      width,
      beltHeight - 12 * uiScale,
      7 * uiScale,
    );
    this.base.fillStyle(0x6e8a8f, 0.32);
    this.base.fillRect(0, top + 7 * uiScale, width, 3 * uiScale);
    this.base.fillStyle(ArtTheme.colors.amberLight, 0.1);
    this.base.fillRect(0, top + 11 * uiScale, width, 2 * uiScale);

    // Recessed rollers and hubs.
    for (let x = 17 * uiScale; x < width + 20 * uiScale; x += 53 * uiScale) {
      this.base.fillStyle(ArtTheme.colors.ink, 0.96);
      this.base.fillCircle(x, rollerY, 12 * uiScale);
      this.base.lineStyle(2 * uiScale, 0x638089, 0.72);
      this.base.fillStyle(0x38545d, 1);
      this.base.fillCircle(x, rollerY, 8.3 * uiScale);
      this.base.strokeCircle(x, rollerY, 8.3 * uiScale);
      this.base.fillStyle(0x93adb0, 0.88);
      this.base.fillCircle(x, rollerY, 3.3 * uiScale);
      this.base.fillStyle(0xe4f1ed, 0.42);
      this.base.fillCircle(x - 1.2 * uiScale, rollerY - 1.4 * uiScale, 1.1 * uiScale);
    }

    // Side access panels and sturdy supports.
    const panelStep = Math.max(96 * uiScale, width / 5);
    for (let x = panelStep * 0.22; x < width; x += panelStep) {
      const panelWidth = Math.min(72 * uiScale, panelStep * 0.58);
      const panelTop = chassisTop + 8 * uiScale;
      this.base.lineStyle(1.5 * uiScale, 0x66838a, 0.38);
      this.base.fillStyle(0x294851, 0.85);
      this.base.fillRoundedRect(
        x,
        panelTop,
        panelWidth,
        Math.max(10 * uiScale, chassisHeight - 14 * uiScale),
        4 * uiScale,
      );
      this.base.strokeRoundedRect(
        x,
        panelTop,
        panelWidth,
        Math.max(10 * uiScale, chassisHeight - 14 * uiScale),
        4 * uiScale,
      );
      this.base.fillStyle(ArtTheme.colors.amber, 0.65);
      this.base.fillCircle(x + 8 * uiScale, panelTop + 7 * uiScale, 2 * uiScale);
    }

    const supportY = chassisTop + chassisHeight;
    for (let x = 48 * uiScale; x < width; x += 164 * uiScale) {
      this.base.fillStyle(ArtTheme.colors.ink, 0.55);
      this.base.fillRoundedRect(x - 13 * uiScale, supportY, 26 * uiScale, 28 * uiScale, 5 * uiScale);
      this.base.fillStyle(0x29464e, 1);
      this.base.fillRoundedRect(x - 9 * uiScale, supportY - 1 * uiScale, 18 * uiScale, 25 * uiScale, 4 * uiScale);
      this.base.fillStyle(0x789298, 0.5);
      this.base.fillRect(x - 6 * uiScale, supportY + 1 * uiScale, 3 * uiScale, 20 * uiScale);
    }
  }

  private drawStripes(): void {
    if (!this.layout) return;
    const { width, conveyorY, conveyorHeight, uiScale } = this.layout;
    const top = conveyorY - conveyorHeight * 0.38;
    this.stripes.clear();
    const step = 42 * uiScale;
    const stripeWidth = 15 * uiScale;
    for (let x = -step + this.offset; x < width + step; x += step) {
      this.stripes.fillStyle(0xcce0df, 0.11);
      this.stripes.fillRoundedRect(
        x,
        top + 13 * uiScale,
        stripeWidth,
        conveyorHeight * 0.31,
        3 * uiScale,
      );
      this.stripes.fillStyle(ArtTheme.colors.cyan, 0.075);
      this.stripes.fillRoundedRect(
        x + 3 * uiScale,
        top + 15 * uiScale,
        3 * uiScale,
        conveyorHeight * 0.25,
        1.5 * uiScale,
      );
    }

    // Animated front-edge glints sell movement without particles or shaders.
    const glintStep = step * 3;
    for (let x = -glintStep + this.offset * 1.7; x < width + glintStep; x += glintStep) {
      this.stripes.fillStyle(ArtTheme.colors.amberLight, 0.17);
      this.stripes.fillRoundedRect(
        x,
        top + conveyorHeight * 0.53,
        22 * uiScale,
        2.2 * uiScale,
        uiScale,
      );
    }
  }
}
