import * as Phaser from "phaser";
import { ArtTheme } from "../art/ArtTheme";
import type { GameLayout } from "../types/GameTypes";

export class FactoryBackdrop extends Phaser.GameObjects.Container {
  private readonly image: Phaser.GameObjects.Image;
  private readonly treatment: Phaser.GameObjects.Graphics;
  private readonly atmosphere: Phaser.GameObjects.Graphics;
  private layout: GameLayout | null = null;

  public constructor(scene: Phaser.Scene) {
    super(scene, 0, 0);
    this.image = scene.add.image(0, 0, "factory-bg-portrait").setOrigin(0.5);
    this.treatment = scene.add.graphics();
    this.atmosphere = scene.add.graphics();
    this.add([this.image, this.treatment, this.atmosphere]);
    this.setDepth(0);
    scene.add.existing(this);
  }

  public applyLayout(layout: GameLayout): void {
    this.layout = layout;
    const textureKey =
      layout.orientation === "portrait"
        ? "factory-bg-portrait"
        : "factory-bg-landscape";
    this.image.setTexture(textureKey).setPosition(layout.width * 0.5, layout.height * 0.5);
    const source = this.image.texture.getSourceImage() as HTMLImageElement;
    const coverScale = Math.max(
      layout.width / Math.max(1, source.width),
      layout.height / Math.max(1, source.height),
    );
    this.image.setScale(coverScale);
    this.drawTreatment(layout);
    this.drawAtmosphere(0);
  }

  public updateAtmosphere(time: number): void {
    if (!this.layout) return;
    this.drawAtmosphere(time);
  }

  private drawTreatment(layout: GameLayout): void {
    const { width, height, uiScale } = layout;
    this.treatment.clear();

    this.treatment.fillStyle(ArtTheme.colors.ink, 0.28);
    this.treatment.fillRect(0, 0, width, height * 0.1);
    this.treatment.fillStyle(ArtTheme.colors.ink, 0.2);
    this.treatment.fillRect(0, height * 0.78, width, height * 0.22);

    for (let i = 0; i < 7; i += 1) {
      const alpha = 0.025 + i * 0.012;
      this.treatment.fillStyle(ArtTheme.colors.ink, alpha);
      this.treatment.fillRect(
        i * 14 * uiScale,
        i * 10 * uiScale,
        width - i * 28 * uiScale,
        height - i * 20 * uiScale,
      );
    }

    this.treatment.fillStyle(ArtTheme.colors.amber, 0.035);
    this.treatment.fillEllipse(width * 0.25, height * 0.25, 260 * uiScale, 190 * uiScale);
    this.treatment.fillStyle(ArtTheme.colors.cyan, 0.028);
    this.treatment.fillEllipse(width * 0.78, height * 0.43, 300 * uiScale, 220 * uiScale);
  }

  private drawAtmosphere(time: number): void {
    if (!this.layout) return;
    const { width, height, uiScale } = this.layout;
    this.atmosphere.clear();
    for (let i = 0; i < 11; i += 1) {
      const seed = i * 97.3;
      const x = Phaser.Math.Wrap(seed * 13 + time * (0.004 + (i % 3) * 0.001), 0, width);
      const y = height * (0.12 + ((i * 0.137) % 0.55));
      const radius = (1.1 + (i % 3) * 0.55) * uiScale;
      this.atmosphere.fillStyle(i % 2 === 0 ? ArtTheme.colors.amberLight : 0xbbecef, 0.14);
      this.atmosphere.fillCircle(x, y, radius);
    }
  }
}
