import * as Phaser from "phaser";
import { ArtTheme } from "../art/ArtTheme";
import { Worker } from "./Worker";

export class Inspector extends Worker {
  private readonly stamp: Phaser.GameObjects.Container;

  public constructor(scene: Phaser.Scene) {
    super(scene, "INSPECTOR", 0x9d77d8);
    const glow = scene.add.graphics();
    glow.fillStyle(ArtTheme.colors.green, 0.19);
    glow.fillCircle(0, 0, 24);
    const badge = scene.add.graphics();
    badge.lineStyle(3, 0xe9fff0, 0.9);
    badge.fillStyle(ArtTheme.colors.green, 1);
    badge.fillCircle(0, 0, 16);
    badge.strokeCircle(0, 0, 16);
    badge.lineStyle(2, 0x1c4a2f, 0.7);
    badge.strokeCircle(0, 0, 12);
    const mark = scene.add
      .text(0, -1, "✓", {
        fontFamily: ArtTheme.fonts.display,
        fontSize: "22px",
        fontStyle: "bold",
        color: "#163924",
      })
      .setOrigin(0.5)
      .setAngle(-7);
    this.stamp = scene.add.container(0, 0, [glow, badge, mark]).setAlpha(0).setDepth(40);
  }

  public approve(x: number, y: number, scale: number): void {
    this.playWork();
    this.scene.tweens.killTweensOf(this.stamp);
    this.stamp
      .setPosition(x, y - 48 * scale)
      .setScale(scale * 0.55)
      .setAngle(-10)
      .setAlpha(1);
    this.scene.tweens.add({
      targets: this.stamp,
      y: y - 74 * scale,
      alpha: 0,
      angle: 4,
      scaleX: scale * 1.12,
      scaleY: scale * 1.12,
      duration: 300,
      ease: "Back.Out",
    });
  }

  public override destroy(fromScene?: boolean): void {
    this.stamp.destroy();
    super.destroy(fromScene);
  }
}
