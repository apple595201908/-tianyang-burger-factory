import * as Phaser from "phaser";
import { GAME_NAME } from "./Branding";
import { BootScene } from "./scenes/BootScene";
import { GameScene } from "./scenes/GameScene";
import { MenuScene } from "./scenes/MenuScene";
import { PreloadScene } from "./scenes/PreloadScene";
import { UIScene } from "./scenes/UIScene";

export function makeGameConfig(
  parent: HTMLElement,
  renderScale: number,
): Phaser.Types.Core.GameConfig {
  const cssWidth = Math.max(1, parent.clientWidth || window.innerWidth);
  const cssHeight = Math.max(1, parent.clientHeight || window.innerHeight);
  return {
    type: Phaser.AUTO,
    parent,
    width: Math.round(cssWidth * renderScale),
    height: Math.round(cssHeight * renderScale),
    backgroundColor: "#0b151d",
    transparent: false,
    banner: false,
    disableContextMenu: true,
    render: {
      antialias: true,
      antialiasGL: true,
      roundPixels: true,
      powerPreference: "high-performance",
    },
    fps: {
      target: 60,
      forceSetTimeOut: false,
    },
    input: {
      activePointers: 3,
      touch: { capture: true },
    },
    scale: {
      mode: Phaser.Scale.NONE,
      autoCenter: Phaser.Scale.NO_CENTER,
      autoRound: true,
    },
    callbacks: {
      postBoot: (game) => {
        const canvas = game.canvas;
        canvas.setAttribute("role", "application");
        canvas.setAttribute(
          "aria-label",
          `${GAME_NAME}。完整食品點左半邊，缺料食品點右半邊。`,
        );
      },
    },
    scene: [BootScene, PreloadScene, MenuScene, GameScene, UIScene],
  };
}
