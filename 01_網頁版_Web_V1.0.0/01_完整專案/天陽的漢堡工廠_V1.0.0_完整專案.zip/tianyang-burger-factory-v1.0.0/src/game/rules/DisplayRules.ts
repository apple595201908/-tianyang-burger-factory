const MAX_RENDER_SCALE = 3;
const MAX_RENDER_PIXELS = 6_000_000;

export function computeRenderScale(
  deviceScale: number,
  cssWidth: number,
  cssHeight: number,
): number {
  const safeWidth = Math.max(1, cssWidth);
  const safeHeight = Math.max(1, cssHeight);
  const pixelBudgetScale = Math.sqrt(MAX_RENDER_PIXELS / (safeWidth * safeHeight));
  return Math.max(
    1,
    Math.min(MAX_RENDER_SCALE, deviceScale || 1, pixelBudgetScale),
  );
}
