import {
  FoodState,
  type GameplayAction,
  type TutorialCue,
} from "../types/GameTypes";

export type ActionOutcome = "SUCCESS" | "FAIL" | "IGNORE";

export function orientationForSize(
  width: number,
  height: number,
): "portrait" | "landscape" {
  return height >= width ? "portrait" : "landscape";
}

export function evaluateGameplayAction(
  state: FoodState,
  action: GameplayAction,
): ActionOutcome {
  if (state === FoodState.FILLED) {
    return action === "FINISH" ? "SUCCESS" : "FAIL";
  }

  if (state === FoodState.BASE_ONLY || state === FoodState.DEFECTIVE) {
    return action === "RETURN" ? "SUCCESS" : "FAIL";
  }

  return "IGNORE";
}

export function splitActionForX(
  pointerX: number,
  viewportX: number,
  viewportWidth: number,
): GameplayAction {
  return pointerX < viewportX + viewportWidth * 0.5 ? "FINISH" : "RETURN";
}

export function isActionableFoodState(state: FoodState): boolean {
  return state === FoodState.FILLED || state === FoodState.BASE_ONLY;
}

export function tutorialActionForCue(cue: TutorialCue | null): GameplayAction | null {
  if (cue === "FINISH_ACTION") return "FINISH";
  if (cue === "RETURN_ACTION") return "RETURN";
  return null;
}

export type ReturnOutfeedDisposition = "KEEP" | "HIDE" | "REMOVE";

export function returnOutfeedDisposition(
  state: FoodState,
  inspected: boolean,
  x: number,
  playerStationX: number,
): ReturnOutfeedDisposition {
  if (x <= playerStationX) return "KEEP";
  if (inspected || state === FoodState.INSPECTION || state === FoodState.APPROVED) {
    return "REMOVE";
  }
  if (state === FoodState.CAPPED) return "HIDE";
  return "KEEP";
}

export function hasMissedDeadline(
  state: FoodState,
  ingredientProcessed: boolean,
  x: number,
  deadlineX: number,
): boolean {
  return ingredientProcessed && isActionableFoodState(state) && x > deadlineX;
}

export interface ActiveCandidate {
  x: number;
  active: boolean;
  state: FoodState;
  ingredientProcessed: boolean;
}

export function pickClosestActiveItem<T extends ActiveCandidate>(
  items: readonly T[],
  stationX: number,
  actionStartX: number,
  actionEndX: number,
): T | null {
  let closest: T | null = null;
  let closestDistance = Number.POSITIVE_INFINITY;

  for (const item of items) {
    if (!item.active || !item.ingredientProcessed || !isActionableFoodState(item.state)) {
      continue;
    }

    if (item.x < actionStartX || item.x > actionEndX) continue;

    const distance = Math.abs(item.x - stationX);
    if (distance < closestDistance) {
      closest = item;
      closestDistance = distance;
    }
  }

  return closest;
}

export class InputGate {
  private lockUntil = 0;
  private acceptedPointer: number | null = null;

  public tryAccept(pointerId: number, now: number, lockMs: number): boolean {
    if (now < this.lockUntil || this.acceptedPointer !== null) {
      return false;
    }
    this.acceptedPointer = pointerId;
    this.lockUntil = now + lockMs;
    return true;
  }

  public release(pointerId: number): void {
    if (this.acceptedPointer === pointerId) {
      this.acceptedPointer = null;
    }
  }

  public reset(): void {
    this.acceptedPointer = null;
    this.lockUntil = 0;
  }

  public describe(now: number): string {
    if (this.acceptedPointer !== null) return `POINTER ${this.acceptedPointer}`;
    if (now < this.lockUntil) return "LOCKED";
    return "READY";
  }
}
