import type Phaser from "phaser";

export class InputManager {
  private static consumedKeys = new Set<string>();

  private static key(pointer: Phaser.Input.Pointer): string {
    return `${pointer.id}:${pointer.downTime}`;
  }

  public static consumeUIEvent(
    pointer: Phaser.Input.Pointer,
    event?: Phaser.Types.Input.EventData,
  ): void {
    const key = InputManager.key(pointer);
    InputManager.consumedKeys.add(key);
    event?.stopPropagation();
    globalThis.setTimeout(() => InputManager.consumedKeys.delete(key), 100);
  }

  public static isConsumed(pointer: Phaser.Input.Pointer): boolean {
    return InputManager.consumedKeys.has(InputManager.key(pointer));
  }

  public static reset(): void {
    InputManager.consumedKeys.clear();
  }
}
