import * as Phaser from "phaser";
import { GameTuning } from "../GameTuning";
import { orientationForSize } from "../rules/GameRules";
import type { GameLayout, SafeAreaInsets } from "../types/GameTypes";
import { DisplayManager } from "./DisplayManager";

function numericStyle(value: string): number {
  const parsed = Number.parseFloat(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

export class LayoutManager {
  private static currentLayout: GameLayout | null = null;

  private static readSafeArea(): SafeAreaInsets {
    if (typeof window === "undefined") {
      return { top: 0, right: 0, bottom: 0, left: 0 };
    }
    const probe = document.getElementById("safe-area-probe");
    if (!probe) return { top: 0, right: 0, bottom: 0, left: 0 };
    const style = window.getComputedStyle(probe);
    return {
      top: numericStyle(style.paddingTop),
      right: numericStyle(style.paddingRight),
      bottom: numericStyle(style.paddingBottom),
      left: numericStyle(style.paddingLeft),
    };
  }

  public static refresh(width: number, height: number): GameLayout {
    const renderScale = DisplayManager.renderScale;
    const cssSafeArea = LayoutManager.readSafeArea();
    const safeArea = {
      top: cssSafeArea.top * renderScale,
      right: cssSafeArea.right * renderScale,
      bottom: cssSafeArea.bottom * renderScale,
      left: cssSafeArea.left * renderScale,
    };
    const orientation = orientationForSize(width, height);
    const portrait = orientation === "portrait";
    const referenceWidth = portrait ? 390 : 844;
    const referenceHeight = portrait ? 844 : 390;
    const logicalWidth = width / renderScale;
    const logicalHeight = height / renderScale;
    const logicalUiScale = Phaser.Math.Clamp(
      Math.min(logicalWidth / referenceWidth, logicalHeight / referenceHeight),
      0.82,
      1.45,
    );
    const uiScale = logicalUiScale * renderScale;
    const motionScale =
      Phaser.Math.Clamp(logicalWidth / referenceWidth, 0.86, 1.7) * renderScale;
    const conveyorY = height * (portrait ? 0.56 : 0.61);
    const playerStationX = width * (portrait ? 0.67 : 0.64);
    const inspectorX = width * (portrait ? 0.9 : 0.87);
    const deadlineX = inspectorX + GameTuning.INSPECTOR_PASS_MARGIN * uiScale;
    const actionStartX = playerStationX - GameTuning.ACTION_LEAD * uiScale;
    const actionEndX = deadlineX;
    const spawnGap = Math.max(
      GameTuning.BASE_GAP * motionScale,
      actionEndX - actionStartX + GameTuning.MIN_ACTION_ZONE_GAP * renderScale,
    );
    const safeTop = safeArea.top;
    const safeBottom = safeArea.bottom;

    LayoutManager.currentLayout = {
      width,
      height,
      renderScale,
      orientation,
      safeArea,
      gameplayRect: new Phaser.Geom.Rectangle(0, 0, width, height),
      halfWidth: width * 0.5,
      conveyorY,
      conveyorHeight: 72 * uiScale,
      spawnX: -GameTuning.FOOD_BASE_WIDTH * uiScale,
      baseWorkerX: width * (portrait ? 0.09 : 0.08),
      ingredientWorkerX: width * (portrait ? 0.33 : 0.31),
      playerStationX,
      inspectorX,
      deadlineX,
      actionStartX,
      actionEndX,
      spawnGap,
      workerTopY: Math.max(safeTop + 118 * uiScale, conveyorY - 145 * uiScale),
      workerBottomY: Math.min(
        height - safeBottom - 82 * uiScale,
        conveyorY + 130 * uiScale,
      ),
      uiScale,
      motionScale,
    };
    return LayoutManager.currentLayout;
  }

  public static get current(): GameLayout {
    if (!LayoutManager.currentLayout) {
      throw new Error("LayoutManager.refresh must run before reading layout");
    }
    return LayoutManager.currentLayout;
  }
}
