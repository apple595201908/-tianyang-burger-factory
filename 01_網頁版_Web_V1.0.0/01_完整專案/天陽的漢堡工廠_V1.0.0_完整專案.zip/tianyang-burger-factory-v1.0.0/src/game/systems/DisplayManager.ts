import * as Phaser from "phaser";
import { computeRenderScale } from "../rules/DisplayRules";

const MAX_TEXT_RESOLUTION = 4;
const TEXT_OVERSAMPLE = 1.35;

export class DisplayManager {
  private static currentScale = 1;

  public static refreshRenderScale(
    cssWidth = typeof window === "undefined" ? 390 : window.innerWidth,
    cssHeight = typeof window === "undefined" ? 844 : window.innerHeight,
  ): number {
    const deviceScale = typeof window === "undefined" ? 1 : window.devicePixelRatio || 1;
    DisplayManager.currentScale = computeRenderScale(deviceScale, cssWidth, cssHeight);
    return DisplayManager.currentScale;
  }

  public static get renderScale(): number {
    return DisplayManager.currentScale;
  }

  public static install(game: Phaser.Game, parent: HTMLElement): void {
    let resizeFrame = 0;

    const resize = (): void => {
      resizeFrame = 0;
      const cssWidth = Math.max(1, parent.clientWidth || window.innerWidth);
      const cssHeight = Math.max(1, parent.clientHeight || window.innerHeight);
      const scale = DisplayManager.refreshRenderScale(cssWidth, cssHeight);
      const renderWidth = Math.max(1, Math.round(cssWidth * scale));
      const renderHeight = Math.max(1, Math.round(cssHeight * scale));

      if (game.scale.width !== renderWidth || game.scale.height !== renderHeight) {
        game.scale.resize(renderWidth, renderHeight);
      }
      game.canvas.style.width = `${cssWidth}px`;
      game.canvas.style.height = `${cssHeight}px`;
      game.canvas.style.imageRendering = "auto";
      DisplayManager.sharpenActiveText(game);
    };

    const scheduleResize = (): void => {
      if (resizeFrame) cancelAnimationFrame(resizeFrame);
      resizeFrame = requestAnimationFrame(resize);
    };

    const cleanup = (): void => {
      window.removeEventListener("resize", scheduleResize);
      window.removeEventListener("orientationchange", scheduleResize);
      window.visualViewport?.removeEventListener("resize", scheduleResize);
      if (resizeFrame) cancelAnimationFrame(resizeFrame);
    };

    window.addEventListener("resize", scheduleResize, { passive: true });
    window.addEventListener("orientationchange", scheduleResize, { passive: true });
    window.visualViewport?.addEventListener("resize", scheduleResize, { passive: true });
    game.events.once(Phaser.Core.Events.DESTROY, cleanup);
    scheduleResize();
  }

  public static sharpenActiveText(game: Phaser.Game): void {
    for (const scene of game.scene.getScenes(true)) {
      for (const child of scene.children.list) {
        DisplayManager.sharpenObject(child);
      }
    }
  }

  private static sharpenObject(child: Phaser.GameObjects.GameObject): void {
    if (child instanceof Phaser.GameObjects.Text) {
      const textResolution = Math.min(
        MAX_TEXT_RESOLUTION,
        DisplayManager.currentScale * TEXT_OVERSAMPLE,
      );
      if (Math.abs(child.style.resolution - textResolution) > 0.01) {
        child.setResolution(textResolution);
      }
      return;
    }

    if (child instanceof Phaser.GameObjects.Container) {
      for (const nested of child.list) {
        DisplayManager.sharpenObject(nested);
      }
    }
  }
}
