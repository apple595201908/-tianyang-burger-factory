import { GameTuning } from "../GameTuning";

export class DifficultyManager {
  public speedForScore(score: number): number {
    return Math.min(
      GameTuning.START_SPEED +
        score * GameTuning.SCORE_SPEED_STEP +
        Math.floor(score / 10) * GameTuning.TEN_SCORE_BONUS,
      GameTuning.MAX_SPEED,
    );
  }

  public isSpeedMilestone(score: number): boolean {
    return GameTuning.SPEED_MILESTONES.includes(score);
  }

  public reworkSkipRateForScore(score: number): number {
    return Math.min(
      GameTuning.REWORK_SKIP_START_RATE +
        Math.max(0, score) * GameTuning.REWORK_SKIP_SCORE_STEP,
      GameTuning.REWORK_SKIP_MAX_RATE,
    );
  }

  public shouldSkipRework(
    score: number,
    previousSkips: number,
    randomRoll: number,
  ): boolean {
    return (
      previousSkips < GameTuning.MAX_CONSECUTIVE_REWORK_SKIPS &&
      randomRoll < this.reworkSkipRateForScore(score)
    );
  }

  public spawnIntervalMs(score: number): number {
    return (GameTuning.BASE_GAP / this.speedForScore(score)) * 1000;
  }
}
