import * as Phaser from "phaser";
import { GameTuning } from "../GameTuning";
import { splitActionForX, InputGate } from "../rules/GameRules";
import { GameState, type GameplayAction } from "../types/GameTypes";
import { InputManager } from "./InputManager";
import { LayoutManager } from "./LayoutManager";

export interface SplitTouchCallbacks {
  getState(): GameState;
  hasActiveItem(): boolean;
  dispatch(action: GameplayAction, pointer: Phaser.Input.Pointer): void;
}

export class SplitTouchController {
  private readonly gate = new InputGate();
  private enabled = false;

  public constructor(
    private readonly scene: Phaser.Scene,
    private readonly callbacks: SplitTouchCallbacks,
  ) {}

  public enable(): void {
    if (this.enabled) return;
    this.enabled = true;
    this.scene.input.on(Phaser.Input.Events.POINTER_DOWN, this.onPointerDown, this);
    this.scene.input.on(Phaser.Input.Events.POINTER_UP, this.onPointerUp, this);
  }

  public destroy(): void {
    if (!this.enabled) return;
    this.enabled = false;
    this.scene.input.off(Phaser.Input.Events.POINTER_DOWN, this.onPointerDown, this);
    this.scene.input.off(Phaser.Input.Events.POINTER_UP, this.onPointerUp, this);
    this.gate.reset();
  }

  public reset(): void {
    this.gate.reset();
  }

  public describe(): string {
    return this.gate.describe(performance.now());
  }

  private onPointerDown(pointer: Phaser.Input.Pointer): void {
    if (InputManager.isConsumed(pointer)) return;
    const state = this.callbacks.getState();
    if (state !== GameState.PLAYING && state !== GameState.TUTORIAL) return;
    if (!this.callbacks.hasActiveItem()) return;
    if (!this.gate.tryAccept(pointer.id, performance.now(), GameTuning.INPUT_LOCK_MS)) {
      return;
    }

    const layout = LayoutManager.current;
    const action = splitActionForX(
      pointer.x,
      layout.gameplayRect.x,
      layout.gameplayRect.width,
    );
    this.callbacks.dispatch(action, pointer);
  }

  private onPointerUp(pointer: Phaser.Input.Pointer): void {
    this.gate.release(pointer.id);
  }
}
