import { StorageManager } from "./StorageManager";

export type SoundName =
  | "finish"
  | "return"
  | "approved"
  | "speedup"
  | "fail"
  | "button";

export type AudioAssetName = SoundName | "bgm";

export const AUDIO_ASSET_PATHS: Readonly<Record<AudioAssetName, string>> = Object.freeze({
  bgm: "/audio/factory-rush-bgm.mp3",
  finish: "/audio/finish.wav",
  return: "/audio/return.wav",
  approved: "/audio/approved.wav",
  speedup: "/audio/speedup.wav",
  fail: "/audio/fail.wav",
  button: "/audio/button.wav",
});

interface ToneDefinition {
  frequency: number;
  duration: number;
  type: OscillatorType;
  gain: number;
  endFrequency?: number;
}

const FALLBACK_TONES: Readonly<Record<SoundName, ToneDefinition>> = Object.freeze({
  finish: { frequency: 620, endFrequency: 850, duration: 0.085, type: "triangle", gain: 0.2 },
  return: { frequency: 430, endFrequency: 240, duration: 0.11, type: "square", gain: 0.11 },
  approved: { frequency: 900, endFrequency: 1180, duration: 0.075, type: "sine", gain: 0.16 },
  speedup: { frequency: 520, endFrequency: 1040, duration: 0.18, type: "triangle", gain: 0.16 },
  fail: { frequency: 170, endFrequency: 92, duration: 0.32, type: "sawtooth", gain: 0.16 },
  button: { frequency: 480, endFrequency: 560, duration: 0.055, type: "sine", gain: 0.12 },
});

export class AudioManager {
  private static instance: AudioManager | null = null;

  private context: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private effectsGain: GainNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;
  private bgmSource: AudioBufferSourceNode | null = null;
  private readonly encodedAssets = new Map<AudioAssetName, ArrayBuffer>();
  private readonly decodedAssets = new Map<AudioAssetName, AudioBuffer>();
  private decodePromise: Promise<void> | null = null;
  private muted = StorageManager.get().mute;

  public static get shared(): AudioManager {
    AudioManager.instance ??= new AudioManager();
    return AudioManager.instance;
  }

  public registerEncodedAsset(
    name: AudioAssetName,
    data: ArrayBuffer | ArrayBufferView,
  ): void {
    const copied = data instanceof ArrayBuffer
      ? data.slice(0)
      : new Uint8Array(data.buffer, data.byteOffset, data.byteLength).slice().buffer;
    this.encodedAssets.set(name, copied);
    this.decodePromise = null;
  }

  public async unlock(): Promise<void> {
    if (!this.context) this.createAudioGraph();
    if (!this.context) return;
    if (this.context.state === "suspended") await this.context.resume();
    this.applyMuteState(false);
    this.decodePromise ??= this.decodeAssets();
    await this.decodePromise;
  }

  public play(name: SoundName): void {
    if (this.muted || !this.context || this.context.state !== "running") return;
    const buffer = this.decodedAssets.get(name);
    if (!buffer || !this.effectsGain) {
      this.playTone(FALLBACK_TONES[name]);
      return;
    }
    const source = this.context.createBufferSource();
    source.buffer = buffer;
    source.connect(this.effectsGain);
    source.start();
  }

  public startBgm(): void {
    if (
      this.bgmSource ||
      !this.context ||
      this.context.state !== "running" ||
      !this.musicGain
    ) {
      return;
    }
    const buffer = this.decodedAssets.get("bgm");
    if (!buffer) return;
    const source = this.context.createBufferSource();
    source.buffer = buffer;
    source.loop = true;
    source.loopStart = 0;
    source.loopEnd = buffer.duration;
    source.connect(this.musicGain);
    source.onended = () => {
      if (this.bgmSource === source) this.bgmSource = null;
    };
    source.start();
    this.bgmSource = source;
  }

  public stopBgm(): void {
    const source = this.bgmSource;
    this.bgmSource = null;
    if (!source) return;
    source.onended = null;
    try {
      source.stop();
    } catch {
      // A source that already ended needs no further cleanup.
    }
    source.disconnect();
  }

  public toggleMute(): boolean {
    this.muted = !this.muted;
    StorageManager.setMute(this.muted);
    this.applyMuteState(true);
    return this.muted;
  }

  public get isMuted(): boolean {
    return this.muted;
  }

  private createAudioGraph(): void {
    const AudioContextClass = window.AudioContext;
    this.context = new AudioContextClass({ latencyHint: "interactive" });
    this.masterGain = this.context.createGain();
    this.musicGain = this.context.createGain();
    this.effectsGain = this.context.createGain();
    this.compressor = this.context.createDynamicsCompressor();

    this.musicGain.gain.value = 0.21;
    this.effectsGain.gain.value = 0.58;
    this.masterGain.gain.value = this.muted ? 0 : 1;
    this.compressor.threshold.value = -12;
    this.compressor.knee.value = 12;
    this.compressor.ratio.value = 4;
    this.compressor.attack.value = 0.003;
    this.compressor.release.value = 0.16;

    this.musicGain.connect(this.masterGain);
    this.effectsGain.connect(this.masterGain);
    this.masterGain.connect(this.compressor);
    this.compressor.connect(this.context.destination);
  }

  private async decodeAssets(): Promise<void> {
    if (!this.context) return;
    const context = this.context;
    const entries = [...this.encodedAssets.entries()];
    await Promise.all(
      entries.map(async ([name, encoded]) => {
        if (this.decodedAssets.has(name)) return;
        try {
          const decoded = await context.decodeAudioData(encoded.slice(0));
          this.decodedAssets.set(name, decoded);
        } catch {
          // Procedural fallback tones keep gameplay feedback available if a codec fails.
        }
      }),
    );
  }

  private applyMuteState(smooth: boolean): void {
    if (!this.context || !this.masterGain) return;
    const now = this.context.currentTime;
    const target = this.muted ? 0 : 1;
    this.masterGain.gain.cancelScheduledValues(now);
    if (smooth) {
      this.masterGain.gain.setTargetAtTime(target, now, 0.015);
    } else {
      this.masterGain.gain.setValueAtTime(target, now);
    }
  }

  private playTone(definition: ToneDefinition): void {
    if (!this.context || !this.effectsGain) return;
    const now = this.context.currentTime;
    const oscillator = this.context.createOscillator();
    const gain = this.context.createGain();
    oscillator.type = definition.type;
    oscillator.frequency.setValueAtTime(definition.frequency, now);
    if (definition.endFrequency) {
      oscillator.frequency.exponentialRampToValueAtTime(
        Math.max(20, definition.endFrequency),
        now + definition.duration,
      );
    }
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(definition.gain, now + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + definition.duration);
    oscillator.connect(gain);
    gain.connect(this.effectsGain);
    oscillator.start(now);
    oscillator.stop(now + definition.duration + 0.01);
  }
}
