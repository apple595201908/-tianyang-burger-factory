export type LineReturnPhase = "IDLE" | "REWINDING" | "REWORKING";

export interface LineItem {
  active: boolean;
  x: number;
}

export interface LineReturnUpdate<T extends LineItem> {
  target: T | null;
  shiftedDistance: number;
  enteredRework: boolean;
  completed: boolean;
}

export class LineReturnController<T extends LineItem> {
  private targetItem: T | null = null;
  private destinationX = 0;
  private reworkRemainingMs = 0;
  private currentPhase: LineReturnPhase = "IDLE";

  public get active(): boolean {
    return this.targetItem !== null;
  }

  public get phase(): LineReturnPhase {
    return this.currentPhase;
  }

  public start(target: T, destinationX: number, reworkMs: number): boolean {
    if (this.targetItem) return false;
    this.targetItem = target;
    this.destinationX = Math.min(destinationX, target.x);
    this.reworkRemainingMs = Math.max(0, reworkMs);
    this.currentPhase = "REWINDING";
    return true;
  }

  public update(
    deltaSeconds: number,
    returnSpeed: number,
    items: readonly T[],
  ): LineReturnUpdate<T> {
    const target = this.targetItem;
    if (!target) return this.emptyUpdate();

    if (!target.active) {
      this.reset();
      return this.emptyUpdate();
    }

    if (this.currentPhase === "REWINDING") {
      const remaining = Math.max(0, target.x - this.destinationX);
      const shiftedDistance = Math.min(
        remaining,
        Math.max(0, returnSpeed * Math.max(0, deltaSeconds)),
      );

      if (shiftedDistance > 0) {
        for (const item of items) {
          if (item.active) item.x -= shiftedDistance;
        }
      }

      const enteredRework = target.x <= this.destinationX + 0.001;
      if (enteredRework) this.currentPhase = "REWORKING";

      return {
        target,
        shiftedDistance,
        enteredRework,
        completed: false,
      };
    }

    this.reworkRemainingMs -= Math.max(0, deltaSeconds) * 1000;
    if (this.reworkRemainingMs > 0) {
      return {
        target,
        shiftedDistance: 0,
        enteredRework: false,
        completed: false,
      };
    }

    this.reset();
    return {
      target,
      shiftedDistance: 0,
      enteredRework: false,
      completed: true,
    };
  }

  public setDestination(destinationX: number): void {
    if (this.currentPhase === "REWINDING" && this.targetItem) {
      this.destinationX = Math.min(destinationX, this.targetItem.x);
    }
  }

  public reset(): void {
    this.targetItem = null;
    this.destinationX = 0;
    this.reworkRemainingMs = 0;
    this.currentPhase = "IDLE";
  }

  private emptyUpdate(): LineReturnUpdate<T> {
    return {
      target: null,
      shiftedDistance: 0,
      enteredRework: false,
      completed: false,
    };
  }
}
