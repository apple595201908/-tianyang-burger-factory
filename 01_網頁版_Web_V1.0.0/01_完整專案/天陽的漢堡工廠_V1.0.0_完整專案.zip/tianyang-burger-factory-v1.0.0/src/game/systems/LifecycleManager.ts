import * as Phaser from "phaser";

export interface LifecycleCallbacks {
  suspend(): void;
  resize(width: number, height: number): void;
}

export class LifecycleManager {
  private resizeFrame = 0;

  public constructor(
    private readonly scene: Phaser.Scene,
    private readonly callbacks: LifecycleCallbacks,
  ) {
    document.addEventListener("visibilitychange", this.onVisibilityChange, {
      passive: true,
    });
    window.addEventListener("blur", this.onSuspend, { passive: true });
    window.addEventListener("pagehide", this.onSuspend, { passive: true });
    window.addEventListener("pageshow", this.onPageShow, { passive: true });
    window.addEventListener("focus", this.onFocus, { passive: true });
    window.addEventListener("orientationchange", this.onOrientationChange, {
      passive: true,
    });
    scene.scale.on(Phaser.Scale.Events.RESIZE, this.onScaleResize, this);
  }

  public destroy(): void {
    document.removeEventListener("visibilitychange", this.onVisibilityChange);
    window.removeEventListener("blur", this.onSuspend);
    window.removeEventListener("pagehide", this.onSuspend);
    window.removeEventListener("pageshow", this.onPageShow);
    window.removeEventListener("focus", this.onFocus);
    window.removeEventListener("orientationchange", this.onOrientationChange);
    this.scene.scale.off(Phaser.Scale.Events.RESIZE, this.onScaleResize, this);
    if (this.resizeFrame) cancelAnimationFrame(this.resizeFrame);
  }

  private readonly onVisibilityChange = (): void => {
    if (document.hidden) this.callbacks.suspend();
  };

  private readonly onSuspend = (): void => {
    this.callbacks.suspend();
  };

  private readonly onPageShow = (): void => {
    if (document.hidden) return;
    // Resuming remains an explicit user action in the pause overlay.
    this.scheduleResize();
  };

  private readonly onFocus = (): void => {
    // Focus never resumes gameplay automatically; it only refreshes viewport metrics.
    this.scheduleResize();
  };

  private readonly onOrientationChange = (): void => {
    this.scheduleResize();
  };

  private scheduleResize(): void {
    if (this.resizeFrame) cancelAnimationFrame(this.resizeFrame);
    this.resizeFrame = requestAnimationFrame(() => {
      this.resizeFrame = 0;
      this.callbacks.resize(this.scene.scale.width, this.scene.scale.height);
    });
  }

  private onScaleResize(gameSize: Phaser.Structs.Size): void {
    this.callbacks.resize(gameSize.width, gameSize.height);
  }
}
