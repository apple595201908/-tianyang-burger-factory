import type { SaveData } from "../types/GameTypes";

const STORAGE_KEY = "factoryRush.save";
const CURRENT_TUTORIAL_VERSION = 2;

const DEFAULT_SAVE: SaveData = {
  saveVersion: 2,
  bestScore: 0,
  mute: false,
  tutorialCompleted: false,
  tutorialVersion: CURRENT_TUTORIAL_VERSION,
};

export class StorageManager {
  private static data: SaveData = StorageManager.load();

  private static load(): SaveData {
    if (typeof window === "undefined") return { ...DEFAULT_SAVE };
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (!raw) return { ...DEFAULT_SAVE };
      const parsed = JSON.parse(raw) as Partial<SaveData>;
      return {
        ...DEFAULT_SAVE,
        ...parsed,
        saveVersion: 2,
        bestScore: Math.max(0, Number(parsed.bestScore) || 0),
        mute: Boolean(parsed.mute),
        tutorialCompleted:
          Boolean(parsed.tutorialCompleted) &&
          Number(parsed.tutorialVersion) === CURRENT_TUTORIAL_VERSION,
        tutorialVersion: CURRENT_TUTORIAL_VERSION,
      };
    } catch {
      return { ...DEFAULT_SAVE };
    }
  }

  private static persist(): void {
    if (typeof window === "undefined") return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(StorageManager.data));
    } catch {
      // Private browsing and full storage must not block gameplay.
    }
  }

  public static get(): Readonly<SaveData> {
    return StorageManager.data;
  }

  public static setBestScore(score: number): void {
    if (score <= StorageManager.data.bestScore) return;
    StorageManager.data.bestScore = score;
    StorageManager.persist();
  }

  public static setMute(mute: boolean): void {
    StorageManager.data.mute = mute;
    StorageManager.persist();
  }

  public static completeTutorial(): void {
    StorageManager.data.tutorialCompleted = true;
    StorageManager.data.tutorialVersion = CURRENT_TUTORIAL_VERSION;
    StorageManager.persist();
  }
}
