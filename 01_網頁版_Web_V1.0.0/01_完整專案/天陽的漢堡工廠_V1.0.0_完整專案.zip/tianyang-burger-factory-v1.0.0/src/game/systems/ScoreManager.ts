import { StorageManager } from "./StorageManager";

export class ScoreManager {
  private currentScore = 0;
  private startingBest = StorageManager.get().bestScore;

  public reset(): void {
    this.startingBest = StorageManager.get().bestScore;
    this.currentScore = 0;
  }

  public increment(): number {
    this.currentScore += 1;
    StorageManager.setBestScore(this.currentScore);
    return this.currentScore;
  }

  public get score(): number {
    return this.currentScore;
  }

  public get best(): number {
    return Math.max(StorageManager.get().bestScore, this.currentScore);
  }

  public get isNewBest(): boolean {
    return this.currentScore > this.startingBest;
  }
}
