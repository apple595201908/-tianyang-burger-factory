export class SeededRng {
  private state: number;

  public constructor(seed?: number) {
    const fallback = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    this.state = (seed ?? fallback) >>> 0 || 0x6d2b79f5;
  }

  public next(): number {
    let value = (this.state += 0x6d2b79f5);
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  }

  public chance(probability: number): boolean {
    return this.next() < probability;
  }
}

