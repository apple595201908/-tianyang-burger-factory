export class SpawnManager {
  private travelled = Number.POSITIVE_INFINITY;

  public reset(spawnImmediately = true): void {
    this.travelled = spawnImmediately ? Number.POSITIVE_INFINITY : 0;
  }

  public update(
    deltaSeconds: number,
    travelSpeed: number,
    gap: number,
  ): number | null {
    if (!Number.isFinite(this.travelled)) {
      this.travelled = 0;
      return 0;
    }

    this.travelled += travelSpeed * deltaSeconds;
    if (this.travelled < gap) return null;
    const overflow = this.travelled - gap;
    this.travelled = overflow;
    return overflow;
  }

  public rescaleProgress(ratio: number): void {
    if (Number.isFinite(this.travelled)) this.travelled *= ratio;
  }

  public rewind(distance: number): void {
    if (Number.isFinite(this.travelled)) {
      this.travelled -= Math.max(0, distance);
    }
  }
}
