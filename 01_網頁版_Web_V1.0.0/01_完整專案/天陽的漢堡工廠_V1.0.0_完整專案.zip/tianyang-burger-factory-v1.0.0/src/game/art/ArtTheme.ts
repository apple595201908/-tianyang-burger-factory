export const ArtTheme = Object.freeze({
  colors: Object.freeze({
    ink: 0x071116,
    inkSoft: 0x10242d,
    panel: 0x16313a,
    panelLight: 0x214653,
    steelDark: 0x1d343d,
    steel: 0x4f6b73,
    steelLight: 0xa8c1c3,
    cream: 0xfff2cf,
    amber: 0xffc857,
    amberLight: 0xffe49a,
    orange: 0xf58b47,
    teal: 0x55d6c2,
    cyan: 0x65dce8,
    coral: 0xf2746b,
    green: 0x68d391,
    purple: 0xa78bda,
  }),
  fonts: Object.freeze({
    display:
      '"PingFang TC", "Noto Sans TC", "Microsoft JhengHei", "Arial Black", sans-serif',
    rounded:
      '"PingFang TC", "Noto Sans TC", "Microsoft JhengHei", "Arial Rounded MT Bold", sans-serif',
    body:
      '"PingFang TC", "Noto Sans TC", "Microsoft JhengHei", "Trebuchet MS", sans-serif',
  }),
});

export type WorkerPalette = Readonly<{
  primary: number;
  shade: number;
  highlight: number;
  accent: number;
}>;

export const WorkerPalettes = Object.freeze({
  BASE: Object.freeze({
    primary: 0x42bcae,
    shade: 0x247d78,
    highlight: 0x8ce5d5,
    accent: 0xffd166,
  }),
  INGREDIENT: Object.freeze({
    primary: 0xe66e6e,
    shade: 0xa94350,
    highlight: 0xffaaa0,
    accent: 0x78dfb4,
  }),
  PLAYER: Object.freeze({
    primary: 0xf0a14a,
    shade: 0xb8612e,
    highlight: 0xffd17c,
    accent: 0x65dce8,
  }),
  INSPECTOR: Object.freeze({
    primary: 0x9d77d8,
    shade: 0x624a9e,
    highlight: 0xc9adf4,
    accent: 0x7be0a0,
  }),
});
