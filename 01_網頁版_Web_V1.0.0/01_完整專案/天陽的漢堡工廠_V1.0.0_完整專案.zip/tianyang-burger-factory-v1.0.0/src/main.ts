import * as Phaser from "phaser";
import { makeGameConfig } from "./game/config";
import { DisplayManager } from "./game/systems/DisplayManager";

export function createFactoryRushGame(parent: HTMLElement): Phaser.Game {
  const renderScale = DisplayManager.refreshRenderScale(
    parent.clientWidth || window.innerWidth,
    parent.clientHeight || window.innerHeight,
  );
  const game = new Phaser.Game(makeGameConfig(parent, renderScale));
  DisplayManager.install(game, parent);
  return game;
}

export function registerFactoryRushServiceWorker(): void {
  if (!("serviceWorker" in navigator) || window.location.protocol !== "https:") return;
  const register = () => {
    void navigator.serviceWorker.register("/sw.js", { scope: "/" });
  };
  if (document.readyState === "complete") register();
  else window.addEventListener("load", register, { once: true });
}
