const CACHE_NAME = "tianyang-burger-factory-shell-v5";
const CORE_ASSETS = [
  "/",
  "/manifest.webmanifest",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
  "/assets/factory-bg-portrait-hd.webp",
  "/assets/factory-bg-landscape-hd.webp",
  "/audio/factory-rush-bgm.mp3",
  "/audio/finish.wav",
  "/audio/return.wav",
  "/audio/approved.wav",
  "/audio/speedup.wav",
  "/audio/fail.wav",
  "/audio/button.wav",
];

async function precacheGameShell() {
  const cache = await caches.open(CACHE_NAME);
  await cache.addAll(CORE_ASSETS);

  try {
    const response = await fetch("/", { cache: "reload" });
    if (!response.ok) return;
    await cache.put("/", response.clone());
    const html = await response.text();
    const localAssets = [...html.matchAll(/(?:src|href)=["']([^"']+)["']/g)]
      .map((match) => match[1])
      .filter((path) => path.startsWith("/") && path !== "/")
      .filter((path, index, list) => list.indexOf(path) === index);
    await Promise.allSettled(localAssets.map((path) => cache.add(path)));
  } finally {
    await self.skipWaiting();
  }
}

self.addEventListener("install", (event) => {
  event.waitUntil(precacheGameShell());
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          void caches.open(CACHE_NAME).then((cache) => cache.put("/", copy));
          return response;
        })
        .catch(async () => {
          const cached = await caches.match("/");
          return cached ?? new Response("天陽的漢堡工廠目前離線。", {
            status: 503,
            headers: { "Content-Type": "text/plain; charset=utf-8" },
          });
        }),
    );
    return;
  }

  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) return cached;
      return fetch(request).then((response) => {
        if (response.ok) {
          const copy = response.clone();
          void caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
        }
        return response;
      });
    }),
  );
});
