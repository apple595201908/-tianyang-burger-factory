import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { join, resolve } from "node:path";
import { spawnSync } from "node:child_process";

const SAMPLE_RATE = 44_100;
const TAU = Math.PI * 2;
const outputDir = resolve("public/audio");
mkdirSync(outputDir, { recursive: true });

let randomState = 0x5f3759df;
function random() {
  randomState ^= randomState << 13;
  randomState ^= randomState >>> 17;
  randomState ^= randomState << 5;
  return (randomState >>> 0) / 0x1_0000_0000;
}

function note(midi) {
  return 440 * 2 ** ((midi - 69) / 12);
}

function makeStereo(duration) {
  const length = Math.ceil(duration * SAMPLE_RATE);
  return {
    duration,
    left: new Float32Array(length),
    right: new Float32Array(length),
  };
}

function envelope(t, duration, attack = 0.008, release = 0.08) {
  const rise = Math.min(1, t / Math.max(0.0001, attack));
  const fall = Math.min(1, (duration - t) / Math.max(0.0001, release));
  return Math.max(0, Math.min(rise, fall));
}

function panGains(pan) {
  const angle = ((Math.max(-1, Math.min(1, pan)) + 1) * Math.PI) / 4;
  return [Math.cos(angle), Math.sin(angle)];
}

function addSample(buffer, index, sample, pan = 0, wrap = false) {
  let target = index;
  if (wrap) target = ((target % buffer.left.length) + buffer.left.length) % buffer.left.length;
  if (target < 0 || target >= buffer.left.length) return;
  const [leftGain, rightGain] = panGains(pan);
  buffer.left[target] += sample * leftGain;
  buffer.right[target] += sample * rightGain;
}

function addSynth(buffer, options) {
  const {
    start,
    duration,
    frequency,
    endFrequency = frequency,
    gain,
    pan = 0,
    shape = "triangle",
    attack = 0.008,
    release = Math.min(0.1, duration * 0.5),
    harmonics = 1,
    wrap = false,
  } = options;
  const startIndex = Math.round(start * SAMPLE_RATE);
  const sampleCount = Math.ceil(duration * SAMPLE_RATE);
  let phase = 0;
  for (let i = 0; i < sampleCount; i += 1) {
    const t = i / SAMPLE_RATE;
    const progress = t / duration;
    const currentFrequency = frequency * (endFrequency / frequency) ** progress;
    phase += (TAU * currentFrequency) / SAMPLE_RATE;
    let wave = 0;
    if (shape === "sine") {
      wave = Math.sin(phase);
    } else if (shape === "square") {
      wave = Math.sin(phase) >= 0 ? 1 : -1;
    } else if (shape === "saw") {
      for (let harmonic = 1; harmonic <= harmonics; harmonic += 1) {
        wave += Math.sin(phase * harmonic) / harmonic;
      }
      wave *= 0.62;
    } else {
      wave = (2 / Math.PI) * Math.asin(Math.sin(phase));
      wave += Math.sin(phase * 2) * 0.08;
    }
    const env = envelope(t, duration, attack, release);
    addSample(buffer, startIndex + i, wave * gain * env, pan, wrap);
  }
}

function addNoise(buffer, options) {
  const {
    start,
    duration,
    gain,
    pan = 0,
    decay = 12,
    highPass = 0.65,
    wrap = false,
  } = options;
  const startIndex = Math.round(start * SAMPLE_RATE);
  const sampleCount = Math.ceil(duration * SAMPLE_RATE);
  let previous = 0;
  for (let i = 0; i < sampleCount; i += 1) {
    const t = i / SAMPLE_RATE;
    const noise = random() * 2 - 1;
    const filtered = noise - previous * highPass;
    previous = noise;
    const env = Math.exp(-decay * t) * envelope(t, duration, 0.001, 0.015);
    addSample(buffer, startIndex + i, filtered * gain * env, pan, wrap);
  }
}

function addKick(buffer, start, gain = 0.54, wrap = false) {
  addSynth(buffer, {
    start,
    duration: 0.19,
    frequency: 150,
    endFrequency: 47,
    gain,
    shape: "sine",
    attack: 0.001,
    release: 0.16,
    wrap,
  });
  addNoise(buffer, {
    start,
    duration: 0.018,
    gain: gain * 0.15,
    decay: 90,
    highPass: 0.9,
    wrap,
  });
}

function addSnare(buffer, start, gain = 0.22, wrap = false) {
  addNoise(buffer, {
    start,
    duration: 0.16,
    gain,
    decay: 19,
    highPass: 0.82,
    wrap,
  });
  addSynth(buffer, {
    start,
    duration: 0.1,
    frequency: 205,
    endFrequency: 155,
    gain: gain * 0.45,
    shape: "triangle",
    attack: 0.001,
    release: 0.09,
    wrap,
  });
}

function addHat(buffer, start, gain = 0.055, pan = 0, open = false, wrap = false) {
  addNoise(buffer, {
    start,
    duration: open ? 0.16 : 0.045,
    gain,
    pan,
    decay: open ? 18 : 62,
    highPass: 0.94,
    wrap,
  });
}

function addPluck(buffer, start, midi, gain, pan, duration = 0.18, wrap = false) {
  const frequency = note(midi);
  addSynth(buffer, {
    start,
    duration,
    frequency,
    gain,
    pan,
    shape: "triangle",
    attack: 0.003,
    release: duration * 0.82,
    wrap,
  });
  addSynth(buffer, {
    start,
    duration: duration * 0.72,
    frequency: frequency * 2,
    gain: gain * 0.18,
    pan: -pan * 0.7,
    shape: "sine",
    attack: 0.002,
    release: duration * 0.6,
    wrap,
  });
}

function addBass(buffer, start, midi, duration, gain = 0.15, wrap = false) {
  const frequency = note(midi);
  addSynth(buffer, {
    start,
    duration,
    frequency,
    endFrequency: frequency * 0.995,
    gain,
    shape: "saw",
    harmonics: 3,
    attack: 0.008,
    release: Math.min(0.12, duration * 0.4),
    wrap,
  });
  addSynth(buffer, {
    start,
    duration,
    frequency: frequency / 2,
    gain: gain * 0.46,
    shape: "sine",
    attack: 0.006,
    release: Math.min(0.13, duration * 0.45),
    wrap,
  });
}

function addEcho(buffer, delaySeconds, gain) {
  const delay = Math.round(delaySeconds * SAMPLE_RATE);
  const originalLeft = buffer.left.slice();
  const originalRight = buffer.right.slice();
  for (let i = 0; i < buffer.left.length; i += 1) {
    const source = (i - delay + buffer.left.length) % buffer.left.length;
    buffer.left[i] += originalRight[source] * gain;
    buffer.right[i] += originalLeft[source] * gain;
  }
}

function master(buffer, targetPeak = 0.9) {
  let peak = 0;
  for (let i = 0; i < buffer.left.length; i += 1) {
    buffer.left[i] = Math.tanh(buffer.left[i] * 1.18);
    buffer.right[i] = Math.tanh(buffer.right[i] * 1.18);
    peak = Math.max(peak, Math.abs(buffer.left[i]), Math.abs(buffer.right[i]));
  }
  const scale = peak > 0 ? targetPeak / peak : 1;
  for (let i = 0; i < buffer.left.length; i += 1) {
    buffer.left[i] *= scale;
    buffer.right[i] *= scale;
  }
}

function writeWav(path, buffer) {
  const channels = 2;
  const bytesPerSample = 2;
  const dataLength = buffer.left.length * channels * bytesPerSample;
  const wav = Buffer.alloc(44 + dataLength);
  wav.write("RIFF", 0);
  wav.writeUInt32LE(36 + dataLength, 4);
  wav.write("WAVE", 8);
  wav.write("fmt ", 12);
  wav.writeUInt32LE(16, 16);
  wav.writeUInt16LE(1, 20);
  wav.writeUInt16LE(channels, 22);
  wav.writeUInt32LE(SAMPLE_RATE, 24);
  wav.writeUInt32LE(SAMPLE_RATE * channels * bytesPerSample, 28);
  wav.writeUInt16LE(channels * bytesPerSample, 32);
  wav.writeUInt16LE(16, 34);
  wav.write("data", 36);
  wav.writeUInt32LE(dataLength, 40);
  let offset = 44;
  for (let i = 0; i < buffer.left.length; i += 1) {
    wav.writeInt16LE(Math.round(Math.max(-1, Math.min(1, buffer.left[i])) * 32767), offset);
    wav.writeInt16LE(Math.round(Math.max(-1, Math.min(1, buffer.right[i])) * 32767), offset + 2);
    offset += 4;
  }
  writeFileSync(path, wav);
}

function createBgm() {
  const bpm = 125;
  const beat = 60 / bpm;
  const bars = 16;
  const duration = bars * 4 * beat;
  const buffer = makeStereo(duration);
  const chords = [
    [50, 53, 57, 60],
    [46, 50, 53, 58],
    [53, 57, 60, 65],
    [48, 52, 55, 60],
  ];
  const bassRoots = [38, 34, 41, 36];
  const melody = [
    74, 77, 81, 77, 72, 74, 77, 69,
    70, 74, 77, 74, 69, 70, 74, 65,
    72, 77, 81, 84, 81, 77, 72, 69,
    67, 72, 76, 79, 76, 72, 67, 64,
  ];

  for (let bar = 0; bar < bars; bar += 1) {
    const barStart = bar * 4 * beat;
    const chord = chords[bar % chords.length];
    const root = bassRoots[bar % bassRoots.length];

    for (let step = 0; step < 8; step += 1) {
      const time = barStart + step * beat * 0.5;
      if (step === 0 || step === 4 || (bar >= 8 && step === 6)) addKick(buffer, time, 0.5, true);
      if (step === 2 || step === 6) addSnare(buffer, time, 0.205, true);
      addHat(buffer, time, step % 2 === 0 ? 0.046 : 0.036, step % 2 ? 0.24 : -0.24, step === 7, true);
      if (bar >= 4) addHat(buffer, time + beat * 0.25, 0.022, -0.08, false, true);

      const bassMidi = step === 6 ? root + 7 : step === 3 ? root + 12 : root;
      if (![1, 5].includes(step)) addBass(buffer, time, bassMidi, beat * 0.42, 0.135, true);

      const arpMidi = chord[(step + bar) % chord.length] + 12;
      addPluck(buffer, time + beat * 0.02, arpMidi, 0.065, step % 2 ? 0.36 : -0.36, beat * 0.36, true);
    }

    if (bar % 4 === 3) {
      for (let tick = 0; tick < 4; tick += 1) {
        addNoise(buffer, {
          start: barStart + (3.5 + tick * 0.125) * beat,
          duration: 0.035,
          gain: 0.03 + tick * 0.008,
          pan: tick % 2 ? 0.42 : -0.42,
          decay: 75,
          highPass: 0.9,
          wrap: true,
        });
      }
    }

    if (bar >= 4) {
      const phraseOffset = ((bar - 4) % 4) * 8;
      for (let step = 0; step < 8; step += 1) {
        if ((bar < 8 && step % 2 === 1) || (bar >= 12 && step === 6)) continue;
        const midi = melody[(phraseOffset + step) % melody.length];
        addPluck(
          buffer,
          barStart + step * beat * 0.5 + beat * 0.04,
          midi,
          bar >= 12 ? 0.076 : 0.062,
          step % 2 ? 0.18 : -0.18,
          beat * 0.42,
          true,
        );
      }
    }
  }

  addEcho(buffer, beat * 0.75, 0.105);
  addEcho(buffer, beat * 1.5, 0.045);
  master(buffer, 0.88);
  return buffer;
}

function createFinish() {
  const buffer = makeStereo(0.16);
  addNoise(buffer, { start: 0, duration: 0.045, gain: 0.16, decay: 55, highPass: 0.72 });
  addSynth(buffer, { start: 0, duration: 0.115, frequency: 560, endFrequency: 880, gain: 0.32, shape: "triangle", release: 0.07 });
  addSynth(buffer, { start: 0.04, duration: 0.1, frequency: 880, endFrequency: 1120, gain: 0.2, pan: 0.18, shape: "sine", release: 0.07 });
  master(buffer, 0.82);
  return buffer;
}

function createReturn() {
  const buffer = makeStereo(0.22);
  addNoise(buffer, { start: 0, duration: 0.18, gain: 0.11, pan: -0.3, decay: 15, highPass: 0.9 });
  addSynth(buffer, { start: 0, duration: 0.18, frequency: 520, endFrequency: 190, gain: 0.31, pan: -0.22, shape: "triangle", release: 0.1 });
  addSynth(buffer, { start: 0.055, duration: 0.12, frequency: 310, endFrequency: 220, gain: 0.16, pan: 0.18, shape: "sine", release: 0.08 });
  master(buffer, 0.8);
  return buffer;
}

function createApproved() {
  const buffer = makeStereo(0.3);
  [74, 78, 81].forEach((midi, index) => addPluck(buffer, index * 0.055, midi, 0.27 - index * 0.025, index * 0.24 - 0.24, 0.2));
  addSynth(buffer, { start: 0.11, duration: 0.17, frequency: note(86), gain: 0.12, pan: 0.3, shape: "sine", release: 0.14 });
  master(buffer, 0.78);
  return buffer;
}

function createSpeedup() {
  const buffer = makeStereo(0.5);
  [62, 67, 69, 74, 79].forEach((midi, index) => {
    addPluck(buffer, index * 0.065, midi, 0.22, index % 2 ? 0.28 : -0.28, 0.2);
  });
  addNoise(buffer, { start: 0.24, duration: 0.2, gain: 0.07, decay: 8, highPass: 0.92 });
  master(buffer, 0.8);
  return buffer;
}

function createFail() {
  const buffer = makeStereo(0.55);
  addSynth(buffer, { start: 0, duration: 0.46, frequency: 185, endFrequency: 58, gain: 0.36, shape: "saw", harmonics: 4, release: 0.2 });
  addSynth(buffer, { start: 0.03, duration: 0.39, frequency: 122, endFrequency: 67, gain: 0.24, pan: -0.18, shape: "square", release: 0.2 });
  addNoise(buffer, { start: 0, duration: 0.34, gain: 0.14, pan: 0.18, decay: 7, highPass: 0.62 });
  master(buffer, 0.78);
  return buffer;
}

function createButton() {
  const buffer = makeStereo(0.09);
  addNoise(buffer, { start: 0, duration: 0.022, gain: 0.13, decay: 100, highPass: 0.88 });
  addSynth(buffer, { start: 0, duration: 0.075, frequency: 610, endFrequency: 760, gain: 0.25, shape: "sine", release: 0.055 });
  master(buffer, 0.74);
  return buffer;
}

const temporaryDirectory = mkdtempSync(resolve(".factory-rush-audio-"));
try {
  const bgmWav = join(temporaryDirectory, "factory-rush-bgm.wav");
  writeWav(bgmWav, createBgm());
  const ffmpeg = spawnSync(
    "ffmpeg",
    [
      "-y",
      "-hide_banner",
      "-loglevel",
      "error",
      "-i",
      bgmWav,
      "-codec:a",
      "libmp3lame",
      "-b:a",
      "128k",
      "-ar",
      String(SAMPLE_RATE),
      "-ac",
      "2",
      "-metadata",
      "title=Factory Floor Sprint",
      "-metadata",
      "artist=天陽的漢堡工廠 Original Sound Team",
      join(outputDir, "factory-rush-bgm.mp3"),
    ],
    { stdio: "inherit" },
  );
  if (ffmpeg.status !== 0) throw new Error("ffmpeg could not encode the original BGM");

  const effects = {
    finish: createFinish(),
    return: createReturn(),
    approved: createApproved(),
    speedup: createSpeedup(),
    fail: createFail(),
    button: createButton(),
  };
  for (const [name, buffer] of Object.entries(effects)) {
    writeWav(join(outputDir, `${name}.wav`), buffer);
  }
} finally {
  rmSync(temporaryDirectory, { recursive: true, force: true });
}

console.log("Generated original 天陽的漢堡工廠 BGM and six gameplay effects in public/audio.");
